/* SANTUARIO SECRETO DE DRAGONES - UNIFIED STANDALONE BUNDLE v7.0.0 */

(function() {

  'use strict';



  // 1. UTILS

function initParticlesCanvas(canvasId = "particle-canvas") {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  // Check if reduced motion is preferred
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (prefersReducedMotion) {
    canvas.style.display = "none";
    return;
  }

  function getParticleCount() {
    return window.innerWidth < 768 ? 18 : 40;
  }

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener("resize", resize);

  let particles = Array.from({ length: getParticleCount() }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 2.2 + 0.8,
    vx: (Math.random() - 0.5) * 0.35,
    vy: (Math.random() - 0.5) * 0.35,
    alpha: Math.random() * 0.55 + 0.15
  }));

  let isAnimating = true;

  function animate() {
    if (!isAnimating) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = canvas.width;
      if (p.x > canvas.width) p.x = 0;
      if (p.y < 0) p.y = canvas.height;
      if (p.y > canvas.height) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(233, 196, 106, ${p.alpha})`;
      ctx.fill();
    });

    requestAnimationFrame(animate);
  }

  // Pause animation when tab is inactive to save battery and GPU
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      isAnimating = false;
    } else {
      if (!isAnimating) {
        isAnimating = true;
        animate();
      }
    }
  });

  animate();
}



let isMuted = (function() {
  try {
    return localStorage.getItem("santuario_sound_muted") === "true";
  } catch (e) {
    return false;
  }
})();
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioClass = window.AudioContext || window.webkitAudioContext;
    if (AudioClass) {
      audioCtx = new AudioClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

function playSound(type) {
  if (isMuted) return;
  
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    if (type === "click") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.05);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);

    } else if (type === "roar") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.linearRampToValueAtTime(180, now + 0.3);
      osc.frequency.linearRampToValueAtTime(80, now + 0.8);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.8);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.8);

    } else if (type === "chime" || type === "magic") {
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);
        gain.gain.setValueAtTime(0.12, now + idx * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.5);
      });

    } else if (type === "drum") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.15);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);

    } else if (type === "rune") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);

    } else if (type === "hit") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(30, now + 0.12);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.12);

    } else if (type === "clash") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.linearRampToValueAtTime(120, now + 0.2);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);

    } else if (type === "victory") {
      const notes = [440, 554.37, 659.25, 880];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);
        gain.gain.setValueAtTime(0.2, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.4);
      });
    }
  } catch (e) {
    console.warn("Web Audio synthesis error:", e);
  }
}

function updateAudioButtonUI() {
  const btn = document.getElementById("btn-audio-toggle");
  if (btn) {
    btn.textContent = isMuted ? "🔇 Sonido: OFF" : "🔊 Sonido: ON";
  }
}

function toggleSound() {
  isMuted = !isMuted;
  try {
    localStorage.setItem("santuario_sound_muted", isMuted ? "true" : "false");
  } catch (e) {
    console.warn("Could not save sound setting to localStorage:", e);
  }
  updateAudioButtonUI();
  if (!isMuted) {
    playSound("click");
  }
  return isMuted;
}



const favoritesSet = new Set(JSON.parse(localStorage.getItem("santuario_favorites") || "[]"));

function isFavorite(dragonId) {
  return favoritesSet.has(dragonId);
}

function toggleFavorite(dragonId) {
  if (favoritesSet.has(dragonId)) {
    favoritesSet.delete(dragonId);
  } else {
    favoritesSet.add(dragonId);
    playSound("chime");
  }
  localStorage.setItem("santuario_favorites", JSON.stringify([...favoritesSet]));
}

function getFavoritesSet() {
  return favoritesSet;
}



/**
 * Austin Osman Spare Consonant Filtering Algorithm
 * Removes vowels (including accents) and ANY consonant that appears more than once in the total phrase.
 */
function extractConsonants(str1 = "", str2 = "") {
  const combined = (str1 + " " + str2).toUpperCase();
  const normalized = combined.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const vowels = new Set(["A", "E", "I", "O", "U"]);

  const lettersOnly = [];
  for (let ch of normalized) {
    if (ch >= "A" && ch <= "Z") {
      lettersOnly.push(ch);
    }
  }

  const freq = {};
  for (let ch of lettersOnly) {
    if (!vowels.has(ch)) {
      freq[ch] = (freq[ch] || 0) + 1;
    }
  }

  const result = [];
  for (let ch of lettersOnly) {
    if (!vowels.has(ch) && freq[ch] === 1) {
      if (!result.includes(ch)) {
        result.push(ch);
      }
    }
  }

  return result.length > 0 ? result : ["M", "D", "T"];
}



// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
// Dragon Script dictionary mapping standard uppercase letters to custom SVG vector paths matching the official "Guía de Equivalencias Latino a Dragon" chart
const DRAGON_SCRIPT_MAP = {
  'A': { 
    glyph: 'S-Dragon', 
    desc: 'Serpiente Alada S-Curva', 
    desc_en: 'S-Curved Winged Serpent',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 32 10 C 15 8 10 20 25 25 C 40 30 35 44 15 42 M 15 42 L 10 38 M 15 42 L 20 38" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'B': { 
    glyph: 'Aliento-Fuego', 
    desc: 'Bocanada de Fuego Dracónico', 
    desc_en: 'Draconic Fire Breath',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 12 40 L 12 10 C 12 10 28 8 28 22 C 28 28 20 28 12 28 C 30 28 40 30 40 40 L 12 40 Z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'C': { 
    glyph: 'Zigzag-Crown', 
    desc: 'Corona Zigzag de la Caverna (C / K)', 
    desc_en: 'Cavern Zigzag Crown (C / K)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 8 18 L 50 18 M 8 28 L 18 18 L 28 32 L 38 18 L 48 28" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'D': { 
    glyph: 'Diamond-Rune', 
    desc: 'Rombo Sagrado de la Fortaleza', 
    desc_en: 'Sacred Diamond of Strength',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 25 8 L 40 25 L 25 42 L 10 25 Z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'E': { 
    glyph: 'Escama-Triple', 
    desc: 'Triple Escama de Protección', 
    desc_en: 'Triple Scale of Protection',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 14 10 L 14 40 M 14 12 L 38 12 M 14 25 L 32 25 M 14 38 L 38 38 M 38 12 L 34 18 M 38 38 L 34 32" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'F': { 
    glyph: 'Llama-Garra', 
    desc: 'Garra Ascendente de Fuego', 
    desc_en: 'Ascending Fire Claw',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 16 42 L 16 10 M 16 12 L 40 12 L 34 20 M 16 26 L 36 26 L 30 32" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'G': { 
    glyph: 'Spiral-Spiral', 
    desc: 'Espiral Doble Infinita', 
    desc_en: 'Infinite Double Spiral',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 25 25 C 12 20 12 8 25 8 C 38 8 38 20 25 25 C 12 30 12 42 25 42 C 38 42 38 30 25 25" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'H': { 
    glyph: 'Diamond-Horns', 
    desc: 'Rombo con Cuernos Superiores', 
    desc_en: 'Diamond with Upper Horns',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 25 18 L 38 30 L 25 42 L 12 30 Z M 12 30 L 8 12 M 38 30 L 42 12" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'I': { 
    glyph: 'Crossed-Arrows', 
    desc: 'Garras Cruzadas del Rayo (I / J)', 
    desc_en: 'Crossed Lightning Claws (I / J)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 12 10 L 38 40 M 38 10 L 12 40 M 12 40 L 12 30 M 12 40 L 22 40 M 38 40 L 38 30 M 38 40 L 28 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'J': { 
    glyph: 'Crossed-Arrows', 
    desc: 'Garras Cruzadas del Rayo (I / J)', 
    desc_en: 'Crossed Lightning Claws (I / J)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 12 10 L 38 40 M 38 10 L 12 40 M 12 40 L 12 30 M 12 40 L 22 40 M 38 40 L 38 30 M 38 40 L 28 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'K': { 
    glyph: 'Zigzag-Crown', 
    desc: 'Corona Zigzag de la Caverna (C / K)', 
    desc_en: 'Cavern Zigzag Crown (C / K)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 8 18 L 50 18 M 8 28 L 18 18 L 28 32 L 38 18 L 48 28" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'L': { 
    glyph: 'Colmillo-Anclado', 
    desc: 'Colmillo de Caza Anclado', 
    desc_en: 'Anchored Hunting Fang',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 15 10 L 15 40 L 40 40 M 40 40 L 32 32" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'M': { 
    glyph: 'Cresta-Dorsal', 
    desc: 'Cresta Dorsal de Gran Dragón', 
    desc_en: 'Great Dragon Dorsal Crest',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 8 40 L 8 12 L 25 32 L 42 12 L 42 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'N': { 
    glyph: 'Gate-Square', 
    desc: 'Puerta Portal de la Montaña', 
    desc_en: 'Mountain Portal Gate',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 12 40 L 12 18 C 12 10 38 10 38 18 L 38 40 M 20 40 L 20 26 C 20 20 30 20 30 26 L 30 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'O': { 
    glyph: 'Ojo-Barrado', 
    desc: 'Ojo de Dragón Barrado (Ø)', 
    desc_en: 'Barred Dragon Eye (Ø)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><circle cx="25" cy="25" r="14" fill="none" stroke="currentColor" stroke-width="3.5"/><path d="M 39 11 L 11 39" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/></svg>`
  },
  'P': { 
    glyph: 'Triangle-Points', 
    desc: 'Triángulo con Puntos Astrales', 
    desc_en: 'Triangle with Astral Points',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 25 10 L 40 38 L 10 38 Z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="25" cy="10" r="3" fill="currentColor"/><circle cx="10" cy="38" r="3" fill="currentColor"/><circle cx="40" cy="38" r="3" fill="currentColor"/></svg>`
  },
  'Q': { 
    glyph: 'Ojo-Barrado', 
    desc: 'Ojo de Dragón Barrado (Ø)', 
    desc_en: 'Barred Dragon Eye (Ø)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><circle cx="25" cy="25" r="14" fill="none" stroke="currentColor" stroke-width="3.5"/><path d="M 39 11 L 11 39" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/></svg>`
  },
  'R': { 
    glyph: 'Garra-Arco', 
    desc: 'Garra de Combate y Vuelo', 
    desc_en: 'Combat and Flight Claw',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 14 40 L 14 10 L 30 10 C 38 10 38 24 30 24 L 14 24 M 26 24 L 40 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'S': { 
    glyph: 'Cola-Serpiente', 
    desc: 'Látigo de la Cola Draconiana', 
    desc_en: 'Draconian Tail Whip',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 36 14 C 36 8 14 6 14 20 C 14 34 36 26 36 38 C 36 46 14 44 14 38 M 14 38 L 20 42" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'T': { 
    glyph: 'T-Rune', 
    desc: 'Sello de la Tierra Sagrada', 
    desc_en: 'Sacred Earth Seal',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 10 14 L 40 14 M 25 14 L 25 36 M 25 36 L 18 42 M 25 36 L 32 42" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'U': { 
    glyph: 'Copa-Aliento', 
    desc: 'Cáliz del Fuego Ferviente', 
    desc_en: 'Chalice of Fervent Fire',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 14 10 L 14 28 C 14 40 36 40 36 28 L 36 10 M 14 10 L 8 16 M 36 10 L 42 16" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'V': { 
    glyph: 'Triangle-Down', 
    desc: 'Triángulo Invertido del Fuego (U / V)', 
    desc_en: 'Inverted Fire Triangle (U / V)',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 10 12 L 40 12 L 25 40 Z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  },
  'W': { 
    glyph: 'Triangle-Loop-Down', 
    desc: 'Triángulo Invertido con Lazo', 
    desc_en: 'Inverted Triangle with Loop',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 10 18 L 40 18 L 25 42 Z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="25" cy="11" r="3" fill="none" stroke="currentColor" stroke-width="3"/></svg>`
  },
  'X': { 
    glyph: 'Cross-Dots', 
    desc: 'Cruz de los Cuatro Vientos', 
    desc_en: 'Cross of the Four Winds',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 10 25 L 40 25 M 25 10 L 25 40" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="10" cy="25" r="3" fill="currentColor"/><circle cx="40" cy="25" r="3" fill="currentColor"/><circle cx="25" cy="10" r="3" fill="currentColor"/><circle cx="25" cy="40" r="3" fill="currentColor"/></svg>`
  },
  'Y': { 
    glyph: 'Cross-Slashed', 
    desc: 'Estrella Tachada de las Nebulosas', 
    desc_en: 'Crossed Star of the Nebulae',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 8 25 L 42 25 M 25 8 L 25 42 M 12 12 L 38 38 M 38 12 L 12 38" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="25" cy="25" r="8" fill="none" stroke="currentColor" stroke-width="3"/></svg>`
  },
  'Z': { 
    glyph: 'Lengua-Bifida', 
    desc: 'Lengua Bífida de la Serpiente Dragón', 
    desc_en: 'Forked Tongue of the Dragon Serpent',
    svg: `<svg viewBox="0 0 50 50" width="38" height="38" style="vertical-align: middle;"><path d="M 25 42 L 25 22 M 25 22 L 12 8 M 25 22 L 38 8" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
  }
};

function translateToDragonScript(text) {
  if (!text) return [];
  const normalized = text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
  
  const clean = normalized.replace(/[^A-Z\s]/g, '');
  return clean.split('').map(char => {
    if (char === ' ') {
      return {
        char: ' ',
        info: { glyph: ' ', desc: 'Espacio Mágico', desc_en: 'Magical Space', svg: `<span style="display:inline-block; width:16px;"></span>` }
      };
    }
    const mapEntry = DRAGON_SCRIPT_MAP[char] || { glyph: char, desc: 'Símbolo Mágico', desc_en: 'Magical Symbol', svg: `<span style="font-size:1.5rem;">${char}</span>` };
    return {
      char: char,
      info: mapEntry
    };
  });
}

if (typeof window !== "undefined") {
  window.DRAGON_SCRIPT_MAP = DRAGON_SCRIPT_MAP;
  window.translateToDragonScript = translateToDragonScript;
}



  // 2. DATA

const DRAGONS_DATA = [
{
    id: 1, name: "Níðhöggr", title: "El Roedor de las Raíces del Mundo", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Sombra", danger: 5,
    habitat: "Niflheim (El Inframundo Helado)", ability: "Aliento de Corrupción y Mordedura Ancestral", weakness: "Luz de la Aurora Boreal",
    scroll: "En los relatos vikingos antiguos, Níðhöggr vive bajo las raíces del gran árbol Yggdrasil. Se pasa la eternidad royendo sus raíces heladas para desestabilizar los nueve mundos. Los sabios del norte decían que cuando baje volando de las montañas con cadáveres en sus alas, el mundo cambiará para siempre.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring dark shadowed purple scales and abyssal twilight smoke with main colors #2b0036 and #990000",
    svgType: "wyrm", colorPrimary: "#2b0036", colorSecondary: "#990000", glowColor: "#bf00ff"
  },
{
    id: 2, name: "Fafnir", title: "El Guardián del Tesoro Maldito", mythology: "Nórdica y Germánica", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Breiðablik (Cueva de las Montañas)", ability: "Piel Impenetrable y Aliento de Fuego Dorado", weakness: "Punto débil oculto bajo su hombro izquierdo",
    scroll: "Fafnir era originalmente un príncipe enano tan codicioso que se transformó en un dragón colosal para proteger su tesoro de oro y el anillo maldito Andvaranaut. Su veneno quemaba el pasto por donde caminaba y su rugido hacía temblar los fiordos.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring blazing fiery scales and glowing ember accents with main colors #664400 and #ffd700",
    svgType: "draco", colorPrimary: "#664400", colorSecondary: "#ffd700", glowColor: "#ffaa00"
  },
{
    id: 3, name: "Jörmungandr", title: "La Serpiente de Midgard", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Agua", danger: 5,
    habitat: "Océano Global de Midgard", ability: "Maremotos Gigantescos y Veneno Letal Eitr", weakness: "El Martillo de Thor (Mjölnir)",
    scroll: "Hijo de Loki, este dragón marino creció tanto que logró rodear toda la Tierra y morderse su propia cola. Si llega a soltar su cola, las olas colosales cubrirán los continentes. Los marineros vikingos evitaban las aguas oscuras por miedo a despertar sus escamas turquesas.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #004d40 and #00bfa5",
    svgType: "shen", colorPrimary: "#004d40", colorSecondary: "#00bfa5", glowColor: "#18ffff"
  },
{
    id: 4, name: "Goinn", title: "El Excavador de la Niebla", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Naturaleza", danger: 3,
    habitat: "Bosques Helados de Jotunheim", ability: "Camuflaje de Musgo y Excavación Relámpago", weakness: "Fuego Volcánico",
    scroll: "Un dragón subterráneo cubierto de líquenes y raíces fosilizadas. Pasaba siglos durmiendo bajo el suelo vikingo, alimentándose de minerales raros. Dicen que las grietas en las rocas de Noruega son rastros de sus antiguas excavaciones.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #1b5e20 and #81c784",
    svgType: "wyrm", colorPrimary: "#1b5e20", colorSecondary: "#81c784", glowColor: "#4caf50"
  },
{
    id: 5, name: "Moinn", title: "El Habitante de los Turbales", mythology: "Nórdica y Germánica", type: "Drake", element: "Tierra", danger: 3,
    habitat: "Pantanos de Skáney", ability: "Trampas de Lodo Espeso y Escamas de Piedra", weakness: "Vientos Fuertes",
    scroll: "Hermano de Goinn, Moinn habita en los pantanos donde la niebla nunca se disipa. Sus escamas son gruesas como baldosas de granito y se arrastra en el barro sin hacer un solo ruido.",
    physicalDescription: "majestic dragon featuring subterranean mossy stone scales and earthy amber glow with main colors #3e2723 and #8d6e63",
    svgType: "draco", colorPrimary: "#3e2723", colorSecondary: "#8d6e63", glowColor: "#d7ccc8"
  },
{
    id: 6, name: "Grabakr", title: "La Llama Gris de la Caverna", mythology: "Nórdica y Germánica", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Cavernas de Ceniza de Muspelheim", ability: "Aliento de Ceniza Ardiente y Visión Térmica", weakness: "Agua de Glaciar",
    scroll: "Cuyo nombre significa 'Lomo Gris', este dragón posee escamas de color carbón que se encienden al enfurecerse. Se cuenta que dormía cerca de los ríos de lava y usaba las rocas calientes como almohada.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring blazing fiery scales and glowing ember accents with main colors #212121 and #ff5722",
    svgType: "draco", colorPrimary: "#212121", colorSecondary: "#ff5722", glowColor: "#ff9800"
  },
{
    id: 7, name: "Grafvolludr", title: "El Señor de las Fosas Ancestrales", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Veneno", danger: 4,
    habitat: "Fosas de Hvergelmir", ability: "Nube Ácida Sulfurosa", weakness: "Aire Puro de las Alturas",
    scroll: "Habitante de las profundidades donde emanan los géiseres sulfurosos. Grafvolludr desprende un humo tóxico que desorienta a cualquiera que intente explorar su guarida subterránea.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring acidic emerald green scales and dripping venomous mist with main colors #33691e and #aed581",
    svgType: "wyrm", colorPrimary: "#33691e", colorSecondary: "#aed581", glowColor: "#76ff03"
  },
{
    id: 8, name: "Svafnir", title: "El Soporífero del Invierno", mythology: "Nórdica y Germánica", type: "Drake", element: "Hielo", danger: 3,
    habitat: "Cumbres Snow-Cap", ability: "Canto de Congelamiento Instantáneo", weakness: "Llama de Antorcha Solar",
    scroll: "Un dragón escarchado cuyo rugido suave suena como el viento de invierno produciendo sueño profundo en los viajeros. Sus escamas parecen cristales pulidos de hielo milenario.",
    physicalDescription: "majestic dragon featuring crystalline icy frost scales and glowing cyan frost aura with main colors #006064 and #80deea",
    svgType: "draco", colorPrimary: "#006064", colorSecondary: "#80deea", glowColor: "#00e5ff"
  },
{
    id: 9, name: "Ofnir", title: "El Enroscado de la Niebla", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Viento", danger: 4,
    habitat: "Cielos de Asgard", ability: "Vuelo Silencioso y Ciclón de Niebla", weakness: "Relámpagos",
    scroll: "Surcaba los cielos escandinavos camuflado en las nubes densas. Su cuerpo delgado y flexible le permitía deslizarse entre las corrientes de aire como una cinta dorada de luz difusa.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #455a64 and #cfd8dc",
    svgType: "shen", colorPrimary: "#455a64", colorSecondary: "#cfd8dc", glowColor: "#eceff1"
  },
{
    id: 10, name: "Lindwyrm de Götaland", title: "El Terror de los Caminos de Suecia", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Tierra", danger: 4,
    habitat: "Valles de Götaland", ability: "Embestida Demoledora y Escamas Afiladas", weakness: "Leche Dulce y Espejos",
    scroll: "Un lindwyrm gigante sin alas, de cuerpo serpentino y dos potentes patas delanteras que aterrorizaba los antiguos caminos de Suecia. Los cuentos populares decían que si le ofrecías un tazón de leche recién ordeñada, se quedaba dormido pacíficamente.",
    physicalDescription: "wingless serpent-like dragon with two strong front legs, coiled scaly body and horns, resting over a stone wall in misty Swedish pine forest, Wyrm dragon with Tierra powers in Valles de Götaland",
    svgType: "wyrm", colorPrimary: "#4a148c", colorSecondary: "#ab47bc", glowColor: "#e040fb"
  },
{
    id: 11, name: "Ladón", title: "El Guardián de las Manzanas Doradas", mythology: "Griega y Romana", type: "Hidra", element: "Tierra", danger: 3,
    habitat: "El Jardín de las Hespérides", ability: "100 Cabezas Parlantes y Sueño Inexistente", weakness: "Las Flechas con Veneno de Hidra",
    scroll: "Este mítico dragón de cien cabezas nunca dormía. Cada cabeza hablaba en un idioma o tono distinto para confundir a los intrusos que intentaban robar las manzanas de oro sagradas de la diosa Hera. Fue enfrentado por el legendario Hércules.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring subterranean mossy stone scales and earthy amber glow with main colors #b71c1c and #ffb74d",
    svgType: "hidra", colorPrimary: "#b71c1c", colorSecondary: "#ffb74d", glowColor: "#ff9100"
  },
{
    id: 12, name: "Hidra de Lerna", title: "La Bestia del Pantano Infinito", mythology: "Griega y Romana", type: "Hidra", element: "Agua", danger: 5,
    habitat: "Lago de Lerna", ability: "Regeneración Cabeza por Cabeza y Sangre Ácida", weakness: "Fuego Cauterizador",
    scroll: "Criatura acuática con múltiples cabezas de serpiente. Si le cortabas una cabeza, le crecían dos más inmediatamente. Su aliento era tan venenoso que bastaba con respirar cerca de su guarida para caer en un trance profundo.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring acidic emerald green scales and dripping venomous mist with main colors #1b5e20 and #00e676",
    svgType: "hidra", colorPrimary: "#1b5e20", colorSecondary: "#00e676", glowColor: "#b2ff59"
  },
{
    id: 13, name: "Pitón de Delfos", title: "La Serpiente del Oráculo", mythology: "Griega y Romana", type: "Wyrm", element: "Tierra", danger: 4,
    habitat: "Monte Parnaso", ability: "Terremotos Locales y Soplido de Tierra Chocante", weakness: "Flechas Doradas del Dios Apolo",
    scroll: "Hija de la diosa Gaia, esta serpiente-dragón custodiaba el centro de la Tierra en Delfos. Sus escamas imitaban los colores de las rocas y el barro, y su cuerpo era tan ancho como un roble milenario.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring subterranean mossy stone scales and earthy amber glow with main colors #4e342e and #bcaaa4",
    svgType: "wyrm", colorPrimary: "#4e342e", colorSecondary: "#bcaaa4", glowColor: "#d7ccc8"
  },
{
    id: 14, name: "Dragón de Colquide", title: "El Insonmne del Vellocino de Oro", mythology: "Griega y Romana", type: "Dragón Europeo", element: "Tormenta", danger: 3,
    habitat: "Bosque Sagrado de Ares (Colquide)", ability: "Silbido Ensordecedor y Mirada Hipnótica", weakness: "Pociones Lulaby de la Hechicera Medea",
    scroll: "Enroscado al árbol donde colgaba el mítico Vellocino de Oro. Nunca cerraba los ojos y su silbido se escuchaba a millas de distancia. Jasón y los Argonautas solo lograron vencerlo gracias a un filtro mágico de sueño que preparó Medea.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring electric crackling scales and sparkling lightning sparks with main colors #f57f17 and #fff59d",
    svgType: "draco", colorPrimary: "#f57f17", colorSecondary: "#fff59d", glowColor: "#ffff00"
  },
{
    id: 15, name: "Dragón de Ismene", title: "El Guardián de la Fuente de Ares", mythology: "Griega y Romana", type: "Drakón", element: "Agua", danger: 4,
    habitat: "Fuente Manantial de Tebas", ability: "Chorros de Agua a Gran Presión y Dientes de Guerrero", weakness: "Lanzas de Bronce Templado",
    scroll: "Hijo de Ares, este dragón protegía las aguas sagradas de Tebas. Cuando el héroe Cadmo lo derrotó, sembró sus dientes en la tierra y de ellos nacieron guerreros armados completos con escudos de bronce.",
    physicalDescription: "majestic dragon featuring magical elemental aura with main colors #00695c and #80cbc4",
    svgType: "draco", colorPrimary: "#0d47a1", colorSecondary: "#64b5f6", glowColor: "#40c4ff"
  },
{
    id: 16, name: "Ceto", title: "El Monstruo de las Profundidades Abisales", mythology: "Griega y Romana", type: "Drakón", element: "Agua", danger: 4,
    habitat: "Mar Egeo", ability: "Tsunamis Embajadores y Escamas de Arrecife", weakness: "Reflejo del Escudo de Atenea",
    scroll: "Un voraz dragón marino enviado por Poseidón. Poseía aletas gigantescas que parecían alas de murciélago submarinas y dientes como estalactitas de roca volcánica.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #002171 and #5472d3",
    svgType: "shen", colorPrimary: "#002171", colorSecondary: "#5472d3", glowColor: "#80d8ff"
  },
{
    id: 17, name: "Campe", title: "La Carcelera del Tártaro", mythology: "Griega y Romana", type: "Hidra", element: "Sombra", danger: 5,
    habitat: "Abismo del Tártaro", ability: "Cola de Escorpión Venom y 50 Cabezas de Bestias", weakness: "El Rayo Primordial de Zeus",
    scroll: "Monstruosa guardiana que custodiaba a los Cíclopes en el inframundo. Su cuerpo combinaba partes de dragón, serpientes en los pies y alas oscuras que tapaban las estrellas.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring dark shadowed purple scales and abyssal twilight smoke with main colors #1a237e and #9c27b0",
    svgType: "hidra", colorPrimary: "#1a237e", colorSecondary: "#9c27b0", glowColor: "#ea80fc"
  },
{
    id: 18, name: "Tifón Dragón", title: "El Titán de los Cien Huracanes", mythology: "Griega y Romana", type: "Otros", element: "Tormenta", danger: 5,
    habitat: "Monte Etna", ability: "Llamaradas de Azufre y Vientos Ciclónicos", weakness: "El Rayo Maestro del Olimpo",
    scroll: "Considerado el padre de todos los monstruos griegos. Sus cabezas tocaban las estrellas y de sus ojos salía un fuego violento capaz de derretir montañas enteras.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring magical elemental aura with main colors #311b92 and #ff1744",
    svgType: "draco", colorPrimary: "#311b92", colorSecondary: "#ff1744", glowColor: "#ff5252"
  },
{
    id: 19, name: "Drakon Nemeios", title: "El Dragón de los Viñedos", mythology: "Griega y Romana", type: "Drakón", element: "Naturaleza", danger: 2,
    habitat: "Valles de Peloponeso", ability: "Camuflaje entre las Vides y Crecimiento Veloz", weakness: "Frío Extremo",
    scroll: "Un pequeño dragón de las colinas griegas que solía proteger los viñedos de las plagas comiéndose a los roedores y expulsando un suave vapor con olor a uvas dulces.",
    physicalDescription: "majestic dragon featuring magical elemental aura with main colors #33691e and #c0ca33",
    svgType: "draco", colorPrimary: "#33691e", colorSecondary: "#c0ca33", glowColor: "#eeff41"
  },
{
    id: 20, name: "Leviatán", title: "El Titán Definitivo de las Profundidades", mythology: "Mesopotámica y Medio Oriente", type: "Otros", element: "Agua", danger: 5,
    habitat: "Abismo del Océano Primordial", ability: "Hervor del Océano y Chispas de Fuego Abrasador", weakness: "Las Cadenas Celestiales de los Tiempos",
    scroll: "Un dragón de agua de casi 500 kilómetros. Leviatán es el titán definitivo de las profundidades: cuando tiene hambre, el calor de sus fauces hace hervir el océano. Su anatomía es una máquina de guerra. Lomo blindado por hileras de escamas durísimas y dientes como navajas. Los ojos brillan, rojos y dorados, como el primer destello del amanecer. De la boca le saltan chispas; de la nariz, un humo espeso. Si se despierta, trae rayos y vendavales que parten el cielo.",
    physicalDescription: "colossal ancient sea serpent wyrm dragon with dark armored scaly spine, razor-sharp teeth, glowing golden-red eyes, exhaling fire sparks and steam mist into boiling ocean storm with lightning, Wyrm dragon with Agua powers in Abismo del Océano Primordial",
    svgType: "wyrm", colorPrimary: "#1a237e", colorSecondary: "#ff6f00", glowColor: "#ffab00"
  },
{
    id: 21, name: "Shen Lung", title: "El Dragón Espíritu del Clima", mythology: "Oriental (Asia)", type: "Shen", element: "Tormenta", danger: 3,
    habitat: "Nubes del Cielo Celestial", ability: "Control del Lluvia, Viento y Rayos Benditos", weakness: "Falta de Respeto a la Naturaleza",
    scroll: "Dragón azul brillante que vuela sin necesidad de alas. En la antigua China, los agricultores le ofrecían cantos y té para que trajera lluvias suaves a las cosechas de arroz. Es considerado un símbolo de sabiduría y prosperidad.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #0277bd and #81d4fa",
    svgType: "shen", colorPrimary: "#0277bd", colorSecondary: "#81d4fa", glowColor: "#00b0ff"
  },
{
    id: 22, name: "T'ien Lung", title: "El Dragón Celestial de los Dioses", mythology: "Oriental (Asia)", type: "Shen", element: "Luz", danger: 4,
    habitat: "Palacios de las Estrellas", ability: "Escudo de Luz Divina y Vuelo Cómico", weakness: "Niebla de Engaño",
    scroll: "El encargado de tirar de los carros de los dioses celestiales y proteger los palacios del cielo. Sus escamas brillan como si tuviera incrustadas miles de gemas estelares.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring golden radiant celestial scales and brilliant solar sparks with main colors #fbc02d and #fff9c4",
    svgType: "shen", colorPrimary: "#fbc02d", colorSecondary: "#fff9c4", glowColor: "#ffff8d"
  },
{
    id: 23, name: "Ti Lung", title: "El Dragón de la Tierra y los Ríos", mythology: "Oriental (Asia)", type: "Wyrm", element: "Agua", danger: 3,
    habitat: "Profundidades del Río Amarillo", ability: "Moldeo de Canales de Agua y Terremotos Suaves", weakness: "Sequía Extrema",
    scroll: "Dragón terrestre que habita bajo el lecho de los grandes ríos de Asia. Se decía que cuando Ti Lung nadaba por debajo de la tierra, creaba fértiles valles y manantiales cristalinos.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring subterranean mossy stone scales and earthy amber glow with main colors #5d4037 and #d7ccc8",
    svgType: "wyrm", colorPrimary: "#5d4037", colorSecondary: "#d7ccc8", glowColor: "#bcaaa4"
  },
{
    id: 24, name: "Fu-ts'an Lung", title: "El Dragón de los Tesoros Ocultos", mythology: "Oriental (Asia)", type: "Shen", element: "Magma", danger: 4,
    habitat: "Volcanes y Minas de Jade", ability: "Geiseres de Lava y Creación de Diamantes", weakness: "Agua Bendita de Manantial",
    scroll: "Este dragón vive en las profundidades del volcán custodiando los metales preciosos y gemas del planeta. Cuando emerge a la superficie para saludar al sol, crea un volcán con su aliento candente.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring volcano lava scales with glowing molten core with main colors #d84315 and #ffab91",
    svgType: "shen", colorPrimary: "#d84315", colorSecondary: "#ffab91", glowColor: "#ff6e40"
  },
{
    id: 25, name: "Ying-lung", title: "El Dragón Alado con Caimán", mythology: "Oriental (Asia)", type: "Shen", element: "Agua", danger: 4,
    habitat: "Lagos Ancestrales de Hubei", ability: "Canalización de Riadas y Control de Vientos", weakness: "Flechas de Bambú Sagrado",
    scroll: "El único dragón oriental tradicional con grandes alas de pluma de águila. Ayudó al mítico emperador Yu a detener las grandes inundaciones dibujando canales en la tierra con su larga cola.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring magical elemental aura with main colors #00695c and #80cbc4",
    svgType: "draco", colorPrimary: "#00695c", colorSecondary: "#80cbc4", glowColor: "#64ffda"
  },
{
    id: 26, name: "Lung Wang", title: "El Rey Dragón de los Cuatro Mares", mythology: "Oriental (Asia)", type: "Shen", element: "Agua", danger: 5,
    habitat: "Palacio de Cristal bajo el Mar", ability: "Transformación Humana y Dominio de las Mareas", weakness: "Perla Maravillosa Robada",
    scroll: "Gobernador supremo de los cuatro océanos (Norte, Sur, Este y Oeste). Vive en un palacio construido con coral y perlas cristalinas, rodeado de un ejército de generales peces y mariscos mágicos.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #1565c0 and #90caf9",
    svgType: "shen", colorPrimary: "#1565c0", colorSecondary: "#90caf9", glowColor: "#448aff"
  },
{
    id: 27, name: "Yamata no Orochi", title: "La Serpiente de Ocho Cabezas y Ocho Colas", mythology: "Oriental (Asia)", type: "Hidra", element: "Sombra", danger: 5,
    habitat: "Provincia de Izumo (Japón)", ability: "Rugido Sembrador de Caos y Ojos como Linternas de Fuego", weakness: "Sake de Ocho Veces Refinado",
    scroll: "Gigantesco dragón japonés con 8 cabezas y 8 colas, cuyo cuerpo ocupaba ocho valles y ocho colinas. En sus espaldas crecían musgo, cipreses y cedros antiguos. Fue vencido por el astuto dios Susanoo.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring dark shadowed purple scales and abyssal twilight smoke with main colors #4a148c and #e1bee7",
    svgType: "hidra", colorPrimary: "#4a148c", colorSecondary: "#e1bee7", glowColor: "#d500f9"
  },
{
    id: 28, name: "Ryujin", title: "El Dios Dragón del Océano Shinto", mythology: "Oriental (Asia)", type: "Shen", element: "Agua", danger: 4,
    habitat: "Ryūgū-jō (Palacio del Dragón)", ability: "Joyas Mareales (Control de Bajamar y Pleamar)", weakness: "La Medicina del Medusa Marina",
    scroll: "Posee el poder de manipular las mareas del mar de Japón mediante dos joyas mágicas: Kanju (marea baja) y Manju (marea alta). Es conocido por su generosidad con los navegantes de buen corazón.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #004d40 and #a7ffeb",
    svgType: "shen", colorPrimary: "#004d40", colorSecondary: "#a7ffeb", glowColor: "#18ffff"
  },
{
    id: 29, name: "Kiyohime", title: "La Llama de la Pasión Transformada", mythology: "Oriental (Asia)", type: "Wyrm", element: "Fuego", danger: 4,
    habitat: "Río Hidaka", ability: "Aliento de Fuego Vengativo y Nadado Ultrarrápido", weakness: "Campana de Bronce de Templo",
    scroll: "Cuenta la leyenda que era una joven que, dominada por una emoción intensa, se transformó en un dragón serpenteante capaz de cruzar ríos embravecidos soltando chispas de fuego por la boca.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring blazing fiery scales and glowing ember accents with main colors #ad1457 and #f8bbd0",
    svgType: "wyrm", colorPrimary: "#ad1457", colorSecondary: "#f8bbd0", glowColor: "#ff4081"
  },
{
    id: 30, name: "Mizuchi", title: "El Dragón de Agua Dulce", mythology: "Oriental (Asia)", type: "Wyrm", element: "Veneno", danger: 3,
    habitat: "Ríos y Lagunas de Nara", ability: "Veneno Fluvial y Niebla Escondite", weakness: "Flores de Calabaza Silvestre",
    scroll: "Un dragón con cuernos rectos y cuerpo de serpiente de agua. Exhalaba un veneno que adormecía a los peces del río hasta que un héroe local aprendió a neutralizarlo con plantas curativas.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring acidic emerald green scales and dripping venomous mist with main colors #00695c and #b2dfdb",
    svgType: "wyrm", colorPrimary: "#00695c", colorSecondary: "#b2dfdb", glowColor: "#64ffda"
  },
{
    id: 31, name: "Imoogi", title: "El Dragón en Potencia", mythology: "Oriental (Asia)", type: "Wyrm", element: "Luz", danger: 2,
    habitat: "Cuevas de las Montañas de Seoraksan", ability: "Paciencia Milenaria y Bendición del Sol", weakness: "Interrupción de su Trance Místico",
    scroll: "En la mitología coreana, una serpiente gigante debe vivir mil años en paz para obtener una joya celestial (Yeouiju) y transformar su cuerpo en un majestuoso Dragón del Cielo.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring golden radiant celestial scales and brilliant solar sparks with main colors #f57f17 and #fff59d",
    svgType: "shen", colorPrimary: "#f57f17", colorSecondary: "#fff59d", glowColor: "#ffff00"
  },
{
    id: 32, name: "Yong", title: "El Dragón de los Cuatro Climas", mythology: "Oriental (Asia)", type: "Shen", element: "Naturaleza", danger: 3,
    habitat: "Cumbres de la Península Coreana", ability: "Convocatoria de Vientos de Primavera", weakness: "Ruidos Metálicos Estridentes",
    scroll: "Portador de la joya brillante Yeouiju en sus garras. Simboliza la armonía entre los elementos naturales y el respeto a los antepasados.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #2e7d32 and #c8e6c9",
    svgType: "shen", colorPrimary: "#2e7d32", colorSecondary: "#c8e6c9", glowColor: "#69f0ae"
  },
{
    id: 33, name: "Zhulong", title: "El Guardián del Fuego Estival", mythology: "Oriental (Asia)", type: "Shen", element: "Fuego", danger: 4,
    habitat: "Montañas del Sur de Hunan", ability: "Calor Solar y Chispa Vital", weakness: "Lluvia Glacial",
    scroll: "Representa el verano y el elemento fuego dentro de los puntos cardinales tradicionales orientales. Sus plumas de fuego iluminan las noches oscuras.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring blazing fiery scales and glowing ember accents with main colors #c62828 and #ff8a80",
    svgType: "shen", colorPrimary: "#c62828", colorSecondary: "#ff8a80", glowColor: "#ff5252"
  },
{
    id: 34, name: "Druk del Bhután", title: "El Dragón del Trueno de las Alturas", mythology: "Oriental (Asia)", type: "Shen", element: "Tormenta", danger: 3,
    habitat: "Montañas del Himalaya", ability: "Rugido de Trueno de Alta Montaña", weakness: "Baja Altitud",
    scroll: "El Dragón del Trueno que adorna la bandera nacional de Bhután. Vuela entre los picos nevados del Himalaya sosteniendo perlas que representan la riqueza y la paz.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #ef6c00 and #ffe0b2",
    svgType: "shen", colorPrimary: "#ef6c00", colorSecondary: "#ffe0b2", glowColor: "#ffab40"
  },
{
    id: 35, name: "Yulong", title: "El Tercer Príncipe de Jade", mythology: "Oriental (Asia)", type: "Shen", element: "Cristal", danger: 3,
    habitat: "Océano del Oeste y Montañas de Jade", ability: "Metamorfosis Equina y Piel de Jade Sanadora", weakness: "Perla Incendiada del Padre",
    scroll: "Yulong (el Dragón de Jade) es el tercer príncipe del Rey Dragón del Mar del Oeste (Ao Lie). Inmortalizado en la inmortal novela 'Viaje al Oeste', tras cometer una falta juvenil fue perdonado por la diosa Guanyin y se transformó en el majestuoso caballo blanco que transportó fielmente al monje Xuanzang en su peregrinación a la India.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #00796b and #b2dfdb",
    svgType: "shen", colorPrimary: "#00796b", colorSecondary: "#b2dfdb", glowColor: "#a7ffeb"
  },
{
    id: 36, name: "Quetzalcóatl", title: "La Serpiente Emplumada de la Mañana", mythology: "Mesoamericana y Sudamericana", type: "Ampithere", element: "Naturaleza", danger: 4,
    habitat: "Tenochtitlan / Cielos Mesoamericanos", ability: "Control del Viento, Sabiduría Divina y Vuelo de Plumas de Quetzal", weakness: "Espejos de Obsidiana Oscura",
    scroll: "Una de las deidades más veneradas del México antiguo. Mezcla la majestuosidad de las serpientes verdes con el plumaje iridiscente del ave quetzal. Traía el conocimiento de las estrellas, la agricultura y el viento suave de la tarde.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring golden radiant celestial scales and brilliant solar sparks with main colors #2e7d32 and #ffd54f",
    svgType: "ampithere", colorPrimary: "#2e7d32", colorSecondary: "#ffd54f", glowColor: "#00e676"
  },
{
    id: 37, name: "Xiuhcóatl", title: "La Serpiente de Fuego Turquesa", mythology: "Mesoamericana y Sudamericana", type: "Wyrm", element: "Magma", danger: 5,
    habitat: "Monte Coatepec", ability: "Rayo de Rayos Solares y Calor Volcánico", weakness: "Agua de Cenote Frío",
    scroll: "Utilizada como arma sagrada por el dios Huitzilopochtli. Su cuerpo estaba formado por mosaicos de turquesa que ardían con una llama azul brillante capaz de atravesar cualquier escudo.",
    physicalDescription: "vibrant Aztec fire serpent dragon made of glowing cyan turquoise mosaic scales, fiery orange mane, sharp horn snout, exhaling blazing blue volcanic flames near Mount Coatepec, Wyrm dragon with Magma powers in Monte Coatepec",
    svgType: "wyrm", colorPrimary: "#00838f", colorSecondary: "#ff6f00", glowColor: "#ffab00"
  },
{
    id: 38, name: "Kukulkán", title: "La Serpiente Visión de la Pirámide", mythology: "Mesoamericana y Sudamericana", type: "Ampithere", element: "Viento", danger: 4,
    habitat: "Chichén Itzá", ability: "Sombra Danzante en los Solsticios y Eco de Quetzal", weakness: "Eclipses Solares Totales",
    scroll: "En la gran pirámide de Chichén Itzá, cada equinoccio la luz del sol proyecta la sombra serpenteante de Kukulkán descendiendo por las escalinatas hasta la gran cabeza de piedra en la base.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring magical elemental aura with main colors #00695c and #80e27e",
    svgType: "ampithere", colorPrimary: "#00695c", colorSecondary: "#80e27e", glowColor: "#b9f6ca"
  },
{
    id: 39, name: "Amaru", title: "La Serpiente Alada de los Andes", mythology: "Mesoamericana y Sudamericana", type: "Ampithere", element: "Tormenta", danger: 4,
    habitat: "Cumbres del Cusco / Lago Titicaca", ability: "Granizo Destructivo y Convocatoria de Lluvias de Montaña", weakness: "Sol de Mediodía Seco",
    scroll: "Mítico dragón serpiente con cabeza de llama, alas de cóndor y cola de pez. Los antiguos incas creían que el Amaru emergía de las cumbres o los lagos para anunciar cambios trascendentales en la naturaleza.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring magical elemental aura with main colors #6a1b9a and #ffb300",
    svgType: "ampithere", colorPrimary: "#6a1b9a", colorSecondary: "#ffb300", glowColor: "#ffd54f"
  },
{
    id: 40, name: "Trentren Vilu", title: "La Serpiente Protectora de la Tierra", mythology: "Mesoamericana y Sudamericana", type: "Otros", element: "Tierra", danger: 4,
    habitat: "Cerros y Cordilleras del Sur", ability: "Elevación de Montañas y Terremotos Protectores", weakness: "Tsunamis de Caicai Vilu",
    scroll: "En la cosmología mapuche, Trentren Vilu es la benigna serpiente de la tierra que elevó los cerros para salvar a la humanidad de una gigante inundación provocada por la serpiente del mar.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring subterranean mossy stone scales and earthy amber glow with main colors #4e342e and #a1887f",
    svgType: "wyrm", colorPrimary: "#4e342e", colorSecondary: "#a1887f", glowColor: "#d7ccc8"
  },
{
    id: 41, name: "Caicai Vilu", title: "La Serpiente de los Maremotos", mythology: "Mesoamericana y Sudamericana", type: "Otros", element: "Agua", danger: 5,
    habitat: "Océano Pacífico Sur", ability: "Crecimiento del Nivel del Mar y Olas Gigantes", weakness: "El Cantar de Trentren Vilu",
    scroll: "Serpiente marina legendaria que reina sobre los peces y los océanos. Su feroz batalla contra Trentren dio origen al archipiélago de Chiloé y sus múltiples islas pintorescas.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #0d47a1 and #42a5f5",
    svgType: "shen", colorPrimary: "#0d47a1", colorSecondary: "#42a5f5", glowColor: "#80d8ff"
  },
{
    id: 42, name: "Alicanto Dorado", title: "El Dragón Volador de Atacama", mythology: "Mesoamericana y Sudamericana", type: "Ampithere", element: "Luz", danger: 2,
    habitat: "Desierto de Atacama", ability: "Alimentación de Oro y Resplandor Guía", weakness: "La Codicia de los Hombres",
    scroll: "Criatura alada misteriosa que se alimenta de vetas de oro y plata puro en el desierto. Emite una luz dorada brillante que guía a los mineros de buen corazón hacia yacimientos ocultos.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring golden radiant celestial scales and brilliant solar sparks with main colors #ff8f00 and #ffe082",
    svgType: "ampithere", colorPrimary: "#ff8f00", colorSecondary: "#ffe082", glowColor: "#ffecb3"
  },
{
    id: 43, name: "Bohitu", title: "El Dragón del Río Amazonas", mythology: "Mesoamericana y Sudamericana", type: "Otros", element: "Naturaleza", danger: 3,
    habitat: "Río Selva Amazónica", ability: "Camuflaje de Liana y Canto de Selva", weakness: "Hachas de Hierro",
    scroll: "Protegía la vegetación tupida de la cuenca amazónica. Se deslizaba entre los copos de los árboles gigantes como si fuera una liana viva que despedía brillo verde fluorescente por las noches.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #1b5e20 and #76ff03",
    svgType: "wyrm", colorPrimary: "#1b5e20", colorSecondary: "#76ff03", glowColor: "#b2ff59"
  },
{
    id: 44, name: "Q'uq'umatz", title: "La Serpiente Resplandeciente del Popol Vuh", mythology: "Mesoamericana y Sudamericana", type: "Ampithere", element: "Agua", danger: 3,
    habitat: "Cielos Verdes de Guatemala", ability: "Creación de Aguas Cristalinas y Vuelo Plumado", weakness: "Fuego de Carbón",
    scroll: "Citado en el libro sagrado Popol Vuh como uno de los dioses creadores que meditaban rodeados de plumas verdes y azules en las aguas primordiales.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring magical elemental aura with main colors #00796b and #80cbc4",
    svgType: "ampithere", colorPrimary: "#00796b", colorSecondary: "#80cbc4", glowColor: "#e0f2f1"
  },
{
    id: 45, name: "Coatlicue Serpiente", title: "La Madre Dragón de las Faldas de Piedra", mythology: "Mesoamericana y Sudamericana", type: "Otros", element: "Tierra", danger: 4,
    habitat: "Templo Mayor de Tenochtitlan", ability: "Petrificación Instantánea de Invasores", weakness: "Luz de la Luna Llena",
    scroll: "Representada con dos cabezas de serpiente en lugar de rostro que simbolizan el equilibrio entre la vida y la tierra que renace.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring subterranean mossy stone scales and earthy amber glow with main colors #37474f and #90a4ae",
    svgType: "hidra", colorPrimary: "#37474f", colorSecondary: "#90a4ae", glowColor: "#cfd8dc"
  },
{
    id: 46, name: "Y Ddraig Goch", title: "El Dragón Rojo de Gales", mythology: "Celta y Británica", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Montañas de Snowdonia (Gales)", ability: "Rugido de Libertad y Aliento Abrasador", weakness: "Vino Dulce Dulce de Brezo",
    scroll: "El famoso Dragón Rojo que aparece orgulloso en la bandera de Gales. Combatió durante siglos contra el dragón blanco invasor bajo la colina de Dinas Emrys hasta salir victorioso.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring blazing fiery scales and glowing ember accents with main colors #b71c1c and #ff5252",
    svgType: "draco", colorPrimary: "#b71c1c", colorSecondary: "#ff5252", glowColor: "#ff1744"
  },
{
    id: 47, name: "Wyvern de Wessex", title: "El Señor de las Alas Peligrosas", mythology: "Celta y Británica", type: "Wyvern", element: "Veneno", danger: 4,
    habitat: "Bosques de Hampshire", ability: "Aguijón de Cola Venenoso y Vuelo en Picada", weakness: "Escudos Rechazantes con Espejo",
    scroll: "Un dragón de dos patas y alas membranosas temido por los caballeros anglosajones. Poseía un aguijón en la punta de la cola similar al de un escorpión gigantesco.",
    physicalDescription: "two-legged agile winged dragon with spiked tail and slender snout featuring acidic emerald green scales and dripping venomous mist with main colors #4a148c and #ea80fc",
    svgType: "wyvern", colorPrimary: "#4a148c", colorSecondary: "#ea80fc", glowColor: "#e040fb"
  },
{
    id: 48, name: "Knucker de Sussex", title: "El Dragón del Pozo Inhondo", mythology: "Celta y Británica", type: "Wyrm", element: "Agua", danger: 3,
    habitat: "Pozos de Knuckerhole (Lyminster)", ability: "Mordedura Adormecedora y Emboscada Acuática", weakness: "Pastel Mágico de Pudín de Sal",
    scroll: "Habitaba en fuentes de agua subterránea llamadas 'Knuckerholes' que según los aldeanos no tenían fondo. Salía de noche a alimentarse de ganado hasta que un joven astuto lo venció ofreciéndole un pastel gigante.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #006064 and #80deea",
    svgType: "wyrm", colorPrimary: "#006064", colorSecondary: "#80deea", glowColor: "#00e5ff"
  },
{
    id: 49, name: "Dragón Blanco Sajón", title: "El Rival de las Nieblas", mythology: "Celta y Británica", type: "Dragón Europeo", element: "Hielo", danger: 4,
    habitat: "Colinas Chalk Cliffs de Dover", ability: "Aliento Glacial y Vuelo Nocturno", weakness: "El Fuego del Dragón Rojo",
    scroll: "En las profecías del mago Merlín, el Dragón Blanco luchaba contra el Dragón Rojo en un duelo subterráneo que sacudía los cimientos de Gran Bretaña.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring crystalline icy frost scales and glowing cyan frost aura with main colors #eceff1 and #90a4ae",
    svgType: "draco", colorPrimary: "#eceff1", colorSecondary: "#90a4ae", glowColor: "#ffffff"
  },
{
    id: 50, name: "Linton Worm", title: "El Enroscado de las Colinas Escocesas", mythology: "Celta y Británica", type: "Wyrm", element: "Tierra", danger: 4,
    habitat: "Colina de Linton Hill (Escocia)", ability: "Constricción de Roble y Peste de Aliento", weakness: "Lanzas con Punta de Turba Encendida",
    scroll: "Un dragón serpiente que se enroscaba alrededor de una colina escocesa, destruyendo las cosechas con su aliento venenoso. Fue derrotado por el héroe Laird de Lariston usando una lanza incandescente.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring subterranean mossy stone scales and earthy amber glow with main colors #3e2723 and #bcaaa4",
    svgType: "wyrm", colorPrimary: "#3e2723", colorSecondary: "#bcaaa4", glowColor: "#d7ccc8"
  },
{
    id: 51, name: "Lambton Worm", title: "La Serpiente del Río Wear", mythology: "Celta y Británica", type: "Wyrm", element: "Agua", danger: 4,
    habitat: "Condado de Durham", ability: "Regeneración de Cuerpo Cortado y Abrazo Asfixiante", weakness: "Armaduras con Espinas de Acero",
    scroll: "Cuenta la historia que este dragón podía volver a juntar sus partes si lo cortaban a la mitad. Lord Lambton tuvo que vestir una armadura llena de cuchillas afiladas y luchar dentro del río para vencerlo.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring magical elemental aura with main colors #1a237e and #8c9eff",
    svgType: "wyrm", colorPrimary: "#1a237e", colorSecondary: "#8c9eff", glowColor: "#536dfe"
  },
{
    id: 52, name: "Gurvelen", title: "El Dragón del Lago Celta", mythology: "Celta y Británica", type: "Shen", element: "Agua", danger: 3,
    habitat: "Lough Gur (Irlanda)", ability: "Encantamiento de Niebla Dorada", weakness: "Trébol de Cuatro Hojas",
    scroll: "Un dragón pacífico que salía a la superficie del lago durante las noches de luna llena para cantar melodías mágicas a las criaturas del bosque.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring magical elemental aura with main colors #1b5e20 and #a5d6a7",
    svgType: "shen", colorPrimary: "#1b5e20", colorSecondary: "#a5d6a7", glowColor: "#b2ff59"
  },
{
    id: 53, name: "Tarasque de Provenza", title: "El Monstruo de Caparazón de Espinas", mythology: "Europea Continental", type: "Otros", element: "Tierra", danger: 4,
    habitat: "Río Ródano", ability: "Caparazón de Tortuga Espinosa y Cola de Escorpión", weakness: "Cantos de Paz y Agua Bendita",
    scroll: "Poseía seis patas cortas pero potentes, un cuerpo protegido por un caparazón de espinas de tortuga y una cabeza de león con orejas de caballo. Fue amansado por Santa Marta con una oración suave.",
    physicalDescription: "majestic dragon featuring subterranean mossy stone scales and earthy amber glow with main colors #558b2f and #f57f17",
    svgType: "draco", colorPrimary: "#558b2f", colorSecondary: "#f57f17", glowColor: "#c0ca33"
  },
{
    id: 54, name: "Longwitton Dragon", title: "El Dragón Invisible de Northumberland", mythology: "Celta y Británica", type: "Wyvern", element: "Sombra", danger: 4,
    habitat: "Pozos de Longwitton", ability: "Invisibilidad Total y Aliento helado", weakness: "Ver su Propia Sombra reflejada",
    scroll: "Este dragón tenía la extraña habilidad de volverse completamente invisible a voluntad. Solo se podía saber dónde estaba por los rastros de hierba aplastada que dejaba al caminar.",
    physicalDescription: "two-legged agile winged dragon with spiked tail and slender snout featuring dark shadowed purple scales and abyssal twilight smoke with main colors #263238 and #78909c",
    svgType: "wyvern", colorPrimary: "#263238", colorSecondary: "#78909c", glowColor: "#b0bec5"
  },
{
    id: 55, name: "Cuélebre de Asturias", title: "El Guardián de los Tesoros Escondidos", mythology: "Celta y Británica", type: "Wyvern", element: "Fuego", danger: 4,
    habitat: "Cuevas del Mar Cantábrico", ability: "Escamas de Diamante Imparables y Ojos de Fuego", weakness: "Pan con Alfileres o Maza Encendida",
    scroll: "Dragón con alas de murciélago y escamas tan duras que ninguna espada de acero podía atravesarlas. Solo envejecía cuando se retiraba al fondo del mar a cuidar sus riquezas.",
    physicalDescription: "two-legged agile winged dragon with spiked tail and slender snout featuring blazing fiery scales and glowing ember accents with main colors #b71c1c and #ffb74d",
    svgType: "wyvern", colorPrimary: "#b71c1c", colorSecondary: "#ffb74d", glowColor: "#ff9100"
  },
{
    id: 56, name: "Zmey Gorynych", title: "El Dragón Tres Cabezas de las Montañas de Kiev", mythology: "Eslava y Este de Europa", type: "Hidra", element: "Fuego", danger: 5,
    habitat: "Montañas de Ceniza de Ucrania y Rusia", ability: "Fuego Tripartito y Garras de Cobre", weakness: "El Látigo Mágico del Héroe Dobrynya",
    scroll: "El dragón más famoso del folclore eslava. Posee tres cabezas que escupen fuego independientemente, alas de cuero negro y camina en dos patas potentes haciendo sonar sus garras de cobre.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring blazing fiery scales and glowing ember accents with main colors #3e2723 and #ff3d00",
    svgType: "hidra", colorPrimary: "#3e2723", colorSecondary: "#ff3d00", glowColor: "#ff6e40"
  },
{
    id: 57, name: "Balaur", title: "El Dragón de Siete Cabezas y Aletas Finas", mythology: "Eslava y Este de Europa", type: "Hidra", element: "Tormenta", danger: 4,
    habitat: "Valles del Danubio", ability: "Creación de Granizo y Huracanes", weakness: "La Espada Encantada de Făt-Frumos",
    scroll: "Un dragón gigantesco de la mitología rumana con siete cabezas. Cuando abría las siete bocas a la vez, creaba un arcoíris tóxico que atraía las tormentas y la niebla hacia los pueblos.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring magical elemental aura with main colors #1a237e and #00e5ff",
    svgType: "hidra", colorPrimary: "#1a237e", colorSecondary: "#00e5ff", glowColor: "#18ffff"
  },
{
    id: 58, name: "Zirnitra", title: "El Dragón Mágico de la Hechicería", mythology: "Eslava y Este de Europa", type: "Dragón Europeo", element: "Sombra", danger: 4,
    habitat: "Bosques Negros de Pomerania", ability: "Chispa de Magia Oscura e Ilusión", weakness: "Amuletos de Plata Pura",
    scroll: "Venerado por los antiguos hechiceros como el dios dragón de la magia. Sus escamas de color azul noche resplandecían con símbolos rúnicos antiguos al lanzar sus hechizos.",
    physicalDescription: "majestic classic four-legged dragon with midnight blue night scales, glowing neon purple ancient runic symbols shimmering across its wings, glowing violet eyes, and a horned head, Draco dragon with Sombra powers in Bosques Negros de Pomerania",
    svgType: "draco", colorPrimary: "#0d47a1", colorSecondary: "#ea80fc", glowColor: "#e040fb"
  },
{
    id: 59, name: "Smok Wawelski", title: "El Dragón de la Cueva del Vístula", mythology: "Eslava y Este de Europa", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Colina de Wawel (Cracovia)", ability: "Llamaradas Devoradoras y Terremoto de Paso", weakness: "Oveja Rellena de Azufre",
    scroll: "Habitaba en una cueva debajo del castillo de Wawel en Cracovia. Exigía tributos semanales de ganado hasta que el ingenioso zapatero Skuba le ofreció una piel de oveja cargada de azufre.",
    physicalDescription: "massive stocky four-legged classic dragon with thick jagged burnt-orange scales, glowing fiery nostrils, smoking jaws, and giant spiked tail standing near a dark cave, Draco dragon with Fuego powers in Colina de Wawel (Cracovia)",
    svgType: "draco", colorPrimary: "#bf360c", colorSecondary: "#ffab91", glowColor: "#ff6e40"
  },
{
    id: 60, name: "Zilant", title: "El Dragón Coronado de Kazán", mythology: "Oriental (Asia)", type: "Wyvern", element: "Fuego", danger: 3,
    habitat: "Lago Kaban (Rusia)", ability: "Corona del Rey Dragón y Vuelo Ágil", weakness: "Hierbas de Ajenjo Sagrado",
    scroll: "Un wyvern hermoso que ostenta una corona de oro sobre su cabeza y patas de gallo mágico. Es el símbolo oficial de la ciudad de Kazán en la actualidad.",
    physicalDescription: "elegant two-legged green wyvern dragon with golden rooster talons, a shiny imperial golden crown on its head, red bird-like wings, and a long curved tail, Wyvern dragon with Fuego powers in Lago Kaban (Rusia)",
    svgType: "wyvern", colorPrimary: "#1b5e20", colorSecondary: "#ffd700", glowColor: "#ffeb3b"
  },
{
    id: 61, name: "Kulshedra", title: "La Tormenta Encarnada", mythology: "Eslava y Este de Europa", type: "Hidra", element: "Agua", danger: 5,
    habitat: "Cavernas Subterráneas de Albania", ability: "Secado de Manantiales y Terremotos Fluviales", weakness: "El Dragón Benigno (Drangue)",
    scroll: "Una serpiente dragón hembra de nueve cabezas que causaba sequías terribles al tragarse el agua de los ríos. Su enemigo natural eran los Drangue, héroes legendarios con alas ocultas.",
    physicalDescription: "frightening nine-headed serpentine hydra dragon with dark violet and indigo scales, glowing purple eyes, and swirling torrential whirlpool water aura around its necks, Hidra dragon with Agua powers in Cavernas Subterráneas de Albania",
    svgType: "hidra", colorPrimary: "#311b92", colorSecondary: "#9575cd", glowColor: "#b388ff"
  },
{
    id: 62, name: "Illuyanka", title: "El Dragón del Imperio Hitita", mythology: "Eslava y Este de Europa", type: "Wyrm", element: "Tierra", danger: 4,
    habitat: "Montañas de Anatolia", ability: "Robo de Fuerza Vital y Emboscada Terrestre", weakness: "Banquetes de Miel y Cerveza",
    scroll: "Un temible dragón que logró derrotar al dios del trueno en su primer enfrentamiento. Solo pudo ser atrapado cuando fue invitado a un gran banquete donde comió tanto que no pudo volver a su cueva.",
    physicalDescription: "gigantic earth brown serpentine wyrm dragon with heavy subterranean rocky armor scales, sharp digging claws, and sleepy fat belly near a mountain feast, Wyrm dragon with Tierra powers in Montañas de Anatolia",
    svgType: "wyrm", colorPrimary: "#4e342e", colorSecondary: "#bcaaa4", glowColor: "#d7ccc8"
  },
{
    id: 63, name: "Yilbegän", title: "El Dragón Multi-Cabeza de Siberia", mythology: "Eslava y Este de Europa", type: "Otros", element: "Hielo", danger: 5,
    habitat: "Estepas Heladas de Siberia", ability: "Cabalgata de Tormentas de Nieve y 6 u 9 Cabezas", weakness: "Calor Intenso de Forja",
    scroll: "Monstruo legendario del folclore turco-siberiano, híbrido de ogro gigante y dragón de siete cabezas con ojos amarillos brillantes y dientes aserrados. Cabalga un buey negro descomunal coronado por noventa y nueve cuernos entrelazados a través de las estepas heladas.",
    physicalDescription: "massive hybrid giant dragon-ogre with seven distinct heads featuring glowing yellow eyes, jagged teeth, petrified wood scales, mounted on a gargantuan black ox with an impossible crown of ninety-nine intertwined horns across desolated frozen Siberian steppes, Hidra dragon with Hielo powers in Estepas Heladas de Siberia",
    svgType: "hidra", colorPrimary: "#006064", colorSecondary: "#e0f7fa", glowColor: "#80deea"
  },
{
    id: 64, name: "Chuvash Yish", title: "El Dragón Volador de Fuego", mythology: "Oriental (Asia)", type: "Shen", element: "Fuego", danger: 3,
    habitat: "Bosques del Volga", ability: "Transformación en Meteriorito y Lluvia de Chispas", weakness: "Oraciones de Abuelas del Pueblo",
    scroll: "Se creía que este dragón caía del cielo como un meteorito ardiente y se transformaba al tocar tierra en una persona apacible que ayudaba a las granjas.",
    physicalDescription: "gorgeous feathered serpent dragon with fiery orange and gold scales, bright red feathered wings, glowing flame tail trail like a shooting meteor, Ampithere dragon with Fuego powers in Bosques del Volga",
    svgType: "ampithere", colorPrimary: "#e65100", colorSecondary: "#ffe0b2", glowColor: "#ffb74d"
  },
{
    id: 65, name: "Huracán", title: "El Señor Corazón del Cielo", mythology: "Mesoamericana y Sudamericana", type: "Otros", element: "Tormenta", danger: 3,
    habitat: "Cielos Tormentosos y Ruinas de El Mirador", ability: "Ciclón de Jade Espiral, Sismos de Cola Única y Aliento de Lluvia Fertil", weakness: "La Calma Absoluta del Ojo Solar",
    scroll: "El colosal Huracán (el gran dragón de la mitología Maya y del Caribe) es el señor absoluto de los vientos giratorios, los terremotos y las tormentas tropicales. ¡De su nombre proviene directamente la palabra 'huracán'! Posee una anatomía única y giratoria de dos brazos asimétricos y una sola pata espiral. Su rostro es una máscara de piedra tallada en basalto con un místico ojo en forma de 'X' y cejas de fuego turquesa, exhalando la lluvia sagrada de jade.",
    physicalDescription: "unique asymmetrical green jade dragon with carved stone mask face, one large eye with X pupil and flaming turquoise eyebrows, exhaling spiral cloud mist tornado, Drakón dragon with Tormenta powers in Cielos Tormentosos",
    svgType: "draco", colorPrimary: "#00695c", colorSecondary: "#18ffff", glowColor: "#64ffda"
  },
{
    id: 66, name: "Tiamat", title: "La Diosa Primordial del Caos Caótico", mythology: "Mesopotámica y Medio Oriente", type: "Hidra", element: "Agua", danger: 5,
    habitat: "El Océano Primordial de Sal", ability: "Creación de Legiones de Monstruos y Olas Cosmicas", weakness: "Las Cuatro Flechas de Viento de Marduk",
    scroll: "En el mito babilónico Enūma Eliš, Tiamat es la dragona madre del océano salado. Encarnaba el caos antes de la creación del cielo y la tierra. Sus escamas contenían todas las tormentas del universo.",
    physicalDescription: "colossal five-headed oceanic dragon hydra with deep sapphire blue scales, glowing cyan eyes, swirling sea foam and salt water waves around its serpentine bodies, Hidra dragon with Agua powers in El Océano Primordial de Sal",
    svgType: "hidra", colorPrimary: "#0d47a1", colorSecondary: "#e040fb", glowColor: "#00e5ff"
  },
{
    id: 67, name: "Kur", title: "El Dragón del Inframundo de Sumeria", mythology: "Mesopotámica y Medio Oriente", type: "Drake", element: "Tierra", danger: 5,
    habitat: "El Abismo Vacío de Kur", ability: "Terremotos Primordiales y Absorción de Luz", weakness: "La Barca Dorada del Dios Enki",
    scroll: "Considerado el primer dragón registrado en las tabletas de arcilla cuneiforme de Sumeria. Habitaba entre el mundo de los vivos y el abismo sombrío.",
    physicalDescription: "ancient subterranean dragon with dark slate grey rocky scales, sharp digging claws, near sumerian cuneiform tablets, Drake dragon with Tierra powers in El Abismo Vacío de Kur",
    svgType: "draco", colorPrimary: "#263238", colorSecondary: "#78909c", glowColor: "#90a4ae"
  },
{
    id: 68, name: "Apep (Apofis)", title: "La Serpiente Devoradora del Sol", mythology: "Mesopotámica y Medio Oriente", type: "Wyrm", element: "Sombra", danger: 5,
    habitat: "Duat (El Inframundo Egipcio)", ability: "Eclipses Solares y Mirada Paralizante", weakness: "La Lanza del Dios Ra y el Gato Sagrado de Heliópolis",
    scroll: "Cada noche, el dios sol Ra viajaba en su barca solar por el inframundo. Apep intentaba tragar la barca para sumergir al mundo en la oscuridad eterna, pero Ra y Seth la defendían al amanecer.",
    physicalDescription: "colossal ancient Egyptian void serpent dragon with obsidian black scales, dark crimson belly, glowing red eyes, attempting to swallow the golden solar barge of Ra in the underworld, Wyrm dragon with Sombra powers in Duat (El Inframundo Egipcio)",
    svgType: "wyrm", colorPrimary: "#1b0000", colorSecondary: "#b71c1c", glowColor: "#ff1744"
  },
{
    id: 69, name: "Azhi Dahaka", title: "El Dragón de Tres Cabezas de Persia", mythology: "Mesopotámica y Medio Oriente", type: "Hidra", element: "Veneno", danger: 5,
    habitat: "Monte Damavand", ability: "Sangre Inundada de Lagartos Venenosos", weakness: "Atado con Cadenas Mágicas por Fereydun",
    scroll: "Un demonio dragón persa con tres bocas, seis ojos y tres cabezas de serpiente. Se decía que si le cortaban el cuello, de su sangre brotarían arañas y escorpiones venenosos.",
    physicalDescription: "monstrous Persian three-headed snake dragon hydra with dark ash grey and toxic green scales, six glowing yellow eyes, venomous green mist dripping from its three fanged jaws, Hidra dragon with Veneno powers in Monte Damavand",
    svgType: "hidra", colorPrimary: "#311b92", colorSecondary: "#b0bec5", glowColor: "#7c4dff"
  },
{
    id: 70, name: "Mušḫoššu (Sirrush)", title: "El Dragón Furioso de la Puerta de Ishtar", mythology: "Mesopotámica y Medio Oriente", type: "Dragón Europeo", element: "Luz", danger: 3,
    habitat: "Babilonia (Mesopotamia)", ability: "Cuerpo de León, Cuerno de Víbora y Patas de Águila", weakness: "Respeto a los Sacerdotes de Marduk",
    scroll: "El hermoso dragón tallado en azulejos de cerámica azul brillante en la Puerta de Ishtar en Babilonia. Posee patas delanteras de león, patas traseras de águila y un cuello largo de serpiente.",
    physicalDescription: "majestic mythical creature with long slender snake neck, lion front legs, eagle hind talons, sharp viper horn on its head, coated in lapis lazuli blue ceramic scales with golden accents, Draco dragon with Luz powers in Babilonia (Mesopotamia)",
    svgType: "draco", colorPrimary: "#0288d1", colorSecondary: "#ffd54f", glowColor: "#ffea00"
  },
{
    id: 71, name: "Gandarewa", title: "El Dragón de los Mares de Oro", mythology: "Mesopotámica y Medio Oriente", type: "Shen", element: "Agua", danger: 4,
    habitat: "Océano Vourukasha", ability: "Devorador de Barcos y Talón de Hierro", weakness: "El Héroe Garshasp",
    scroll: "Un monstruo marino con garras gigantescas que intentó devorar los tesoros mágicos del océano persa. Sus escamas doradas reflejaban la luz de las estrellas.",
    physicalDescription: "gigantic sea serpent dragon with glittering golden scales, flowing whiskers, giant sharp iron-like talons, emerging from starlit ocean waves near a wooden ship, Shen dragon with Agua powers in Océano Vourukasha",
    svgType: "shen", colorPrimary: "#f57f17", colorSecondary: "#ffe082", glowColor: "#ffeb3b"
  },
{
    id: 72, name: "Labbu", title: "El Dragón de Cien Leguas", mythology: "Mesopotámica y Medio Oriente", type: "Wyrm", element: "Tormenta", danger: 5,
    habitat: "Cielos Mesopotámicos", ability: "Longitud de 60 Leguas y Aliento Devastador", weakness: "El Rayo del Dios Tishpak",
    scroll: "Creado por el dios del cielo para castigar los excesos de la humanidad. Medía más de 300 kilómetros de largo y su aliento podía secar cosechas enteras en un solo día.",
    physicalDescription: "immense endless storm serpent wyrm soaring through thunderous Mesopotamian clouds, dark charcoal scales glowing with orange lightning embers and hurricane winds, Wyrm dragon with Tormenta powers in Cielos Mesopotámicos",
    svgType: "wyrm", colorPrimary: "#37474f", colorSecondary: "#ff7043", glowColor: "#ffab91"
  },
{
    id: 73, name: "Illuyanka Hatti", title: "El Dragón de las Rocas de Anatolia", mythology: "Mesopotámica y Medio Oriente", type: "Wyrm", element: "Tierra", danger: 3,
    habitat: "Cañones de Capadocia", ability: "Camuflaje de Piedra Caliza y Vuelo Bajo", weakness: "Agua Dulce de Lluvia",
    scroll: "Un dragón serpiente que habitaba en las chimeneas de fadas de Capadocia. Se mimetizaba con las rocas porosas hasta confundirse por completo con el paisaje.",
    physicalDescription: "ancient limestone earth serpent dragon blending into porous fairy chimney rocks and stone spires of Cappadocia, sandy brown scales, Wyrm dragon with Tierra powers in Cañones de Capadocia",
    svgType: "wyrm", colorPrimary: "#8d6e63", colorSecondary: "#d7ccc8", glowColor: "#efebe9"
  },
{
    id: 74, name: "Shedu Serpiente", title: "El Guardián Alado del Palacio", mythology: "Mesopotámica y Medio Oriente", type: "Ampithere", element: "Luz", danger: 3,
    habitat: "Palacio de Nínive", ability: "Protección Divina contra el Mal", weakness: "Destrucción de las Runas de la Entrada",
    scroll: "Un dragón protector tallado a la entrada de los palacios reales asirios para espantar a los espíritus malvados con su sola mirada severa.",
    physicalDescription: "majestic winged palace guardian dragon serpent with golden feathered wings, solar lion crown, sparkling golden scales, standing at ancient Assyrian gates, Ampithere dragon with Luz powers in Palacio de Nínive",
    svgType: "ampithere", colorPrimary: "#ffb300", colorSecondary: "#fff8e1", glowColor: "#ffe082"
  },
{
    id: 75, name: "Skrimsl", title: "El Dragón Astral de Islandia", mythology: "Nórdica y Germánica", type: "Wyrm", element: "Agua", danger: 3,
    habitat: "Lagos y Fiordos Helados de Islandia", ability: "Materialización Astral, Camuflaje de Niebla y Nado Telúrico", weakness: "Luz Solar Directa sin Niebla",
    scroll: "Los tomos secretos revelan que Skrimsl es un dragón de agua astral que vive en una dimensión paralela de energía, capaz de materializarse físicamente en nuestro mundo. ¡Fue avistado por navegantes en las heladas aguas de Islandia en 1860! Su cuerpo serpentino sin patas ni alas posee escamas plateadas y verde-azuladas con una cresta de suaves barbas plumosas que flotan como ensueños en la niebla glacial.",
    physicalDescription: "wingless serpentine water dragon with flat snake head, horny eye sockets, feathery chin fringes and spine crest, silvery blue scales in misty icy lake, Wyrm dragon with Agua powers in Lagos Helados de Islandia",
    svgType: "wyrm", colorPrimary: "#37474f", colorSecondary: "#80deea", glowColor: "#80d8ff"
  },
{
    id: 76, name: "Vritra", title: "El Dragón Bloqueador de los Ríos", mythology: "Hindú y Sudeste Asiático", type: "Wyrm", element: "Tierra", danger: 5,
    habitat: "Montañas del Indo", ability: "Absorción de Todas las Aguas del Mundo y Sequía", weakness: "El Rayo Vajra del Dios Indra",
    scroll: "En los textos del Rigveda, Vritra era el Asura dragón que encerró a los 99 ríos del mundo dentro de su vientre causando la primera gran sequía de la humanidad.",
    physicalDescription: "massive dark earth serpent wyrm with swollen belly trapping ninety-nine rivers, dry cracked brown scales, blocking mountain valley waterfalls, Wyrm dragon with Tierra powers in Montañas del Indo",
    svgType: "wyrm", colorPrimary: "#4e342e", colorSecondary: "#ff6f00", glowColor: "#ffab00"
  },
{
    id: 77, name: "Kaliya", title: "El Dragón Venenoso de Cinco Cabezas", mythology: "Hindú y Sudeste Asiático", type: "Hidra", element: "Veneno", danger: 4,
    habitat: "Río Yamuna (Vrindavan)", ability: "Agua Hierve con Veneno y Cinco Capuchas de Cobra", weakness: "La Danza Divina del Joven Krishna",
    scroll: "Una serpiente dragón de cinco cabezas que envenenaba las aguas del río Yamuna. Krishna subió a sus cabezas y ejecutó una danza cósmica hasta amansarla y pedirle que nadara pacíficamente hacia el océano.",
    physicalDescription: "fearsome five-headed cobra dragon hydra with dark emerald green hoods, glowing toxic yellow eyes, dripping luminous green venom into boiling river waters, Hidra dragon with Veneno powers in Río Yamuna (Vrindavan)",
    svgType: "hidra", colorPrimary: "#004d40", colorSecondary: "#a7ffeb", glowColor: "#18ffff"
  },
{
    id: 78, name: "Phaya Naga", title: "El Dragón del Río Mekong", mythology: "Hindú y Sudeste Asiático", type: "Shen", element: "Fuego", danger: 3,
    habitat: "Río Mekong", ability: "Bolas de Fuego del Mekong y Bendición Fluvial", weakness: "Falta de Respeto al Río",
    scroll: "Se cree que habita en las profundidades del río Mekong. Cada año a finales de octubre se observa el fenómeno de las 'Bolas de Fuego del Naga', luces incandescentes que suben desde el agua hacia el cielo.",
    physicalDescription: "glowing red and gold serpent dragon emerging from the Mekong River under full moon, spitting incandescent fireball orbs into the night sky, Shen dragon with Fuego powers in Río Mekong",
    svgType: "shen", colorPrimary: "#c62828", colorSecondary: "#ffe082", glowColor: "#ffd54f"
  },
{
    id: 79, name: "Bakunawa", title: "El Devorador de Lunas de Filipinas", mythology: "Hindú y Sudeste Asiático", type: "Wyrm", element: "Sombra", danger: 5,
    habitat: "Cielos de Visayas", ability: "Causa Eclipses Lunares Tragándose la Luna", weakness: "Ruido de Tambores y Ollas de Metal golpeadas",
    scroll: "Un gigantesco dragón marino de Filipinas con boca tan ancha como el horizonte. Se enamoró de las siete lunas del cielo y comenzó a comérselas una por una hasta que los pobladores aprendieron a hacer tanto ruido con ollas que las escupía de susto.",
    physicalDescription: "colossal deep violet sea serpent dragon with gaping wide jaw swallowing a glowing silver crescent moon in dark starry eclipse sky, Wyrm dragon with Sombra powers in Cielos de Visayas",
    svgType: "wyrm", colorPrimary: "#1a237e", colorSecondary: "#e040fb", glowColor: "#ea80fc"
  },
{
    id: 80, name: "Makara Dragón", title: "El Monstruo Acuático Vehículo de las Diosas", mythology: "Hindú y Sudeste Asiático", type: "Otros", element: "Agua", danger: 3,
    habitat: "Ríos Sagrados de India", ability: "Cuerpo de Cocodrilo, Trompa de Elefante y Cola de Dragón", weakness: "Redes Sagradas de Seda",
    scroll: "Criatura mítica que combina la cabeza de cocodrilo o dragón con cuerpo de pez y trompa de elefante. Es la montura sagrada de la diosa del río Ganga.",
    physicalDescription: "mystical aquatic chimera dragon with crocodile head, curled elephant trunk, scaly fish body, swimming gracefully in lotus river, Drake dragon with Agua powers in Ríos Sagrados de India",
    svgType: "draco", colorPrimary: "#00695c", colorSecondary: "#80cbc4", glowColor: "#80e27e"
  },
{
    id: 81, name: "Naga Vasuki", title: "El Rey Dragón de la Cuerda Cósmica", mythology: "Hindú y Sudeste Asiático", type: "Basilisco", element: "Luz", danger: 4,
    habitat: "Cuello del Dios Shiva", ability: "Batido del Océano de Leche y Resistencia Divina", weakness: "Garuḍa el Ave Celestial",
    scroll: "Utilizado por los devas y asuras como cuerda gigantesca alrededor del Monte Mandara para batir el océano de leche y extraer el elíxir de la inmortalidad.",
    physicalDescription: "golden radiant multi-hooded Naga serpent dragon coiled around a sacred cosmic mountain churning the ocean of milk, Shen dragon with Luz powers in Cuello del Dios Shiva",
    svgType: "shen", colorPrimary: "#ff6f00", colorSecondary: "#fff3e0", glowColor: "#ffe082"
  },
{
    id: 82, name: "Antaboga", title: "El Dragón de la Tierra de Bali", mythology: "Hindú y Sudeste Asiático", type: "Wyrm", element: "Tierra", danger: 3,
    habitat: "Profundidades del Monte Agung", ability: "Meditación Cósmica y Creación de la Tortuga Bedawang", weakness: "Ruidos Estridentes",
    scroll: "En la mitología de Bali, Antaboga creó a la tortuga gigante Bedawang sobre la cual descansa toda la isla de Bali.",
    physicalDescription: "majestic Balinese earth serpent dragon with ornate crown, brown mossy scales, wrapping around a giant cosmic turtle carrying the island of Bali, Wyrm dragon with Tierra powers in Profundidades del Monte Agung",
    svgType: "wyrm", colorPrimary: "#4e342e", colorSecondary: "#a1887f", glowColor: "#bcaaa4"
  },
{
    id: 83, name: "Taxaka", title: "El Dragón Rey de las Serpientes de Takshashila", mythology: "Hindú y Sudeste Asiático", type: "Wyrm", element: "Veneno", danger: 4,
    habitat: "Bosque de Khandava", ability: "Vuelo de Veneno y Transformación en Humano", weakness: "El Sacrificio de Serpientes de Janamejaya",
    scroll: "Mencionando en el Mahabharata como el astuto rey de las serpientes dragón que podía cambiar de forma a voluntad para proteger a su pueblo.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring acidic emerald green scales and dripping venomous mist with main colors #2e7d32 and #a5d6a7",
    svgType: "wyrm", colorPrimary: "#2e7d32", colorSecondary: "#a5d6a7", glowColor: "#c8e6c9"
  },
{
    id: 84, name: "Dragón de San Jorge", title: "El Terror de la Villa de Silene", mythology: "Europea Continental", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Laguna de Silene (Libia / Europa Medieval)", ability: "Aliento de Pestilencia y Escamas Afiladas", weakness: "La Lanza Asalon de San Jorge y la Cruz Bendita",
    scroll: "El dragón más célebre de los cuentos de caballería medievales. Aterrorizaba a un reino pidiendo raciones diarias hasta que el caballero San Jorge lo enfrentó para salvar a la princesa.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring blazing fiery scales and glowing ember accents with main colors #b71c1c and #ffe082",
    svgType: "draco", colorPrimary: "#b71c1c", colorSecondary: "#ffe082", glowColor: "#ffb74d"
  },
{
    id: 85, name: "Peluda de Maine", title: "La Bestia del Río Huisne", mythology: "Europea Continental", type: "Drake", element: "Agua", danger: 4,
    habitat: "Río Huisne (Francia)", ability: "Lanzamiento de Púas Venenosas y Maremoto de Río", weakness: "Corte Preciso en la Cola",
    scroll: "Un extraño dragón cubierto de pelaje verde lleno de púas venenosas del tamaño de jabalinas. Se refugiaba en el río y podía disparar sus púas como si fueran flechas.",
    physicalDescription: "majestic dragon featuring magical elemental aura with main colors #33691e and #76ff03",
    svgType: "draco", colorPrimary: "#33691e", colorSecondary: "#76ff03", glowColor: "#b2ff59"
  },
{
    id: 86, name: "Basilisco de Vilna", title: "El Rey de la Mirada Mortal", mythology: "Eslava y Este de Europa", type: "Basilisco", element: "Veneno", danger: 3,
    habitat: "Catacumbas de Vilna", ability: "Petrificación con la Mirada y Aliento Secante", weakness: "Un Espejo que Refleje su Propia Mirada",
    scroll: "Nacido de un huevo de gallina empollado por un sapo bajo una estrella de mal agüero. Podía petrificar a cualquier criatura viva con tan solo mirarla a los ojos.",
    physicalDescription: "majestic dragon featuring acidic emerald green scales and dripping venomous mist with main colors #1b5e20 and #eeff41",
    svgType: "basilisco", colorPrimary: "#1b5e20", colorSecondary: "#eeff41", glowColor: "#c0ca33"
  },
{
    id: 87, name: "Cocatriz de Hampshire", title: "El Dragón con Cabeza de Gallo", mythology: "Celta y Británica", type: "Otros", element: "Viento", danger: 4,
    habitat: "Pueblo de Wherwell", ability: "Canto Paralizante y Vuelo Ágil", weakness: "El Canto de un Gallo Real",
    scroll: "Un mítico ser con cuerpo de wyvern y cabeza de gallo de plumas incandescentes. Su solo aliento marchitaba las flores y hacía tropezar a los caballos de los caballeros.",
    physicalDescription: "majestic dragon featuring magical elemental aura with main colors #e65100 and #ffecb3",
    svgType: "basilisco", colorPrimary: "#e65100", colorSecondary: "#ffecb3", glowColor: "#ffe082"
  },
{
    id: 88, name: "Gárgola de Ruán", title: "El Origen Legendario del Mito Catedralicio", mythology: "Europea Continental", type: "Otros", element: "Fuego", danger: 2,
    habitat: "Pantanos de la Margen Izquierda del Río Sena (Normandía, Francia)", ability: "Llamaradas de Fuego Abrasador, Ráfagas Ciclónicas e Inundaciones", weakness: "Las Oraciones de San Román (Obispo de Ruán)",
    scroll: "La Gárgola de Ruán (conocida en francés como La Gargouille) es la criatura legendaria que dio origen al término y al mito arquitectónico de las gárgolas medievales. Según la tradición de Normandía del siglo VII, este feroz dragón acuático de cuello largo, alas de murciélago y garras afiladas habitaba los pantanos del río Sena. Asolaba las orillas exhalando llamaradas de fuego, provocando inundaciones destructivas, hundiendo embarcaciones y exigiendo sacrificios humanos anuales a los pobladores, hasta ser enfrentado por el obispo San Román.",
    physicalDescription: "monstrous aquatic serpent wyrm dragon with long slender neck, bat-like wings, sharp claws, exhaling blazing flames and water torrents near the Seine river swamps in Normandy, Wyrm dragon with Fuego powers in Río Sena (Francia)",
    svgType: "wyrm", colorPrimary: "#c62828", colorSecondary: "#ff8f00", glowColor: "#ff5252"
  },
{
    id: 89, name: "Herensuge Vasco", title: "El Dragón de Siete Cabezas de los Pirineos", mythology: "Europea Continental", type: "Hidra", element: "Fuego", danger: 5,
    habitat: "Cuevas de los Pirineos", ability: "Vuelo Estelar y Fuego Devorador", weakness: "Suena la Campana de San Miguel",
    scroll: "Legendario dragón vasco que volaba echando llamas por las siete bocas. Atraía a los viajeros cantando con un tono hipnótico entre los desfiladeros de la montaña.",
    physicalDescription: "multi-headed serpentine hydra dragon with multiple long necks featuring blazing fiery scales and glowing ember accents with main colors #4e342e and #ff3d00",
    svgType: "hidra", colorPrimary: "#4e342e", colorSecondary: "#ff3d00", glowColor: "#ff9100"
  },
{
    id: 90, name: "Bisu de Cerdeña", title: "El Dragón Somnoliento de las Torres", mythology: "Europea Continental", type: "Dragón Europeo", element: "Sombra", danger: 2,
    habitat: "Ruinas Nurágicas de Cerdeña", ability: "Canto de Dulces Sueños", weakness: "Ruidos Fuertes de Campanas",
    scroll: "Un pequeño dragón pacífico que vive en las antiguas torres Nuraghes de Cerdeña. Se pasa el día durmiendo al sol y soñando con estrellas de colores.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring dark shadowed purple scales and abyssal twilight smoke with main colors #4a148c and #d1c4e9",
    svgType: "draco", colorPrimary: "#4a148c", colorSecondary: "#d1c4e9", glowColor: "#b388ff"
  },
{
    id: 91, name: "Guivre de Borgoña", title: "El Dragón de los Viñedos Franceses", mythology: "Europea Continental", type: "Wyrm", element: "Veneno", danger: 3,
    habitat: "Bosques de Borgoña", ability: "Picadura Ácida y Vuelo Deslizado", weakness: "Ver a una Persona Sin Miedo",
    scroll: "Tenía un cuerpo largo de serpiente con alas de murciélago y cuernos de ciervo. Huía a toda velocidad si alguien lo miraba fijamente a los ojos sin mostrar una gota de temor.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring acidic emerald green scales and dripping venomous mist with main colors #1b5e20 and #ccff90",
    svgType: "wyrm", colorPrimary: "#1b5e20", colorSecondary: "#ccff90", glowColor: "#b2ff59"
  },
{
    id: 92, name: "Vouivre de los Alpes", title: "La Dama Dragón del Carbúnculo Rojo", mythology: "Europea Continental", type: "Wyvern", element: "Luz", danger: 3,
    habitat: "Lagos de los Alpes", ability: "La Gema Carbúnculo de la Frente (Resplandor Sol)", weakness: "Robar la Gema cuando se Baña en el Lago",
    scroll: "Lleva en la frente una piedra preciosa roja brillante llamada 'Carbúnculo' que ilumina las montañas en las noches frías. Cuando se baña en el agua cristalina del lago, deja la gema en la orilla.",
    physicalDescription: "two-legged agile winged dragon with spiked tail and slender snout featuring golden radiant celestial scales and brilliant solar sparks with main colors #b71c1c and #ffd700",
    svgType: "wyvern", colorPrimary: "#b71c1c", colorSecondary: "#ffd700", glowColor: "#ffff00"
  },
{
    id: 93, name: "Dragón de la Cueva de Drachenfels", title: "El Dragón del Río Rhin", mythology: "Nórdica y Germánica", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Roca de Drachenfels (Alemania)", ability: "Aliento de Fuego Volcánico y Escamas de Hierro", weakness: "La Espada Balmung del Héroe Sigfrido",
    scroll: "Vivía en una caverna sobre el río Rhin exigiendo ofrendas. El héroe Sigfrido lo derrotó y al bañarse en la sangre del dragón obtuvo una piel impenetrable.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring blazing fiery scales and glowing ember accents with main colors #212121 and #ff6f00",
    svgType: "draco", colorPrimary: "#212121", colorSecondary: "#ff6f00", glowColor: "#ff9100"
  },
{
    id: 94, name: "Dragón Astral del Cosmos", title: "El Tejedor de las Constelaciones", mythology: "Leyenda del Santuario", type: "Ampithere", element: "Luz", danger: 5,
    habitat: "Órbita de las Estrellas Fugaces", ability: "Polvo de Galaxias y Rayo Cósmico", weakness: "Ninguna conocida por los mortales",
    scroll: "Un dragón místico cuyas alas transparentes contienen mapas de galaxias lejanas. Vuela en el espacio profundo encendiendo las estrellas fugaces que piden los chicos por las noches.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring golden radiant celestial scales and brilliant solar sparks with main colors #4a148c and #00e5ff",
    svgType: "ampithere", colorPrimary: "#4a148c", colorSecondary: "#00e5ff", glowColor: "#18ffff"
  },
{
    id: 95, name: "Dragón de Magma Ancestral", title: "El Guardián del Núcleo de la Tierra", mythology: "Leyenda del Santuario", type: "Dragón Europeo", element: "Magma", danger: 5,
    habitat: "Núcleo Fundido del Planeta", ability: "Tsunami de Lava y Piel de Obsidiana Candente", weakness: "Hielo Estelar",
    scroll: "Duerma placidamente cerca del centro de la Tierra. Cuando bosteza, los volcanes del mundo expulsan chispas de luz dorada y piedras brillantes.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring volcano lava scales with glowing molten core with main colors #bf360c and #ffab91",
    svgType: "draco", colorPrimary: "#bf360c", colorSecondary: "#ffab91", glowColor: "#ff6e40"
  },
{
    id: 96, name: "Dragón de Cristal de Aurora", title: "El Reflejo de las Luces Polares", mythology: "Leyenda del Santuario", type: "Dragón Europeo", element: "Cristal", danger: 3,
    habitat: "Polos de Hielo Eterno", ability: "Prisma de Colores y Rayo Espejo", weakness: "Oscuridad Absoluta",
    scroll: "Sus escamas son cristales de cuarzo puro que descomponen la luz del sol en los hermosos colores violeta, verde y rosa de la aurora boreal.",
    physicalDescription: "four-legged classic dragon with majestic wings and scaled chest featuring magical elemental aura with main colors #00b0ff and #ea80fc",
    svgType: "draco", colorPrimary: "#00b0ff", colorSecondary: "#ea80fc", glowColor: "#e040fb"
  },
{
    id: 97, name: "Dragón del Abismo de Sombras", title: "El Caminante de los Sueños Secretos", mythology: "Leyenda del Santuario", type: "Wyrm", element: "Sombra", danger: 4,
    habitat: "Dimensión del Crepúsculo", ability: "Paso Incorpóreo y Esfumado de Humo", weakness: "Luz de la Linterna de Oro",
    scroll: "Se desliza suavemente por las sombras sin hacer ruido. Le gusta proteger los sueños de los niños ahuyentando las pesadillas con sus cuernos de plata.",
    physicalDescription: "wingless serpent-like dragon with coiled body and sharp claws featuring dark shadowed purple scales and abyssal twilight smoke with main colors #1a162b and #9c27b0",
    svgType: "wyrm", colorPrimary: "#1a162b", colorSecondary: "#9c27b0", glowColor: "#d500f9"
  },
{
    id: 98, name: "Dragón de la Tormenta Solar", title: "La Chispa del Sol Radiante", mythology: "Leyenda del Santuario", type: "Ampithere", element: "Tormenta", danger: 4,
    habitat: "Corona Solar", ability: "Llamarada Solar y Vuelo a Velocidad Luz", weakness: "Niebla de Cometa Helado",
    scroll: "Un dragón majestuoso compuesto de energía pura de helio e hidrógeno. Vuela alrededor del sol jugando con las llamaradas solares.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring electric crackling scales and sparkling lightning sparks with main colors #ff6f00 and #ffff00",
    svgType: "ampithere", colorPrimary: "#ff6f00", colorSecondary: "#ffff00", glowColor: "#ffff8d"
  },
{
    id: 99, name: "Dragón Fénix de Esmeralda", title: "El Renacido de las Hojas Ancestrales", mythology: "Leyenda del Santuario", type: "Ampithere", element: "Naturaleza", danger: 3,
    habitat: "Bosque Mágico Inexplorado", ability: "Brote de Plantas Gigantes y Renacimiento de Semilla", weakness: "Fuego de Carbón",
    scroll: "Cuando envejece, se convierte en un brote verde brillante de árbol del que nace un dragón joven y vibrante lleno de energía para renovar los bosques.",
    physicalDescription: "feathered-winged serpent dragon with vibrant crest featuring magical elemental aura with main colors #1b5e20 and #b2ff59",
    svgType: "ampithere", colorPrimary: "#1b5e20", colorSecondary: "#b2ff59", glowColor: "#69f0ae"
  },
{
    id: 100, name: "Dragón de Runas Antiguas", title: "El Sabio Eterno del Santuario", mythology: "Leyenda del Santuario", type: "Otros", element: "Luz", danger: 5,
    habitat: "Biblioteca Secreta del Santuario", ability: "Conocimiento de Todos los Idiomas y Aliento de Sabiduría", weakness: "El Olvido",
    scroll: "El dragón guardián supremo de esta enciclopedia. Lleva inscritas en sus escamas las historias de los más de 100 dragones del mundo y da la bienvenida a todos los jóvenes guardianes que desean aprender sobre la grandeza de los dragones.",
    physicalDescription: "oriental long serpentine dragon with flowing whiskers and floating crest featuring golden radiant celestial scales and brilliant solar sparks with main colors #ffd700 and #ffffff",
    svgType: "wyrm", colorPrimary: "#37474f", colorSecondary: "#ff7043", glowColor: "#ffab91"
  },
{
    id: 101, name: "Ignitharyon", title: "El Heredero del Fuego Venenoso", mythology: "Leyenda del Santuario", type: "Wyvern", element: "Fuego", danger: 5,
    habitat: "Cumbres Sagradas del Santuario", ability: "Llamaradas Verdes Venenosas, Fuego Sanador y Vuelo Ágil", weakness: "Ninguna",
    scroll: "Hijo de Magus Dragus y fiel compañero de aventuras. Ignitharyon es un wyvern invencible con escamas escarlata y doradas capaz de exhalar ráfagas de fuego verde de veneno abrasador sobre sus rivales, así como también un poderoso fuego sanador que restaura la vida y cura cualquier herida. Posee una fuerza legendaria tan colosal que es capaz de derrotar al mismísimo Leviatán en combate.",
    physicalDescription: "agile two-legged red and orange wyvern dragon with massive wings carrying a young rider with a glowing sword, exhaling brilliant green poisonous flames over coastal cliffs, Wyvern dragon with Fuego powers in Cumbres Sagradas del Santuario",
    svgType: "wyvern", colorPrimary: "#d84315", colorSecondary: "#76ff03", glowColor: "#b2ff59"
  },
{
    id: 102, name: "Zenith", title: "El Gemelo Impenetrable de las Cumbres", mythology: "Leyenda del Santuario", type: "Drake", element: "Fuego", danger: 3,
    habitat: "Prados y Colinas Místicas del Santuario", ability: "Visión Doble Coordinada, Aliento Dual de Fuego Violeta y Escamas Impenetrables", weakness: "Descoordinación entre Cabezas por Distracción",
    scroll: "Hijo menor de Magus Dragus y hermano de Ignitharyon y Traxes. Zenith es un singular dragón de dos cabezas y tipo Drake, cubierto por una armadura de escamas violetas totalmente impenetrables. Sus dos cabezas independientes le permiten vigilar en todas direcciones simultáneamente y lanzar ráfagas sincronizadas de fuego místico mientras corre a toda velocidad por las colinas.",
    physicalDescription: "colossal two-headed wingless drake dragon with deep violet scales, glowing eyes, Drake dragon with Fuego powers in Prados Místicos del Santuario",
    svgType: "draco", colorPrimary: "#6a1b9a", colorSecondary: "#e1bee7", glowColor: "#ea80fc"
  },
{
    id: 103, name: "Traxes", title: "El Señor de las Espirales Igneas", mythology: "Leyenda del Santuario", type: "Dragón Europeo", element: "Fuego", danger: 4,
    habitat: "Cráteres Volcánicos del Santuario", ability: "Vórtice Ciclónico de Fuego Espiral y Vuelo Dominante", weakness: "Flechazos Directos a las Alas y Hachazos de Obsidiana Sagrada",
    scroll: "Hijo de Magus Dragus y hermano de Ignitharyon y Zenith. Traxes es un majestuoso y feroz Dragón Europeo de imponentes escamas grises pizarra y amplias alas membranosas. Domina los cielos volcánicos desplegando su legendario ataque: ráfagas ciclónicas de fuego hirviente que descienden en espiral destructiva sobre el cráter de las cumbres.",
    physicalDescription: "colossal slate-grey European dragon with large wings hovering over volcanic crater exhaling swirling spiral vortex of crimson flames, Dragón Europeo dragon with Fuego powers in Cráteres Volcánicos",
    svgType: "draco", colorPrimary: "#455a64", colorSecondary: "#ff6d00", glowColor: "#ff9e80"
  }
];



  // 3. SVG GENERATORS

function renderSigilSVG(state, consonants, width = 600, height = 600) {
  const pCol = state.colorPrimary || "#ffd700";
  const sCol = state.colorSecondary || "#2a9d8f";
  const gCol = state.colorGlow || state.glowColor || "#e76f51";
  const element = state.element || "Rayo";
  const body = state.bodyType || "draco";
  const horn = state.hornStyle || "horns-classic";

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * 0.32;

  // Calculate Nodes for Consonants
  const N = consonants.length;
  const points = consonants.map((c, i) => {
    const angle = (i * 2 * Math.PI) / N - Math.PI / 2;
    return {
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
      char: c,
      angle: angle
    };
  });

  // Build Glyph Curve Path
  let glyphPath = "";
  if (points.length > 0) {
    glyphPath = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`;
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const midX = (prev.x + curr.x) / 2 + Math.cos(i) * 25;
      const midY = (prev.y + curr.y) / 2 + Math.sin(i) * 25;
      glyphPath += ` Q ${midX.toFixed(1)} ${midY.toFixed(1)}, ${curr.x.toFixed(1)} ${curr.y.toFixed(1)}`;
    }
    glyphPath += ` Z`;
  }

  // Sacred Geometry Background Lines (Pentáculo Sagrado de 5 Puntas)
  let pentaclePath = "";
  const rPent = radius * 1.08;
  const pentPoints = [];
  for (let k = 0; k < 5; k++) {
    const a = (k * 2 * Math.PI) / 5 - Math.PI / 2;
    pentPoints.push({
      x: cx + rPent * Math.cos(a),
      y: cy + rPent * Math.sin(a)
    });
  }
  const pentSeq = [pentPoints[0], pentPoints[2], pentPoints[4], pentPoints[1], pentPoints[3]];
  const pentPolyStr = pentSeq.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");

  pentaclePath = `
    <!-- Pentáculo de 5 puntas de fondo -->
    <circle cx="${cx}" cy="${cy}" r="${rPent.toFixed(1)}" stroke="${sCol}" stroke-width="2" fill="none" opacity="0.6" />
    <polygon points="${pentPolyStr}" stroke="${gCol}" stroke-width="1.8" fill="none" opacity="0.65" filter="url(#sigilGlowFilter)" />
  `;

  // Element Specific Aura Paths
  let auraSvg = "";

    if (element === "Rayo") {
    // 2 Rayos cruzados plenos (sin líneas punteadas), gruesos, más cortos y con clara forma de zig-zag
    const r1_p1 = `${(cx - radius * 0.75).toFixed(1)},${(cy - radius * 0.75).toFixed(1)}`;
    const r1_p2 = `${(cx - radius * 0.20).toFixed(1)},${(cy - radius * 0.40).toFixed(1)}`;
    const r1_p3 = `${(cx - radius * 0.35).toFixed(1)},${(cy - radius * 0.05).toFixed(1)}`;
    const r1_p4 = `${(cx + radius * 0.30).toFixed(1)},${(cy + radius * 0.20).toFixed(1)}`;
    const r1_p5 = `${(cx + radius * 0.10).toFixed(1)},${(cy + radius * 0.40).toFixed(1)}`;
    const r1_p6 = `${(cx + radius * 0.75).toFixed(1)},${(cy + radius * 0.75).toFixed(1)}`;
    const path1 = `M ${r1_p1} L ${r1_p2} L ${r1_p3} L ${r1_p4} L ${r1_p5} L ${r1_p6}`;

    const r2_p1 = `${(cx + radius * 0.75).toFixed(1)},${(cy - radius * 0.75).toFixed(1)}`;
    const r2_p2 = `${(cx + radius * 0.20).toFixed(1)},${(cy - radius * 0.40).toFixed(1)}`;
    const r2_p3 = `${(cx + radius * 0.35).toFixed(1)},${(cy - radius * 0.05).toFixed(1)}`;
    const r2_p4 = `${(cx - radius * 0.30).toFixed(1)},${(cy + radius * 0.20).toFixed(1)}`;
    const r2_p5 = `${(cx - radius * 0.10).toFixed(1)},${(cy + radius * 0.40).toFixed(1)}`;
    const r2_p6 = `${(cx - radius * 0.75).toFixed(1)},${(cy + radius * 0.75).toFixed(1)}`;
    const path2 = `M ${r2_p1} L ${r2_p2} L ${r2_p3} L ${r2_p4} L ${r2_p5} L ${r2_p6}`;

    auraSvg = `
      <path d="${path1}" stroke="${gCol}" stroke-width="6" fill="none" stroke-linecap="square" stroke-linejoin="miter" filter="url(#sigilGlowFilter)" />
      <path d="${path1}" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="square" stroke-linejoin="miter" />

      <path d="${path2}" stroke="${pCol}" stroke-width="5" fill="none" stroke-linecap="square" stroke-linejoin="miter" filter="url(#sigilGlowFilter)" />
      <path d="${path2}" stroke="#ffd700" stroke-width="2.5" fill="none" stroke-linecap="square" stroke-linejoin="miter" />
    `; } else if (element === "Fuego") {
    // 3 Triángulos picudos (Grande, Mediano, Pequeño) alineados por la base en el círculo principal
    const baseY = cy + radius * 0.90;
    
    // 1. Triángulo Grande (Outer)
    const x1_left = cx - radius * 0.85;
    const x1_right = cx + radius * 0.85;
    const y1_top = cy - radius * 1.45;
    
    // 2. Triángulo Mediano (Middle)
    const x2_left = cx - radius * 0.58;
    const x2_right = cx + radius * 0.58;
    const y2_top = cy - radius * 1.05;
    
    // 3. Triángulo Pequeño (Inner)
    const x3_left = cx - radius * 0.32;
    const x3_right = cx + radius * 0.32;
    const y3_top = cy - radius * 0.65;
    
    auraSvg = `
      <polygon points="${x1_left.toFixed(1)},${baseY.toFixed(1)} ${cx.toFixed(1)},${y1_top.toFixed(1)} ${x1_right.toFixed(1)},${baseY.toFixed(1)}" fill="none" stroke="${gCol}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round" filter="url(#sigilGlowFilter)" />
      <polygon points="${x2_left.toFixed(1)},${baseY.toFixed(1)} ${cx.toFixed(1)},${y2_top.toFixed(1)} ${x2_right.toFixed(1)},${baseY.toFixed(1)}" fill="rgba(255, 69, 0, 0.15)" stroke="${pCol}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />
      <polygon points="${x3_left.toFixed(1)},${baseY.toFixed(1)} ${cx.toFixed(1)},${y3_top.toFixed(1)} ${x3_right.toFixed(1)},${baseY.toFixed(1)}" fill="rgba(255, 215, 0, 0.25)" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />
      <line x1="${x1_left.toFixed(1)}" y1="${baseY.toFixed(1)}" x2="${x1_right.toFixed(1)}" y2="${baseY.toFixed(1)}" stroke="${pCol}" stroke-width="3" stroke-linecap="round" />
    `;   } else if (element === "Veneno") {
    // Línea serpenteante con ángulos suavizados (Catmull-Rom a Bezier cúbico suave)
    const getSmoothSerpentinePath = (rBase, amplitude, waves, nPts) => {
      let pts = [];
      for (let i = 0; i < nPts; i++) {
        const a = (i * 2 * Math.PI) / nPts;
        const rWave = rBase + Math.sin(a * waves) * amplitude;
        const x = cx + rWave * Math.cos(a);
        const y = cy + rWave * Math.sin(a);
        pts.push([x, y]);
      }
      let pathCmds = [`M ${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`];
      const len = pts.length;
      for (let i = 0; i < len; i++) {
        const p0 = pts[(i - 1 + len) % len];
        const p1 = pts[i];
        const p2 = pts[(i + 1) % len];
        const p3 = pts[(i + 2) % len];
        const cp1x = p1[0] + (p2[0] - p0[0]) / 6.0;
        const cp1y = p1[1] + (p2[1] - p0[1]) / 6.0;
        const cp2x = p2[0] - (p3[0] - p1[0]) / 6.0;
        const cp2y = p2[1] - (p3[1] - p1[1]) / 6.0;
        pathCmds.push(`C ${cp1x.toFixed(1)} ${cp1y.toFixed(1)}, ${cp2x.toFixed(1)} ${cp2y.toFixed(1)}, ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`);
      }
      return pathCmds.join(" ") + " Z";
    };

    const venomPath = getSmoothSerpentinePath(radius * 1.12, 12, 8, 48);
    const innerPath = getSmoothSerpentinePath(radius * 1.05, 8, 8, 48);

    auraSvg = `
      <path d="${venomPath}" stroke="${gCol}" stroke-width="3" fill="none" filter="url(#sigilGlowFilter)" stroke-linecap="round" stroke-linejoin="round" />
      <path d="${innerPath}" stroke="${pCol}" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" />
      <polygon points="${cx},${cy - radius - 28} ${cx - 10},${cy - radius - 14} ${cx + 10},${cy - radius - 14}" fill="${gCol}" stroke="${pCol}" stroke-width="1.5" />
      <circle cx="${cx - 4}" cy="${cy - radius - 18}" r="1.5" fill="#ffffff" />
      <circle cx="${cx + 4}" cy="${cy - radius - 18}" r="1.5" fill="#ffffff" />
    `; } else if (element === "Luz") {
    let sunburstPts = [];
    const nRays = 12;
    for (let i = 0; i < nRays * 2; i++) {
      const a = (i * Math.PI) / nRays - Math.PI / 2;
      const rCurr = (i % 2 === 0) ? (radius * 1.32) : (radius * 1.05);
      const x = cx + rCurr * Math.cos(a);
      const y = cy + rCurr * Math.sin(a);
      sunburstPts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    const sunburstPoly = sunburstPts.join(" ");

    auraSvg = `
      <polygon points="${sunburstPoly}" fill="none" stroke="${gCol}" stroke-width="2.5" filter="url(#sigilGlowFilter)" />
      <circle cx="${cx}" cy="${cy}" r="${radius * 1.05}" stroke="${pCol}" stroke-width="1.5" fill="none" />
      <circle cx="${cx}" cy="${cy}" r="${radius * 1.28}" stroke="${gCol}" stroke-width="1" opacity="0.6" fill="none" />
    `;
    } else if (element === "Hielo") {
    // 1. Cristales geométricos actuales (Superior e Inferior) + Anillo exterior
    const baseCrystals = `
      <polygon points="${cx},${cy-radius-25} ${cx+15},${cy-radius-10} ${cx},${cy-radius+5} ${cx-15},${cy-radius-10}" fill="rgba(144,224,239,0.25)" stroke="${gCol}" stroke-width="2" />
      <polygon points="${cx},${cy+radius-5} ${cx+15},${cy+radius+10} ${cx},${cy+radius+25} ${cx-15},${cy+radius+10}" fill="rgba(144,224,239,0.25)" stroke="${gCol}" stroke-width="2" />
      <circle cx="${cx}" cy="${cy}" r="${radius*1.15}" stroke="${gCol}" stroke-width="1.8" fill="none" filter="url(#sigilGlowFilter)" />
    `;

    // 2. Cristales coincidentes con las 5 puntas del pentáculo
    const rPent = radius * 1.08;
    let pentCrystals = [];
    for (let k = 0; k < 5; k++) {
      const a = (k * 2 * Math.PI) / 5 - Math.PI / 2;
      const px = cx + rPent * Math.cos(a);
      const py = cy + rPent * Math.sin(a);
      const pt_top = `${(px + 12 * Math.cos(a)).toFixed(1)},${(py + 12 * Math.sin(a)).toFixed(1)}`;
      const pt_bottom = `${(px - 8 * Math.cos(a)).toFixed(1)},${(py - 8 * Math.sin(a)).toFixed(1)}`;
      const pt_left = `${(px + 7 * Math.cos(a + Math.PI / 2)).toFixed(1)},${(py + 7 * Math.sin(a + Math.PI / 2)).toFixed(1)}`;
      const pt_right = `${(px + 7 * Math.cos(a - Math.PI / 2)).toFixed(1)},${(py + 7 * Math.sin(a - Math.PI / 2)).toFixed(1)}`;
      pentCrystals.push(`<polygon points="${pt_top} ${pt_right} ${pt_bottom} ${pt_left}" fill="rgba(255,255,255,0.4)" stroke="${gCol}" stroke-width="1.8" filter="url(#sigilGlowFilter)" />`);
    }

    // 3. Cristales en el centro del espacio entre puntas del pentáculo
    const rMid = radius * 0.88;
    let midCrystals = [];
    for (let k = 0; k < 5; k++) {
      const a = (k * 2 * Math.PI) / 5 - Math.PI / 2 + Math.PI / 5;
      const mx = cx + rMid * Math.cos(a);
      const my = cy + rMid * Math.sin(a);
      const pt_top = `${(mx + 9 * Math.cos(a)).toFixed(1)},${(my + 9 * Math.sin(a)).toFixed(1)}`;
      const pt_bottom = `${(mx - 6 * Math.cos(a)).toFixed(1)},${(my - 6 * Math.sin(a)).toFixed(1)}`;
      const pt_left = `${(mx + 5 * Math.cos(a + Math.PI / 2)).toFixed(1)},${(my + 5 * Math.sin(a + Math.PI / 2)).toFixed(1)}`;
      const pt_right = `${(mx + 5 * Math.cos(a - Math.PI / 2)).toFixed(1)},${(my + 5 * Math.sin(a - Math.PI / 2)).toFixed(1)}`;
      midCrystals.push(`<polygon points="${pt_top} ${pt_right} ${pt_bottom} ${pt_left}" fill="rgba(0,119,182,0.3)" stroke="#ffffff" stroke-width="1.5" />`);
    }

    auraSvg = `
      ${baseCrystals}
      ${pentCrystals.join("")}
      ${midCrystals.join("")}
    `; } else if (element === "Sombra") {
    auraSvg = `
      <circle cx="${cx}" cy="${cy}" r="${radius*1.25}" stroke="${gCol}" stroke-width="2" fill="none" filter="url(#sigilGlowFilter)" />
      <circle cx="${cx}" cy="${cy}" r="${radius*1.15}" stroke="${pCol}" stroke-width="1" fill="none" />
    `;
  } else {
    auraSvg = `
      <circle cx="${cx}" cy="${cy}" r="${radius*1.18}" stroke="${gCol}" stroke-width="1.5" fill="none" />
    `;
  }

  // Horn Flourishes (Centered at Sigil Core cx, cy)
  let hornSvg = "";
  if (horn === "horns-classic") {
    // 1. Cuernos Clásicos (Draco Clásico): Más chicos, sin relleno (fill="none")
    const leftHorn = `M ${(cx - radius * 0.55).toFixed(1)} ${(cy + radius * 0.40).toFixed(1)} C ${(cx - radius * 0.95).toFixed(1)} ${(cy + radius * 0.20).toFixed(1)} ${(cx - radius * 1.00).toFixed(1)} ${(cy - radius * 0.25).toFixed(1)} ${(cx - radius * 0.35).toFixed(1)} ${(cy - radius * 0.75).toFixed(1)} C ${(cx - radius * 0.55).toFixed(1)} ${(cy - radius * 0.42).toFixed(1)} ${(cx - radius * 0.48).toFixed(1)} ${(cy - radius * 0.03).toFixed(1)} ${(cx - radius * 0.22).toFixed(1)} ${(cy + radius * 0.35).toFixed(1)} Q ${(cx - radius * 0.38).toFixed(1)} ${(cy + radius * 0.43).toFixed(1)} ${(cx - radius * 0.55).toFixed(1)} ${(cy + radius * 0.40).toFixed(1)} Z`;
    const rightHorn = `M ${(cx + radius * 0.55).toFixed(1)} ${(cy + radius * 0.40).toFixed(1)} C ${(cx + radius * 0.95).toFixed(1)} ${(cy + radius * 0.20).toFixed(1)} ${(cx + radius * 1.00).toFixed(1)} ${(cy - radius * 0.25).toFixed(1)} ${(cx + radius * 0.35).toFixed(1)} ${(cy - radius * 0.75).toFixed(1)} C ${(cx + radius * 0.55).toFixed(1)} ${(cy - radius * 0.42).toFixed(1)} ${(cx + radius * 0.48).toFixed(1)} ${(cy - radius * 0.03).toFixed(1)} ${(cx + radius * 0.22).toFixed(1)} ${(cy + radius * 0.35).toFixed(1)} Q ${(cx + radius * 0.38).toFixed(1)} ${(cy + radius * 0.43).toFixed(1)} ${(cx + radius * 0.55).toFixed(1)} ${(cy + radius * 0.40).toFixed(1)} Z`;

    hornSvg = `
      <!-- Cuernos Clásicos: Más chicos y sin relleno -->
      <path d="${leftHorn}" stroke="${pCol}" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
      <path d="${rightHorn}" stroke="${pCol}" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
    `;
      } else if (horn === "horns-ram") {
    // 2. Cuernos de Carnero Grandes: Llegan hasta la periferia del círculo y se tocan al centro
    const makeSpiralPath = (centerX, isRight = false) => {
      let pts = [];
      const nSteps = 60;
      const maxTurns = 2.4 * 2 * Math.PI;
      for (let step = 0; step <= nSteps; step++) {
        const t = (step / nSteps) * maxTurns;
        const r = 5 + t * 4.4;
        const angle = isRight ? -t : t;
        const x = centerX + r * Math.cos(angle + Math.PI / 2);
        const y = cy - 10 + r * Math.sin(angle + Math.PI / 2);
        pts.push([x, y]);
      }
      let cmd = [`M ${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`];
      for (let p of pts.slice(1)) {
        cmd.push(`L ${p[0].toFixed(1)} ${p[1].toFixed(1)}`);
      }
      return cmd.join(" ");
    };

    const ramLeft = makeSpiralPath(cx - radius * 0.48, false);
    const ramRight = makeSpiralPath(cx + radius * 0.48, true);

    hornSvg = `
      <!-- Cuernos de Carnero Grandes: Hasta la periferia del círculo -->
      <path d="${ramLeft}" stroke="${pCol}" stroke-width="3.8" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
      <path d="${ramRight}" stroke="${pCol}" stroke-width="3.8" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
    `; } else if (horn === "horns-crown") {
    // 3. Corona de Espinas: De lado a lado del círculo, más grande, sin relleno, 5 puntas
    const rX = radius * 0.98;
    const crownPts = `${(cx - rX).toFixed(1)},${(cy + 10).toFixed(1)} ${(cx - rX).toFixed(1)},${(cy - 35).toFixed(1)} ${(cx - radius * 0.7).toFixed(1)},${(cy - 5).toFixed(1)} ${(cx - radius * 0.48).toFixed(1)},${(cy - 58).toFixed(1)} ${(cx - radius * 0.24).toFixed(1)},${(cy - 12).toFixed(1)} ${cx.toFixed(1)},${(cy - 78).toFixed(1)} ${(cx + radius * 0.24).toFixed(1)},${(cy - 12).toFixed(1)} ${(cx + radius * 0.48).toFixed(1)},${(cy - 58).toFixed(1)} ${(cx + radius * 0.7).toFixed(1)},${(cy - 5).toFixed(1)} ${(cx + rX).toFixed(1)},${(cy - 35).toFixed(1)} ${(cx + rX).toFixed(1)},${(cy + 10).toFixed(1)}`;
    hornSvg = `
      <path d="M ${crownPts.replace(/ /g, " L ")} Q ${cx.toFixed(1)} ${(cy + 35).toFixed(1)} ${(cx - rX).toFixed(1)} ${(cy + 10).toFixed(1)} Z" stroke="${pCol}" stroke-width="3" fill="none" stroke-linejoin="round" stroke-linecap="round" filter="url(#sigilGlowFilter)" />
    `;
  } else if (horn === "horns-unicorn") {
    // 4. Cuerno Único de Cristal: De la base al tope del círculo, sin sobresalir, sin rellenar
    const yBase = cy + radius;
    const yTop = cy - radius;
    hornSvg = `
      <polygon points="${(cx - 15).toFixed(1)},${yBase.toFixed(1)} ${cx.toFixed(1)},${yTop.toFixed(1)} ${(cx + 15).toFixed(1)},${yBase.toFixed(1)}" fill="none" stroke="${pCol}" stroke-width="3" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
      <line x1="${cx.toFixed(1)}" y1="${yBase.toFixed(1)}" x2="${cx.toFixed(1)}" y2="${yTop.toFixed(1)}" stroke="${gCol}" stroke-width="1.8" />
      <line x1="${(cx - 12).toFixed(1)}" y1="${(cy + radius * 0.5).toFixed(1)}" x2="${(cx + 12).toFixed(1)}" y2="${(cy + radius * 0.35).toFixed(1)}" stroke="${gCol}" stroke-width="1.8" />
      <line x1="${(cx - 9).toFixed(1)}" y1="${cy.toFixed(1)}" x2="${(cx + 9).toFixed(1)}" y2="${(cy - radius * 0.15).toFixed(1)}" stroke="${gCol}" stroke-width="1.8" />
      <line x1="${(cx - 6).toFixed(1)}" y1="${(cy - radius * 0.4).toFixed(1)}" x2="${(cx + 6).toFixed(1)}" y2="${(cy - radius * 0.55).toFixed(1)}" stroke="${gCol}" stroke-width="1.8" />
    `;
  }

  // Anatomical Outer Shape
  let bodyOutline = "";
  if (body === "draco") {
    // Draco Clásico: Triángulo de escudo apuntando hacia abajo (contrario a cresta triangular)
    bodyOutline = `
      <polygon points="${(cx - radius - 10).toFixed(1)},${(cy - radius * 0.7).toFixed(1)} ${(cx + radius + 10).toFixed(1)},${(cy - radius * 0.7).toFixed(1)} ${cx.toFixed(1)},${(cy + radius + 15).toFixed(1)}" stroke="${pCol}" stroke-width="2.5" fill="none" stroke-linejoin="round" />
    `;
    } else if (body === "shen") {
    bodyOutline = `
      <!-- Primary Centered Outer Ring -->
      <circle cx="${cx}" cy="${cy}" r="${radius}" stroke="${pCol}" stroke-width="4.2" fill="none" />
      <!-- Centered Oriental Shen Serpentine Wave (Yin-Yang / Infinity S-curves con líneas más gruesas) -->
      <path d="M ${cx} ${cy - radius} C ${cx + radius * 0.7} ${cy - radius * 0.5} ${cx - radius * 0.7} ${cy + radius * 0.5} ${cx} ${cy + radius}" stroke="${pCol}" stroke-width="3.8" fill="none" filter="url(#sigilGlowFilter)" />
      <path d="M ${cx} ${cy - radius} C ${cx - radius * 0.7} ${cy - radius * 0.5} ${cx + radius * 0.7} ${cy + radius * 0.5} ${cx} ${cy + radius}" stroke="${gCol}" stroke-width="3.5" fill="none" filter="url(#sigilGlowFilter)" />
      <!-- Sacred Central Shen Core Ring -->
      <circle cx="${cx}" cy="${cy}" r="${radius * 0.45}" stroke="${pCol}" stroke-width="3.0" fill="none" />
    `; } else if (body === "wyvern") {
    bodyOutline = `
      <polygon points="${cx},${cy-radius-15} ${cx+radius+10},${cy+radius*0.7} ${cx-radius-10},${cy+radius*0.7}" stroke="${pCol}" stroke-width="2.5" fill="none" />
    `;
  } else if (body === "hidra") {
    bodyOutline = `
      <circle cx="${cx}" cy="${cy-25}" r="${radius*0.75}" stroke="${pCol}" stroke-width="2" fill="none" />
      <circle cx="${cx-35}" cy="${cy+25}" r="${radius*0.75}" stroke="${pCol}" stroke-width="2" fill="none" />
      <circle cx="${cx+35}" cy="${cy+25}" r="${radius*0.75}" stroke="${pCol}" stroke-width="2" fill="none" />
    `;
  } else if (body === "ampithere") {
    bodyOutline = `
      <path d="M ${cx-radius-20} ${cy} Q ${cx} ${cy-radius-30} ${cx+radius+20} ${cy} Q ${cx} ${cy+radius+30} ${cx-radius-20} ${cy}" stroke="${pCol}" stroke-width="2.5" fill="none" />
    `;
  } else {
    bodyOutline = `<circle cx="${cx}" cy="${cy}" r="${radius}" stroke="${pCol}" stroke-width="2.5" fill="none" />`;
  }

  return `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <filter id="sigilGlowFilter" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <!-- Background Circle Shield -->
      <circle cx="${cx}" cy="${cy}" r="${radius*1.22}" stroke="rgba(255,215,0,0.3)" stroke-width="1.5" fill="rgba(0,0,0,0.25)" />

      <!-- Sacred Geometry Pentacle Background -->
      ${pentaclePath}

      <!-- Elemental Aura -->
      ${auraSvg}

      <!-- Anatomical Outer Frame -->
      ${bodyOutline}

      <!-- Central Horns -->
      ${hornSvg}

      <!-- Consonant Sigil Glyph Curve -->
      <path d="${glyphPath}" stroke="${pCol}" stroke-width="3.5" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#sigilGlowFilter)" />
      <path d="${glyphPath}" stroke="#ffffff" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round" />

      <!-- Consonant Node Points & Runes -->
      ${points.map(pt => `
        <circle cx="${pt.x.toFixed(1)}" cy="${pt.y.toFixed(1)}" r="10" fill="rgba(10,14,23,0.9)" stroke="${gCol}" stroke-width="2" />
        <circle cx="${pt.x.toFixed(1)}" cy="${pt.y.toFixed(1)}" r="4" fill="${pCol}" />
        <text x="${pt.x.toFixed(1)}" y="${pt.y > cy ? pt.y + 24 : pt.y - 14}" fill="#ffd700" font-size="14" font-weight="bold" font-family="serif" text-anchor="middle">${pt.char}</text>
      `).join("")}

      <!-- Center Alchemical Seal -->
      <circle cx="${cx}" cy="${cy}" r="6" fill="#ffd700" stroke="${pCol}" stroke-width="1.5" />
    </svg>
  `;
}



function getDragonArtworkSrc(dragon) {
  if (dragon && dragon.id <= 200) {
    const v = (dragon.id === 13) ? '?v=13_v2' : (dragon.id === 45) ? '?v=45_v2' : (dragon.id === 18) ? '?v=18_v2' : (dragon.id === 11) ? '?v=11_v2' : (dragon.id === 3) ? '?v=3_v2' : (dragon.id === 20) ? '?v=20_v2' : (dragon.id === 10) ? '?v=10_v2' : (dragon.id === 2) ? '?v=2_v2' : (dragon.id === 46) ? '?v=46_v2' : (dragon.id === 65) ? '?v=65_v2' : (dragon.id === 67) ? '?v=67_v2' : (dragon.id === 75) ? '?v=75_v2' : '';
    return `/assets/dragons/dragon_${dragon.id}.webp${v}`;
  }
  return null;
}

function renderDragonSVG(dragon, width = 300, height = 240) {
  const { svgType = "draco", colorPrimary = "#c8553d", colorSecondary = "#e9c46a", glowColor = "#2a9d8f", id = 1, name = "" } = dragon;

  const outline = "#12111c";
  
  const palette = [
    "#e9c46a", // Mustard
    "#2a9d8f", // Teal
    "#c8553d", // Rust
    "#b23a3a", // Faded Red
    "#d4a373", // Pale Clay
    "#264653"  // Deep Slate
  ];

  const seed1 = (id * 17) % 5;
  const seed2 = (id * 31) % 4;
  const seed3 = (id * 47) % 3;

  const bodyColor = colorPrimary || palette[id % palette.length];
  const accentColor = colorSecondary || palette[(id + 2) % palette.length];
  const secondaryAccent = palette[(id + 4) % palette.length];

  let paths = "";

  let headPolygon = "";
  if (seed1 === 0) headPolygon = "210,80 295,40 280,95 230,115 200,90";
  else if (seed1 === 1) headPolygon = "215,70 285,55 295,95 220,110 205,85";
  else if (seed1 === 2) headPolygon = "205,85 275,35 290,75 240,110 195,95";
  else if (seed1 === 3) headPolygon = "220,75 300,60 270,105 225,115 210,95";
  else headPolygon = "210,80 280,45 285,90 235,110 205,90";

  let eyeMarkup = "";
  if (seed2 === 0) {
    eyeMarkup = `
      <polygon points="238,55 258,52 260,70 240,73" fill="#ffffff" stroke="${outline}" stroke-width="3" />
      <rect x="248" y="58" width="5" height="10" fill="#12111c" />
      <path d="M 234 50 L 264 45" stroke="${outline}" stroke-width="5" stroke-linecap="square" />
    `;
  } else if (seed2 === 1) {
    eyeMarkup = `
      <polygon points="232,50 252,48 254,68 234,70" fill="#ffffff" stroke="${outline}" stroke-width="3" />
      <rect x="240" y="53" width="7" height="12" fill="#12111c" />
      <polygon points="258,45 272,42 274,58 260,60" fill="#ffffff" stroke="${outline}" stroke-width="3" />
      <rect x="264" y="47" width="4" height="8" fill="#12111c" />
      <path d="M 228 42 L 278 35" stroke="${outline}" stroke-width="5" stroke-linecap="square" />
    `;
  } else {
    eyeMarkup = `
      <polygon points="235,58 260,54 262,70 237,73" fill="#ffffff" stroke="${outline}" stroke-width="3" />
      <line x1="235" y1="63" x2="260" y2="59" stroke="${outline}" stroke-width="4" />
      <rect x="246" y="64" width="6" height="5" fill="#12111c" />
    `;
  }

  let toothMarkup = "";
  if (seed3 === 0) toothMarkup = `<polygon points="265,95 273,112 280,93" fill="#ffffff" stroke="${outline}" stroke-width="3" />`;
  else if (seed3 === 1) toothMarkup = `<polygon points="250,98 256,114 262,96" fill="#ffffff" stroke="${outline}" stroke-width="3" /><polygon points="270,92 276,108 282,90" fill="#ffffff" stroke="${outline}" stroke-width="3" />`;
  else toothMarkup = `<polygon points="272,90 282,106 288,88" fill="#ffffff" stroke="${outline}" stroke-width="3" />`;

  switch (svgType) {
    case "wyrm":
      paths = `
        <polygon points="40,210 180,225 260,205 120,200" fill="rgba(18, 17, 28, 0.3)" />
        <path d="M 35 185 L 85 220 L 145 170 L 195 195 L 245 130 L 225 75 L 155 45 L 115 85 L 135 125 L 85 145 Z" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <path d="M 45 190 L 85 215 L 140 175 L 190 190 L 235 135" fill="none" stroke="${accentColor}" stroke-width="10" stroke-linecap="square" />
        <path d="M 45 190 L 85 215 L 140 175 L 190 190 L 235 135" fill="none" stroke="${outline}" stroke-width="3" stroke-dasharray="10,8" />
        <polygon points="${headPolygon}" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="225,65 245,15 240,60" fill="${accentColor}" stroke="${outline}" stroke-width="4" />
        <polygon points="238,55 275,20 255,62" fill="${secondaryAccent}" stroke="${outline}" stroke-width="4" />
        ${eyeMarkup}
        <path d="M 235 105 L 285 90" stroke="${outline}" stroke-width="5" />
        ${toothMarkup}
        <polygon points="280,85 315,75 305,95 330,85 295,105" fill="${secondaryAccent}" stroke="${outline}" stroke-width="3" />
      `;
      break;

    case "shen":
      paths = `
        <polygon points="30,195 80,180 140,210 210,185 280,210 230,225 100,220" fill="${secondaryAccent}" opacity="0.4" stroke="${outline}" stroke-width="3" />
        <path d="M 30 160 L 80 50 L 130 200 L 180 110 L 230 170 L 260 85" fill="none" stroke="${bodyColor}" stroke-width="34" stroke-linecap="square" stroke-linejoin="miter" />
        <path d="M 30 160 L 80 50 L 130 200 L 180 110 L 230 170 L 260 85" fill="none" stroke="${outline}" stroke-width="6" stroke-linecap="square" stroke-linejoin="miter" />
        <polygon points="${headPolygon}" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="285,45 320,55 295,75" fill="${accentColor}" stroke="${outline}" stroke-width="4" />
        ${eyeMarkup}
        <path d="M 290 75 L 325 80 L 310 115 M 285 85 L 335 105 L 315 135" fill="none" stroke="${accentColor}" stroke-width="5" stroke-linecap="square" />
        <path d="M 290 75 L 325 80 L 310 115 M 285 85 L 335 105 L 315 135" fill="none" stroke="${outline}" stroke-width="2" stroke-linecap="square" />
      `;
      break;

    case "hidra":
      paths = `
        <polygon points="60,215 150,230 240,215 150,200" fill="rgba(18, 17, 28, 0.3)" />
        <polygon points="80,200 150,230 220,200 180,150 120,150" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <path d="M 100 150 L 55 90 L 70 45 L 105 60 L 125 150" fill="${bodyColor}" stroke="${outline}" stroke-width="5" stroke-linejoin="miter" />
        <polygon points="50,45 85,25 95,55 60,65" fill="${accentColor}" stroke="${outline}" stroke-width="4" />
        <rect x="62" y="38" width="10" height="10" fill="#ffffff" stroke="${outline}" stroke-width="2" />
        <rect x="65" y="40" width="4" height="6" fill="#12111c" />
        <path d="M 52 32 L 78 30" stroke="${outline}" stroke-width="4" />
        <path d="M 135 150 L 140 75 L 155 25 L 180 40 L 165 150" fill="${bodyColor}" stroke="${outline}" stroke-width="5" stroke-linejoin="miter" />
        <polygon points="140,25 185,15 175,50 135,45" fill="${bodyColor}" stroke="${outline}" stroke-width="4" />
        <polygon points="145,26 160,22 162,36 147,38" fill="#ffffff" stroke="${outline}" stroke-width="2" /><rect x="152" y="27" width="4" height="6" fill="#12111c" />
        <polygon points="163,22 176,18 178,32 165,34" fill="#ffffff" stroke="${outline}" stroke-width="2" /><rect x="170" y="23" width="4" height="6" fill="#12111c" />
        <path d="M 138 16 L 182 12" stroke="${outline}" stroke-width="4" />
        <path d="M 175 150 L 235 90 L 215 50 L 195 65 L 160 150" fill="${bodyColor}" stroke="${outline}" stroke-width="5" stroke-linejoin="miter" />
        <polygon points="205,50 245,35 235,70 195,75" fill="${secondaryAccent}" stroke="${outline}" stroke-width="4" />
        <rect x="210" y="52" width="10" height="10" fill="#ffffff" stroke="${outline}" stroke-width="2" />
        <rect x="213" y="54" width="4" height="6" fill="#12111c" />
        <path d="M 202 44 L 230 40" stroke="${outline}" stroke-width="4" />
      `;
      break;

    case "ampithere":
      paths = `
        <polygon points="50,215 150,225 250,215 150,200" fill="rgba(18, 17, 28, 0.3)" />
        <polygon points="140,120 40,25 15,80 115 135" fill="${accentColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="160,120 260,25 285,80 185 135" fill="${accentColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <path d="M 115 110 L 35 45 M 105 120 L 45 75 M 185 110 L 265 45 M 195 120 L 255 75" stroke="${outline}" stroke-width="3" stroke-linecap="square" />
        <path d="M 95 175 L 150 215 L 205 175 L 215 130 L 150 100 L 90 130 Z" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <path d="M 140 100 L 140 45 L 180 50 L 165 115 Z" fill="${bodyColor}" stroke="${outline}" stroke-width="5" />
        <polygon points="180,50 225,55 175,75" fill="${secondaryAccent}" stroke="${outline}" stroke-width="4" />
        ${eyeMarkup}
      `;
      break;

    case "wyvern":
    case "basilisco":
    case "draco":
    default:
      paths = `
        <polygon points="40,215 150,230 260,215 150,195" fill="rgba(18, 17, 28, 0.3)" />
        <polygon points="130,110 40,15 10,75 115,130" fill="${accentColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="160,110 250,15 285,75 175,130" fill="${accentColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <path d="M 105 175 L 35 205 L 15 165 L 50 155" fill="none" stroke="${bodyColor}" stroke-width="24" stroke-linecap="square" stroke-linejoin="miter" />
        <path d="M 105 175 L 35 205 L 15 165 L 50 155" fill="none" stroke="${outline}" stroke-width="6" stroke-linecap="square" stroke-linejoin="miter" />
        <polygon points="15,165 -5,145 5,185" fill="${secondaryAccent}" stroke="${outline}" stroke-width="4" />
        <polygon points="95,165 150,210 200,165 210,120 150,100 90,120" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="120,130 150,185 180,130 150,110" fill="${accentColor}" stroke="${outline}" stroke-width="4" />
        <path d="M 130 110 L 120 45 L 180 35 L 210 65 L 165 100 Z" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        <polygon points="145,40 120,5 155,30" fill="${accentColor}" stroke="${outline}" stroke-width="4" />
        <polygon points="160,38 175,0 178,35" fill="${secondaryAccent}" stroke="${outline}" stroke-width="4" />
        <polygon points="${headPolygon}" fill="${bodyColor}" stroke="${outline}" stroke-width="6" stroke-linejoin="miter" />
        ${eyeMarkup}
        <path d="M 160 72 L 215 65" stroke="${outline}" stroke-width="5" stroke-linecap="square" />
        ${toothMarkup}
        <path d="M 115 175 L 95 215 L 120 215 M 175 175 L 195 215 L 215 215" stroke="${outline}" stroke-width="6" stroke-linecap="square" stroke-linejoin="miter" />
        <polygon points="215,65 255,55 240,75 270,65 230,85" fill="${secondaryAccent}" stroke="${outline}" stroke-width="3" />
      `;
      break;
  }

  return `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="100%" height="100%" class="dragon-svg-illustration">
      </defs>
      <circle cx="${width/2}" cy="${height/2}" r="${Math.min(width, height)*0.42}" fill="#13101c" stroke="#ffd700" stroke-width="2" opacity="0.6" />
      <circle cx="${width/2}" cy="${height/2}" r="${Math.min(width, height)*0.39}" fill="none" stroke="${colorSecondary}" stroke-width="1" stroke-dasharray="6,6" opacity="0.4" />
      ${paths}
    </svg>
  `;
}



  // 4. VIEWS

function slugify(text) {
  text = (text || "").toLowerCase();
  const replacements = {'á':'a', 'é':'e', 'í':'i', 'ó':'o', 'ú':'u', 'ñ':'n', 'ü':'u'};
  for (let k in replacements) {
    text = text.replace(new RegExp(k, 'g'), replacements[k]);
  }
  return text.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function renderDragonCardHTML(dragon) {
  const isFav = isFavorite(dragon.id);
  const dangerLevel = Math.max(1, Math.min(5, parseInt(dragon.danger || 1, 10)));
  const flames = "🔥".repeat(dangerLevel);
  const artSrc = getDragonArtworkSrc(dragon);
  const slug = slugify(dragon.name);

  const isEn = (typeof window !== "undefined" && window.I18N && window.I18N.currentLang === "en");
  const elemText = (typeof window !== "undefined" && window.I18N) ? window.I18N.translateElement(dragon.element) : dragon.element;
  const mythText = (typeof window !== "undefined" && window.I18N) ? window.I18N.translateMythology(dragon.mythology) : dragon.mythology;
  const favTitle = isFav 
    ? (isEn ? "Remove from Favorites" : "Quitar de Favoritos")
    : (isEn ? "Save to Favorites" : "Guardar en Favoritos");

  const mediaHtml = artSrc
    ? `<img src="${artSrc}" alt="${dragon.name}" width="400" height="300" loading="lazy" decoding="async" class="dragon-artwork-img" />`
    : renderDragonSVG(dragon, 300, 200);

  const enData = (typeof window !== "undefined" && window.DRAGONS_EN) ? window.DRAGONS_EN[dragon.id] : null;
  const titleText = (isEn && enData && enData.title) ? enData.title : dragon.title;

  return `
    <a href="/dragon/${slug}.html" class="dragon-card fantasy-panel" data-id="${dragon.id}" style="text-decoration: none; color: inherit; display: flex; flex-direction: column;">
      <button class="fav-btn ${isFav ? "active" : ""}" title="${favTitle}" onclick="event.preventDefault(); event.stopPropagation();">
        ${isFav ? "❤️" : "🤍"}
      </button>

      <div class="dragon-card-media">
        ${mediaHtml}
      </div>

      <div class="dragon-card-content">
        <span class="element-badge" data-raw-element="${dragon.element}">${elemText}</span>
        <h3 class="dragon-name">${dragon.name}</h3>
        <p class="dragon-title" data-raw-title="${dragon.title}">"${titleText}"</p>

        <div class="dragon-card-footer">
          <span class="mythology-tag" data-raw-myth="${dragon.mythology}">🏛️ ${mythText}</span>
          <span class="danger-tag">${flames}</span>
        </div>
      </div>
    </a>
  `;
}

function openDragonModal(dragon, onFavToggleCallback = null) {
  playSound("roar");

  const modalOverlay = document.getElementById("dragon-modal-overlay");
  const modalContent = document.getElementById("dragon-modal-content");

  if (!modalOverlay || !modalContent) return;

  const isFav = isFavorite(dragon.id);
  const flames = "🔥".repeat(dragon.danger);
  const artSrc = getDragonArtworkSrc(dragon);

  const mediaHtml = artSrc
    ? `<img src="${artSrc}" alt="${dragon.name}" width="600" height="450" decoding="async" class="modal-artwork-img" />`
    : renderDragonSVG(dragon, 340, 240);

  const isEn = (window.I18N && window.I18N.currentLang === "en");
  const t = (k) => (window.I18N ? window.I18N.t(k) : k);
  const transElem = (v) => (window.I18N ? window.I18N.translateElement(v) : v);
  const transMyth = (v) => (window.I18N ? window.I18N.translateMythology(v) : v);
  const transType = (v) => (window.I18N ? window.I18N.translateType(v) : v);
  const slug = slugify(dragon.name);

  const enData = (typeof window !== "undefined" && window.DRAGONS_EN) ? window.DRAGONS_EN[dragon.id] : null;
  const modalTitle = (isEn && enData && enData.title) ? enData.title : dragon.title;
  const modalHabitat = (isEn && enData && enData.habitat) ? enData.habitat : dragon.habitat;
  const modalAbility = (isEn && enData && enData.ability) ? enData.ability : dragon.ability;
  const modalWeakness = (isEn && enData && enData.weakness) ? enData.weakness : dragon.weakness;
  const modalScroll = (isEn && enData && enData.scroll) ? enData.scroll : dragon.scroll;

  const favText = isFav 
    ? (isEn ? "❤️ Remove from Favorites" : "❤️ Quitar de Favoritos")
    : (isEn ? "🤍 Save to Favorites" : "🤍 Guardar en Favoritos");

  modalContent.innerHTML = `
    <button class="modal-close-btn" id="btn-close-modal" aria-label="Cerrar">✖</button>
    <div class="modal-grid">
      <div class="modal-media-column">
        <div class="modal-img-frame">
          ${mediaHtml}
        </div>
        <div class="modal-actions margin-top-md" style="display: flex; flex-direction: column; gap: 8px;">
          <button class="btn ${isFav ? "btn-secondary" : "btn-primary"} width-100" id="btn-modal-fav">
            ${favText}
          </button>
          <a href="/dragon/${slug}.html" class="btn btn-secondary width-100" style="text-decoration: none; text-align: center; font-size: 0.9rem;">
            ${t("view_full_page")}
          </a>
        </div>
      </div>

      <div class="modal-info-column">
        <span class="element-badge" data-raw-element="${dragon.element}">${transElem(dragon.element)}</span>
        <h2 class="modal-dragon-title">${dragon.name}</h2>
        <p class="modal-dragon-subtitle">"${modalTitle}"</p>

        <div class="stats-table margin-top-md">
          <div class="stat-row"><strong>${t("stat_mythology")}:</strong> <span>${transMyth(dragon.mythology)}</span></div>
          <div class="stat-row"><strong>${t("stat_type")}:</strong> <span>${transType(dragon.type)}</span></div>
          <div class="stat-row"><strong>${t("stat_danger")}:</strong> <span>${flames} (${dragon.danger}/5)</span></div>
          <div class="stat-row"><strong>${t("stat_habitat")}:</strong> <span>${modalHabitat}</span></div>
          <div class="stat-row"><strong>${t("stat_ability")}:</strong> <span>${modalAbility}</span></div>
          <div class="stat-row"><strong>${t("stat_weakness")}:</strong> <span>${modalWeakness}</span></div>
        </div>

        <div class="historical-scroll-box margin-top-md fantasy-panel">
          <h4>📜 ${t("ancient_scroll_title")}:</h4>
          <p>${modalScroll}</p>
        </div>
      </div>
    </div>
  `;

  modalOverlay.classList.add("active");

  const btnClose = modalContent.querySelector("#btn-close-modal");
  if (btnClose) {
    btnClose.addEventListener("click", closeDragonModal);
  }

  modalOverlay.onclick = (e) => {
    if (e.target === modalOverlay) closeDragonModal();
  };

  const btnFav = modalContent.querySelector("#btn-modal-fav");
  if (btnFav) {
    btnFav.addEventListener("click", () => {
      toggleFavorite(dragon.id);
      openDragonModal(dragon, onFavToggleCallback);
      if (onFavToggleCallback) onFavToggleCallback();
    });
  }

  // Update URL parameter for deep-linking
  const url = new URL(window.location.href);
  url.searchParams.set("dragon", dragon.id);
  window.history.pushState({ dragonId: dragon.id }, "", url.toString());
}

function closeDragonModal() {
  const modalOverlay = document.getElementById("dragon-modal-overlay");
  if (modalOverlay) {
    modalOverlay.classList.remove("active");
  }

  // Remove dragon param from URL when closed
  const url = new URL(window.location.href);
  if (url.searchParams.has("dragon")) {
    url.searchParams.delete("dragon");
    window.history.pushState({}, "", url.toString());
  }
}



const ITEMS_PER_PAGE = 12;
let currentPage = 1;
let filteredDragons = [...DRAGONS_DATA].sort((a, b) => a.name.localeCompare(b.name));

function initEncyclopediaFilters() {
  const mythSelect = document.getElementById("filter-mythology");
  const elemSelect = document.getElementById("filter-element");
  const typeSelect = document.getElementById("filter-type");

  if (mythSelect) {
    const mythologies = ["Todas", ...new Set(DRAGONS_DATA.map(d => d.mythology))];
    mythSelect.innerHTML = mythologies.map(m => `<option value="${m}">${m === "Todas" ? "Todas las Mitologías" : m}</option>`).join("");
  }

  if (elemSelect) {
    const elements = ["Todos", ...new Set(DRAGONS_DATA.map(d => d.element))];
    elemSelect.innerHTML = elements.map(e => `<option value="${e}">${e === "Todos" ? "Todos los Elementos" : e}</option>`).join("");
  }

  if (typeSelect) {
    const rawTypes = new Set(DRAGONS_DATA.map(d => d.type));
    rawTypes.add("Drakón");
    rawTypes.add("Otros");
    const types = ["Todos", ...Array.from(rawTypes).sort()];
    typeSelect.innerHTML = types.map(t => `<option value="${t}">${t === "Todos" ? "Todos los Tipos" : t}</option>`).join("");
  }

  // Restore filter values from URL params on load
  const urlParams = new URLSearchParams(window.location.search);
  const searchInput = document.getElementById("search-input");
  const dangerSelect = document.getElementById("filter-danger");
  const sortSelect = document.getElementById("filter-sort");

  if (searchInput && urlParams.has("q")) searchInput.value = urlParams.get("q");
  if (mythSelect && urlParams.has("mitologia")) mythSelect.value = urlParams.get("mitologia");
  if (elemSelect && urlParams.has("elemento")) elemSelect.value = urlParams.get("elemento");
  if (typeSelect && urlParams.has("tipo")) typeSelect.value = urlParams.get("tipo");
  if (dangerSelect && urlParams.has("peligro")) dangerSelect.value = urlParams.get("peligro");
  if (sortSelect && urlParams.has("orden")) sortSelect.value = urlParams.get("orden");

  // Setup search and filter listeners
  if (searchInput) searchInput.addEventListener("input", () => applyFilters(true));
  if (mythSelect) mythSelect.addEventListener("change", () => applyFilters(true));
  if (elemSelect) elemSelect.addEventListener("change", () => applyFilters(true));
  if (typeSelect) typeSelect.addEventListener("change", () => applyFilters(true));
  if (dangerSelect) dangerSelect.addEventListener("change", () => applyFilters(true));
  if (sortSelect) sortSelect.addEventListener("change", () => applyFilters(true));

  const btnReset = document.getElementById("btn-reset-filters");
  if (btnReset) {
    btnReset.addEventListener("click", () => {
      if (searchInput) searchInput.value = "";
      if (mythSelect) mythSelect.value = "Todas";
      if (elemSelect) elemSelect.value = "Todos";
      if (typeSelect) typeSelect.value = "Todos";
      if (dangerSelect) dangerSelect.value = "Todos";
      if (sortSelect) sortSelect.value = "name-asc";
      applyFilters(true);
    });
  }

  // Initial filtering based on URL (only if not on a static SSG detail page)
  if (!window.location.pathname.includes("/dragon/")) {
    applyFilters(false);
  }
  if (window.I18N) window.I18N.applyTranslations();
}

function updateURLWithFilters(query, mythology, element, type, danger, sort) {
  const url = new URL(window.location.href);
  
  if (query) url.searchParams.set("q", query); else url.searchParams.delete("q");
  if (mythology && mythology !== "Todas") url.searchParams.set("mitologia", mythology); else url.searchParams.delete("mitologia");
  if (element && element !== "Todos") url.searchParams.set("elemento", element); else url.searchParams.delete("elemento");
  if (type && type !== "Todos") url.searchParams.set("tipo", type); else url.searchParams.delete("tipo");
  if (danger && danger !== "Todos") url.searchParams.set("peligro", danger); else url.searchParams.delete("peligro");
  if (sort && sort !== "name-asc") url.searchParams.set("orden", sort); else url.searchParams.delete("orden");

  window.history.replaceState({}, "", url.toString());
}

function applyFilters(shouldUpdateURL = true) {
  const query = (document.getElementById("search-input")?.value || "").toLowerCase().trim();
  
  const mVal = document.getElementById("filter-mythology")?.value;
  const mythology = (mVal && mVal.trim() !== "") ? mVal : "Todas";

  const eVal = document.getElementById("filter-element")?.value;
  const element = (eVal && eVal.trim() !== "") ? eVal : "Todos";

  const tVal = document.getElementById("filter-type")?.value;
  const type = (tVal && tVal.trim() !== "") ? tVal : "Todos";

  const dVal = document.getElementById("filter-danger")?.value;
  const danger = (dVal && dVal.trim() !== "") ? dVal : "Todos";

  const sort = document.getElementById("filter-sort")?.value || "name-asc";

  if (shouldUpdateURL) {
    updateURLWithFilters(query, mythology, element, type, danger, sort);
  }

  filteredDragons = DRAGONS_DATA.filter(d => {
    const matchQuery = !query || 
      d.name.toLowerCase().includes(query) || 
      d.title.toLowerCase().includes(query) || 
      d.mythology.toLowerCase().includes(query) || 
      d.ability.toLowerCase().includes(query) || 
      d.scroll.toLowerCase().includes(query);

    const matchMyth = mythology === "Todas" || d.mythology === mythology;
    const matchElem = element === "Todos" || d.element === element;
    const matchType = type === "Todos" || d.type === type;
    const matchDanger = danger === "Todos" || d.danger === parseInt(danger, 10);

    return matchQuery && matchMyth && matchElem && matchType && matchDanger;
  });

  if (sort === "name-asc") {
    filteredDragons.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sort === "name-desc") {
    filteredDragons.sort((a, b) => b.name.localeCompare(a.name));
  } else if (sort === "danger-desc") {
    filteredDragons.sort((a, b) => b.danger - a.danger);
  } else if (sort === "danger-asc") {
    filteredDragons.sort((a, b) => a.danger - b.danger);
  }

  currentPage = 1;
  renderEncyclopedia();
}

function renderEncyclopedia() {
  const grid = document.getElementById("dragons-grid");
  const countBadge = document.getElementById("results-count");
  const paginationBox = document.getElementById("pagination-box");

  if (!grid) return;

  if (countBadge) {
    countBadge.textContent = `${filteredDragons.length} Dragones Encontrados`;
  }

  if (filteredDragons.length === 0) {
    grid.innerHTML = `
      <div class="empty-state fantasy-panel width-100">
        <h3>🔍 No se encontraron dragones</h3>
        <p>Probá cambiando los filtros de búsqueda o reiniciando los parámetros.</p>
      </div>
    `;
    if (paginationBox) paginationBox.innerHTML = "";
    return;
  }

  const totalPages = Math.ceil(filteredDragons.length / ITEMS_PER_PAGE);
  const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
  const pageDragons = filteredDragons.slice(startIdx, startIdx + ITEMS_PER_PAGE);

  grid.innerHTML = pageDragons.map(dragon => renderDragonCardHTML(dragon)).join("");

  // Attach card click handlers for roar sound & favorite button
  grid.querySelectorAll(".dragon-card").forEach(card => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".fav-btn")) return;
      playSound("roar");
    });

    const btnFav = card.querySelector(".fav-btn");
    if (btnFav) {
      btnFav.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const dragonId = parseInt(card.dataset.id, 10);
        toggleFavorite(dragonId);
        renderEncyclopedia();
      });
    }
  });

  // Render pagination controls
  if (paginationBox) {
    if (totalPages <= 1) {
      paginationBox.innerHTML = "";
    } else {
      let pageButtonsHtml = "";
      
      // Calculate numeric range to display
      let startPage = Math.max(1, currentPage - 2);
      let endPage = Math.min(totalPages, startPage + 4);
      if (endPage - startPage < 4) {
        startPage = Math.max(1, endPage - 4);
      }

      // Build page numbers buttons
      for (let p = startPage; p <= endPage; p++) {
        const isActive = p === currentPage;
        pageButtonsHtml += `
          <button class="pag-btn ${isActive ? "active" : ""}" data-page="${p}">
            ${p}
          </button>
        `;
      }

      paginationBox.innerHTML = `
        <div class="pagination-container">
          <button class="pag-btn nav-arrow" id="btn-first-page" ${currentPage === 1 ? "disabled" : ""} title="Primera página">⏮️ Primera</button>
          <button class="pag-btn nav-arrow" id="btn-prev-page" ${currentPage === 1 ? "disabled" : ""} title="Página anterior">◀ Anterior</button>
          
          <div class="pag-numbers-wrap">
            ${pageButtonsHtml}
          </div>

          <button class="pag-btn nav-arrow" id="btn-next-page" ${currentPage === totalPages ? "disabled" : ""} title="Página siguiente">Siguiente ▶</button>
          <button class="pag-btn nav-arrow" id="btn-last-page" ${currentPage === totalPages ? "disabled" : ""} title="Última página">Última ⏭️</button>
        </div>
      `;

      const btnFirst = paginationBox.querySelector("#btn-first-page");
      const btnPrev = paginationBox.querySelector("#btn-prev-page");
      const btnNext = paginationBox.querySelector("#btn-next-page");
      const btnLast = paginationBox.querySelector("#btn-last-page");

      if (btnFirst) {
        btnFirst.addEventListener("click", () => {
          if (currentPage !== 1) {
            currentPage = 1;
            playSound("click");
            renderEncyclopedia();
            window.scrollTo({ top: 300, behavior: "smooth" });
          }
        });
      }
      if (btnPrev) {
        btnPrev.addEventListener("click", () => {
          if (currentPage > 1) {
            currentPage--;
            playSound("click");
            renderEncyclopedia();
            window.scrollTo({ top: 300, behavior: "smooth" });
          }
        });
      }
      if (btnNext) {
        btnNext.addEventListener("click", () => {
          if (currentPage < totalPages) {
            currentPage++;
            playSound("click");
            renderEncyclopedia();
            window.scrollTo({ top: 300, behavior: "smooth" });
          }
        });
      }
      if (btnLast) {
        btnLast.addEventListener("click", () => {
          if (currentPage !== totalPages) {
            currentPage = totalPages;
            playSound("click");
            renderEncyclopedia();
            window.scrollTo({ top: 300, behavior: "smooth" });
          }
        });
      }

      paginationBox.querySelectorAll(".pag-btn[data-page]").forEach(btn => {
        btn.addEventListener("click", () => {
          const targetP = parseInt(btn.dataset.page, 10);
          if (targetP !== currentPage) {
            currentPage = targetP;
            playSound("click");
            renderEncyclopedia();
            window.scrollTo({ top: 300, behavior: "smooth" });
          }
        });
      });
    }
  }
  if (window.I18N) window.I18N.applyTranslations();
}



const ELEMENTAL_PALETTES = {
  Rayo: { primary: "#ffd700", secondary: "#7209b7", glow: "#4cc9f0" },
  Fuego: { primary: "#ffd700", secondary: "#e63946", glow: "#ff5722" },
  Hielo: { primary: "#90e0ef", secondary: "#0077b6", glow: "#48cae4" },
  Veneno: { primary: "#2a9d8f", secondary: "#52b788", glow: "#74c69d" },
  Sombra: { primary: "#e0aaff", secondary: "#3c096c", glow: "#9d4edd" },
  Luz: { primary: "#ffd700", secondary: "#f8f9fa", glow: "#ffb703" }
};

const ELEMENT_NAMES_EN = {
  Rayo: "Lightning",
  Fuego: "Fire",
  Hielo: "Ice",
  Veneno: "Poison",
  Sombra: "Shadow",
  Luz: "Light"
};

const BODY_LABELS_ES = {
  draco: "Draco Clásico",
  shen: "Shen Serpentino",
  wyvern: "Wyvern Ágil",
  hidra: "Hidra",
  ampithere: "Ampithere Alado"
};

const BODY_LABELS_EN = {
  draco: "Classic Draco",
  shen: "Serpentine Shen",
  wyvern: "Agile Wyvern",
  hidra: "Hydra",
  ampithere: "Winged Ampithere"
};

const HORN_LABELS_ES = {
  "horns-classic": "Cuernos Clásicos",
  "horns-ram": "Cuernos de Carnero",
  "horns-crown": "Corona de Espinas",
  "horns-unicorn": "Cuerno de Cristal"
};

const HORN_LABELS_EN = {
  "horns-classic": "Classic Horns",
  "horns-ram": "Ram Horns",
  "horns-crown": "Crown of Thorns",
  "horns-unicorn": "Crystal Horn"
};

const RUNAL_MEANINGS_ES = {
  B: "Sabiduría Ancestral", C: "Viento y Cielos", D: "Dominio Draco", F: "Fuego Inmortal",
  G: "Guardián de Protección", H: "Escarcha Eterna", J: "Justicia Solar", K: "Cristal de Poder",
  L: "Luz Estelar", M: "Magia Mística", N: "Fuerza Vital", P: "Poder Elemental",
  Q: "Alquimia Sagrada", R: "Rayo y Tormenta", S: "Sombra Abisal", T: "Poder Terrenal",
  V: "Veneno Curativo", W: "Viento Ancestral", X: "Vínculo Cósmico", Y: "Eternidad", Z: "Cúspide Dragón"
};

const RUNAL_MEANINGS_EN = {
  B: "Ancestral Wisdom", C: "Wind & Skies", D: "Draco Dominion", F: "Immortal Fire",
  G: "Guardian Protection", H: "Eternal Frost", J: "Solar Justice", K: "Power Crystal",
  L: "Starlight", M: "Mystic Magic", N: "Life Force", P: "Elemental Power",
  Q: "Sacred Alchemy", R: "Lightning & Storm", S: "Abyssal Shadow", T: "Earthen Might",
  V: "Curative Venom", W: "Ancestral Wind", X: "Cosmic Bond", Y: "Eternity", Z: "Dragon Peak"
};

const BACKGROUND_PRESETS = {
  astral: "radial-gradient(circle at center, #2e1065 0%, #0f172a 70%, #020617 100%)",
  fuego: "radial-gradient(circle at center, #7f1d1d 0%, #450a0a 65%, #0f0505 100%)",
  escarcha: "radial-gradient(circle at center, #075985 0%, #0c4a6e 65%, #031e2e 100%)",
  obsidiana: "radial-gradient(circle at center, #581c87 0%, #2e1065 65%, #090314 100%)"
};

const SIGIL_STATE = {
  userName: "MAGUS DRAGUS",
  dragonName: "IGNITHARYON",
  bodyType: "draco",
  hornStyle: "horns-classic",
  element: "Rayo",
  colorPrimary: "#ffd700",
  colorSecondary: "#7209b7",
  colorGlow: "#4cc9f0",
  bgStyle: "astral",
  isConsecrated: false
};

const sigilIsEn = () => (window.I18N && window.I18N.currentLang === "en");
const sigilT = (k, fallback = "") => (window.I18N ? window.I18N.t(k) : fallback || k);

function initSigilForge(containerId = "sigil-container") {
  const container = document.getElementById(containerId);
  if (!container) return;

  renderSigilForgeUI(container);
}

function renderSigilForgeUI(container) {
  const consonants = extractConsonants(SIGIL_STATE.userName, SIGIL_STATE.dragonName);
  const resonance = Math.min(99, 84 + consonants.length * 2);
  const en = sigilIsEn();

  container.innerHTML = `
    <div class="sigil-forge-wrapper display-flex flex-direction-column gap-xl" style="display: flex; flex-direction: column; gap: 2rem;">
      
      <!-- HERO BANNER -->
      <div class="fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(233,196,106,0.15), rgba(42,157,143,0.15)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div class="quiz-step-tag" style="font-size: 0.95rem;">${en ? "🔮 Vector Alchemy 🔮" : "🔮 Alquimia Vectorial 🔮"}</div>
        <h2 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 2.3rem;">${en ? "The Draconian Sigil Forge" : "La Forja de Sigilos Draconianos"}</h2>
        <p style="color: var(--text-main); font-size: 1.1rem; max-width: 820px; margin: 12px auto 0 auto; line-height: 1.6;">
          ${en 
            ? "A <strong>Sigil</strong> is a secret and powerful symbol. It is the magical code in vector geometry linking your mind to your Guardian Dragon without human words." 
            : "Un <strong>Sigilo</strong> es un símbolo secreto y poderoso. Es el código mágico en geometría vectorial que une tu mente con la de tu Dragón Guardián sin usar palabras humanas."}
        </p>
      </div>

      <!-- MAIN LAYOUT: CONTROLS & LIVE VECTOR MIRROR -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 2rem; align-items: start;">
        
        <!-- COLUMN 1: PASOS DE ALQUIMIA & CONTROLES -->
        <div class="fantasy-panel" style="padding: 1.8rem; display: flex; flex-direction: column; gap: 1.4rem;">
          
          <!-- Paso 1 & 2: Palabras de Poder y Código Secreto -->
          <div style="background: rgba(0,0,0,0.3); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--border-panel);">
            <h3 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">
              ${en ? "📜 Steps 1 & 2: Words of Power & Code" : "📜 Paso 1 y 2: Palabras de Poder y Código"}
            </h3>
            
            <div style="background: rgba(233,196,106,0.08); padding: 12px; border-radius: 8px; border-left: 4px solid var(--gold-main); margin-top: 6px; line-height: 1.5;">
              <span style="font-size: 0.9rem; color: var(--gold-main); font-weight: 700; display: block; margin-bottom: 4px;">
                ${en ? "🔮 Alchemy of Your Secret Sigil:" : "🔮 Alquimia de tu Sigilo Secreto:"}
              </span>
              <p style="font-size: 0.85rem; color: var(--text-main); margin: 0;">
                ${en 
                  ? "We combine your Name and your Dragon's. We remove vowels and repeating letters to obtain the sacred consonant matrix." 
                  : "Combinamos tu Nombre y el de tu Dragón. Eliminamos las vocales y letras repetidas para obtener la matriz sagrada de consonantes."}
              </p>
            </div>

            <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 15px;">
              <div>
                <label style="display: block; color: var(--text-gold); font-size: 0.9rem; font-weight: 700; margin-bottom: 4px;">
                  ${en ? "Your Magical Name:" : "Tu Nombre Mágico:"}
                </label>
                <input type="text" id="sigil-user-name" value="${SIGIL_STATE.userName}" maxlength="15" style="width: 100%; padding: 10px; background: rgba(0,0,0,0.6); border: 1px solid var(--gold-main); border-radius: 8px; color: var(--gold-main); font-weight: 700; font-size: 1.05rem;" />
              </div>

              <div>
                <label style="display: block; color: var(--text-gold); font-size: 0.9rem; font-weight: 700; margin-bottom: 4px;">
                  ${en ? "Guardian Dragon's Name:" : "Nombre de tu Dragón Guardián:"}
                </label>
                <input type="text" id="sigil-dragon-name" value="${SIGIL_STATE.dragonName}" maxlength="15" style="width: 100%; padding: 10px; background: rgba(0,0,0,0.6); border: 1px solid var(--color-teal); border-radius: 8px; color: var(--color-teal); font-weight: 700; font-size: 1.05rem;" />
              </div>
            </div>
          </div>

          <!-- Paso 3: Características del Dragón -->
          <div style="background: rgba(0,0,0,0.3); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--border-panel);">
            <h3 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">
              ${en ? "🐉 Step 3: Power & Magic Palette" : "🐉 Paso 3: Poder y Paleta Mágica"}
            </h3>

            <div style="display: flex; flex-direction: column; gap: 12px;">
              <div>
                <label style="display: block; color: var(--text-muted); font-size: 0.88rem; font-weight: 700; margin-bottom: 4px;">
                  ${en ? "Anatomical Base Frame:" : "Anatomía / Forma Base:"}
                </label>
                <select id="sigil-body-type" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.6); border: 1px solid var(--border-panel); border-radius: 8px; color: var(--text-main);">
                  <option value="draco" ${SIGIL_STATE.bodyType === "draco" ? "selected" : ""}>${en ? "🛡️ Classic Draco (Inverted Shield Frame)" : "🛡️ Draco Clásico (Marco de Escudo Invertido)"}</option>
                  <option value="shen" ${SIGIL_STATE.bodyType === "shen" ? "selected" : ""}>${en ? "🐍 Serpentine Shen (Oriental Spiral)" : "🐍 Shen Serpentino (Espiral Oriental)"}</option>
                  <option value="wyvern" ${SIGIL_STATE.bodyType === "wyvern" ? "selected" : ""}>${en ? "🦅 Agile Wyvern (Triangular Crest)" : "🦅 Wyvern Ágil (Cresta Triangular)"}</option>
                  <option value="hidra" ${SIGIL_STATE.bodyType === "hidra" ? "selected" : ""}>${en ? "🐲 Hydra (Interlocking Rings)" : "🐲 Hidra (Círculos Intercalados)"}</option>
                  <option value="ampithere" ${SIGIL_STATE.bodyType === "ampithere" ? "selected" : ""}>${en ? "🕊️ Winged Ampithere (Winged Arches)" : "🕊️ Ampithere (Arcos Alados)"}</option>
                </select>
              </div>

              <div>
                <label style="display: block; color: var(--text-muted); font-size: 0.88rem; font-weight: 700; margin-bottom: 4px;">
                  ${en ? "Horns Style & Crests:" : "Estilo de Cuernos & Puntas:"}
                </label>
                <select id="sigil-horn-style" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.6); border: 1px solid var(--border-panel); border-radius: 8px; color: var(--text-main);">
                  <option value="horns-classic" ${SIGIL_STATE.hornStyle === "horns-classic" ? "selected" : ""}>${en ? "🐂 Curved Classic Horns" : "🐂 Cuernos Clásicos Curvados"}</option>
                  <option value="horns-ram" ${SIGIL_STATE.hornStyle === "horns-ram" ? "selected" : ""}>${en ? "🐏 Spiral Ram Horns" : "🐏 Cuernos de Carnero en Espiral"}</option>
                  <option value="horns-crown" ${SIGIL_STATE.hornStyle === "horns-crown" ? "selected" : ""}>${en ? "👑 Crown of Thorns" : "👑 Corona de Espinas"}</option>
                  <option value="horns-unicorn" ${SIGIL_STATE.hornStyle === "horns-unicorn" ? "selected" : ""}>${en ? "🦄 Single Crystal Horn" : "🦄 Cuerno Único de Cristal"}</option>
                </select>
              </div>

              <div>
                <label style="display: block; color: var(--text-muted); font-size: 0.88rem; font-weight: 700; margin-bottom: 4px;">
                  ${en ? "Magical Element (Auto Palette):" : "Elemento Mágico (Paleta Automática):"}
                </label>
                <select id="sigil-element" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.6); border: 1px solid var(--border-panel); border-radius: 8px; color: var(--text-main);">
                  <option value="Rayo" ${SIGIL_STATE.element === "Rayo" ? "selected" : ""}>${en ? "⚡ Lightning (Full Zig-zag)" : "⚡ Rayo (Plenos Zig-zag)"}</option>
                  <option value="Fuego" ${SIGIL_STATE.element === "Fuego" ? "selected" : ""}>${en ? "🔥 Fire (3 Spiked Triangles)" : "🔥 Fuego (3 Triángulos Picudos)"}</option>
                  <option value="Hielo" ${SIGIL_STATE.element === "Hielo" ? "selected" : ""}>${en ? "❄️ Ice (Pentacle Crystals)" : "❄️ Hielo (Cristales en Pentáculo)"}</option>
                  <option value="Veneno" ${SIGIL_STATE.element === "Veneno" ? "selected" : ""}>${en ? "🧪 Poison (Smooth Wave)" : "🧪 Veneno (Onda Suave)"}</option>
                  <option value="Sombra" ${SIGIL_STATE.element === "Sombra" ? "selected" : ""}>${en ? "🌑 Shadow (Abyssal Smoke)" : "🌑 Sombra (Humo Abisal)"}</option>
                  <option value="Luz" ${SIGIL_STATE.element === "Luz" ? "selected" : ""}>${en ? "✨ Light (Solar Rays)" : "✨ Luz (Rayos Solares)"}</option>
                </select>
              </div>

              <!-- Quick Presets -->
              <div style="margin-top: 4px;">
                <label style="display: block; font-size: 0.75rem; color: var(--text-gold); font-weight: 700; margin-bottom: 6px;">
                  ${en ? "🎨 Quick Theme Palettes:" : "🎨 Paletas Temáticas Rápidas:"}
                </label>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
                  <button type="button" class="btn btn-secondary btn-sm sigil-preset-btn" data-p="#ffd700" data-s="#2a9d8f" data-g="#e76f51">${en ? "🌟 Sacred Gold" : "🌟 Oro Sagrado"}</button>
                  <button type="button" class="btn btn-secondary btn-sm sigil-preset-btn" data-p="#ffd700" data-s="#e63946" data-g="#ff5722">${en ? "🔥 Blaze" : "🔥 Llamarada"}</button>
                  <button type="button" class="btn btn-secondary btn-sm sigil-preset-btn" data-p="#90e0ef" data-s="#0077b6" data-g="#48cae4">${en ? "❄️ Frost" : "❄️ Escarcha"}</button>
                  <button type="button" class="btn btn-secondary btn-sm sigil-preset-btn" data-p="#e0aaff" data-s="#3c096c" data-g="#9d4edd">${en ? "🌑 Abyssal Night" : "🌑 Noche Abisal"}</button>
                </div>
              </div>

              <!-- Colors Controls -->
              <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-top: 6px;">
                <div>
                  <label style="display: block; font-size: 0.75rem; color: var(--text-gold);">${en ? "Strokes / Frame:" : "Trazos / Marco:"}</label>
                  <input type="color" id="sigil-col-primary" value="${SIGIL_STATE.colorPrimary}" style="width: 100%; height: 36px; border: none; border-radius: 6px; cursor: pointer; background: transparent;" />
                </div>
                <div>
                  <label style="display: block; font-size: 0.75rem; color: var(--text-gold);">${en ? "Geometry:" : "Geometría:"}</label>
                  <input type="color" id="sigil-col-secondary" value="${SIGIL_STATE.colorSecondary}" style="width: 100%; height: 36px; border: none; border-radius: 6px; cursor: pointer; background: transparent;" />
                </div>
                <div>
                  <label style="display: block; font-size: 0.75rem; color: var(--text-gold);">${en ? "Aura / Glow:" : "Aura / Brillo:"}</label>
                  <input type="color" id="sigil-col-glow" value="${SIGIL_STATE.colorGlow}" style="width: 100%; height: 36px; border: none; border-radius: 6px; cursor: pointer; background: transparent;" />
                </div>
              </div>

            </div>
          </div>

          <!-- DECODIFICADOR DE RUNAS Y RESONANCIA ALQUÍMICA -->
          <div id="sigil-decoder-panel" style="background: rgba(0,0,0,0.3); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--gold-main);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.2rem;">${en ? "📜 Rune Decoder" : "📜 Decodificador de Runas"}</h3>
              <span style="background: rgba(233,196,106,0.2); border: 1px solid var(--gold-main); color: var(--gold-main); padding: 3px 10px; border-radius: 12px; font-weight: 700; font-size: 0.85rem;">
                ${en ? "Resonance" : "Resonancia"}: ${resonance}%
              </span>
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px;">
              ${consonants.map(c => `
                <div style="background: rgba(255,255,255,0.06); border: 1px solid var(--border-panel); padding: 4px 8px; border-radius: 6px; font-size: 0.82rem;">
                  <strong style="color: var(--gold-main);">${c}:</strong> <span style="color: var(--text-muted);">${(en ? RUNAL_MEANINGS_EN[c] : RUNAL_MEANINGS_ES[c]) || (en ? "Secret Power" : "Poder Secreto")}</span>
                </div>
              `).join("")}
            </div>
          </div>

        </div>

        <!-- COLUMN 2: PASO 4 - DIBUJO VECTORIAL & ESPEJO MÁGICO -->
        <div class="fantasy-panel text-center" style="padding: 1.8rem; display: flex; flex-direction: column; align-items: center; justify-content: space-between; min-height: 580px;">
          
          <div style="width: 100%;">
            <div class="quiz-step-tag" style="margin-bottom: 8px;">${en ? "✨ Step 4: Vector Drawing Spell ✨" : "✨ Paso 4: Hechizo de Dibujo Vectorial ✨"}</div>
            <h3 style="color: var(--gold-main); font-size: 1.5rem; margin: 0;">${en ? "The Mirror of Sigils" : "El Espejo de Sigilos"}</h3>
            <p style="color: var(--text-muted); font-size: 0.92rem; margin-top: 4px;">
              ${en 
                ? "Pure mathematical geometry: smooth, infinite, and scalable strokes that never pixelate." 
                : "Geometría matemática pura: trazos suaves, infinitos y escalables que nunca se pixelan."}
            </p>

            <!-- FONDOS ASTRALES INTERCAMBIABLES -->
            <div style="display: flex; justify-content: center; gap: 6px; margin-top: 10px;">
              <button type="button" class="btn btn-secondary btn-sm sigil-bg-btn" data-bg="astral" style="font-size: 0.78rem; padding: 3px 8px;">🌌 ${en ? "Astral" : "Astral"}</button>
              <button type="button" class="btn btn-secondary btn-sm sigil-bg-btn" data-bg="fuego" style="font-size: 0.78rem; padding: 3px 8px;">🔥 ${en ? "Fire" : "Fuego"}</button>
              <button type="button" class="btn btn-secondary btn-sm sigil-bg-btn" data-bg="escarcha" style="font-size: 0.78rem; padding: 3px 8px;">❄️ ${en ? "Frost" : "Escarcha"}</button>
              <button type="button" class="btn btn-secondary btn-sm sigil-bg-btn" data-bg="obsidiana" style="font-size: 0.78rem; padding: 3px 8px;">🌑 ${en ? "Obsidian" : "Obsidiana"}</button>
            </div>
          </div>

          <!-- SVG Canvas Stage -->
          <div id="sigil-svg-stage" style="width: 100%; max-width: 380px; height: 380px; display: flex; align-items: center; justify-content: center; background: ${BACKGROUND_PRESETS[SIGIL_STATE.bgStyle]}; border: 2px solid var(--gold-main); border-radius: 20px; box-shadow: 0 0 25px rgba(233,196,106,0.25); position: relative; margin: 1rem 0; overflow: hidden; transition: background 0.4s ease;">
            ${renderSigilSVG(SIGIL_STATE, consonants, 360, 360)}
          </div>

          <!-- ACTION BUTTONS -->
          <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <!-- Trace Animation -->
              <button class="btn btn-secondary btn-md" id="btn-animate-sigil" style="font-weight: 700; font-size: 0.88rem;">
                ${en ? "✨ Vector Revelation" : "✨ Revelación Vectorial"}
              </button>
              <!-- Consecration Ritual -->
              <button class="btn btn-gold btn-md" id="btn-consecrate-sigil" style="font-weight: 700; font-size: 0.88rem;">
                ${en ? "🔥 Consecrate Sigil" : "🔥 Consagrar Sigilo"}
              </button>
            </div>

            <!-- Download Action -->
            <button class="btn btn-gold btn-lg width-100" id="btn-export-sigil" style="padding: 14px 24px; font-weight: 700; font-size: 1.05rem;">
              ${en ? "🔮 Download HD Draconian Sigil (PNG)" : "🔮 Descargar Sigilo Draconiano HD (PNG)"}
            </button>
          </div>

        </div>

      </div>

    </div>
  `;

  // Attach Input Listeners
  const bindInput = (id, prop) => {
    const el = container.querySelector(`#${id}`);
    if (el) {
      el.addEventListener("input", e => {
        SIGIL_STATE[prop] = e.target.value;
        updateSigilStage(container);
        updateDecoderPanel(container);
      });
    }
  };

  bindInput("sigil-user-name", "userName");
  bindInput("sigil-dragon-name", "dragonName");
  bindInput("sigil-body-type", "bodyType");
  bindInput("sigil-horn-style", "hornStyle");

  const elemSelect = container.querySelector("#sigil-element");
  if (elemSelect) {
    elemSelect.addEventListener("change", e => {
      const elem = e.target.value;
      SIGIL_STATE.element = elem;
      if (ELEMENTAL_PALETTES[elem]) {
        SIGIL_STATE.colorPrimary = ELEMENTAL_PALETTES[elem].primary;
        SIGIL_STATE.colorSecondary = ELEMENTAL_PALETTES[elem].secondary;
        SIGIL_STATE.colorGlow = ELEMENTAL_PALETTES[elem].glow;
        updateColorPickerInputs(container);
      }
      updateSigilStage(container);
    });
  }

  bindInput("sigil-col-primary", "colorPrimary");
  bindInput("sigil-col-secondary", "colorSecondary");
  bindInput("sigil-col-glow", "colorGlow");

  // Preset Color Buttons
  container.querySelectorAll(".sigil-preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      SIGIL_STATE.colorPrimary = btn.dataset.p;
      SIGIL_STATE.colorSecondary = btn.dataset.s;
      SIGIL_STATE.colorGlow = btn.dataset.g;
      playSound("click");
      updateColorPickerInputs(container);
      updateSigilStage(container);
    });
  });

  // Background Preset Buttons
  container.querySelectorAll(".sigil-bg-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const bg = btn.dataset.bg;
      SIGIL_STATE.bgStyle = bg;
      playSound("click");
      const stage = container.querySelector("#sigil-svg-stage");
      if (stage && BACKGROUND_PRESETS[bg]) {
        stage.style.background = BACKGROUND_PRESETS[bg];
      }
    });
  });

  // Trace Animation Button
  const btnAnimate = container.querySelector("#btn-animate-sigil");
  if (btnAnimate) {
    btnAnimate.addEventListener("click", () => {
      playSound("chime");
      animateSigilTrace(container);
    });
  }

  // Consecration Ritual Button
  const btnConsecrate = container.querySelector("#btn-consecrate-sigil");
  if (btnConsecrate) {
    btnConsecrate.addEventListener("click", () => {
      SIGIL_STATE.isConsecrated = true;
      playSound("roar");
      triggerConsecrationBanner(container);
    });
  }

  const btnExp = container.querySelector("#btn-export-sigil");
  if (btnExp) {
    btnExp.addEventListener("click", () => {
      playSound("roar");
      exportSigilCardPNG();
    });
  }
}

function updateColorPickerInputs(container) {
  const pInput = container.querySelector("#sigil-col-primary");
  const sInput = container.querySelector("#sigil-col-secondary");
  const gInput = container.querySelector("#sigil-col-glow");
  if (pInput) pInput.value = SIGIL_STATE.colorPrimary;
  if (sInput) sInput.value = SIGIL_STATE.colorSecondary;
  if (gInput) gInput.value = SIGIL_STATE.colorGlow;
}

function updateDecoderPanel(container) {
  const panel = container.querySelector("#sigil-decoder-panel");
  if (!panel) return;
  const consonants = extractConsonants(SIGIL_STATE.userName, SIGIL_STATE.dragonName);
  const resonance = Math.min(99, 84 + consonants.length * 2);
  const en = sigilIsEn();

  panel.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
      <h3 style="color: var(--gold-main); margin: 0; font-size: 1.2rem;">${en ? "📜 Rune Decoder" : "📜 Decodificador de Runas"}</h3>
      <span style="background: rgba(233,196,106,0.2); border: 1px solid var(--gold-main); color: var(--gold-main); padding: 3px 10px; border-radius: 12px; font-weight: 700; font-size: 0.85rem;">
        ${en ? "Resonance" : "Resonancia"}: ${resonance}%
      </span>
    </div>
    <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px;">
      ${consonants.map(c => `
        <div style="background: rgba(255,255,255,0.06); border: 1px solid var(--border-panel); padding: 4px 8px; border-radius: 6px; font-size: 0.82rem;">
          <strong style="color: var(--gold-main);">${c}:</strong> <span style="color: var(--text-muted);">${(en ? RUNAL_MEANINGS_EN[c] : RUNAL_MEANINGS_ES[c]) || (en ? "Secret Power" : "Poder Secreto")}</span>
        </div>
      `).join("")}
    </div>
  `;
}

function updateSigilStage(container) {
  const stage = container.querySelector("#sigil-svg-stage");
  const consonants = extractConsonants(SIGIL_STATE.userName, SIGIL_STATE.dragonName);
  
  if (stage) {
    stage.innerHTML = renderSigilSVG(SIGIL_STATE, consonants, 360, 360);
  }
}

function animateSigilTrace(container) {
  const stage = container.querySelector("#sigil-svg-stage");
  if (!stage) return;

  const svg = stage.querySelector("svg");
  if (!svg) return;

  const paths = svg.querySelectorAll("path, polygon, circle, line");
  paths.forEach(p => {
    p.style.transition = "none";
    p.style.strokeDasharray = "1000";
    p.style.strokeDashoffset = "1000";
    p.getBoundingClientRect(); // Force reflow
    p.style.transition = "stroke-dashoffset 2.2s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease";
    p.style.strokeDashoffset = "0";
  });
}

function triggerConsecrationBanner(container) {
  const stage = container.querySelector("#sigil-svg-stage");
  if (!stage) return;
  const en = sigilIsEn();

  // Flash Golden Glow Filter
  stage.style.boxShadow = "0 0 50px rgba(255,215,0,0.8)";
  setTimeout(() => {
    stage.style.boxShadow = "0 0 25px rgba(233,196,106,0.25)";
  }, 1500);

  // Show Alert Banner
  let banner = container.querySelector("#consecration-alert");
  if (!banner) {
    banner = document.createElement("div");
    banner.id = "consecration-alert";
    banner.style.cssText = "background: linear-gradient(135deg, rgba(255,215,0,0.2), rgba(230,57,70,0.2)); border: 2px solid var(--gold-main); border-radius: 12px; padding: 14px; margin-top: 1rem; text-align: center; color: var(--gold-main); font-weight: 700; font-size: 0.98rem; animation: fadeIn 0.5s ease;";
    stage.parentNode.insertBefore(banner, stage.nextSibling);
  }
  banner.innerHTML = en 
    ? `📜 SIGIL OFFICIALLY CONSECRATED!<br><span style="font-size:0.85rem; color:#ffffff; font-weight:normal;">Your sacred pact with <strong>${SIGIL_STATE.dragonName}</strong> has been sealed into the alchemical matrix.</span>`
    : `📜 ¡SIGILO CONSAGRADO OFICIALMENTE!<br><span style="font-size:0.85rem; color:#ffffff; font-weight:normal;">Tu pacto sagrado con <strong>${SIGIL_STATE.dragonName}</strong> ha sido sellado en la matriz alquímica.</span>`;
}

function exportSigilCardPNG() {
  const consonants = extractConsonants(SIGIL_STATE.userName, SIGIL_STATE.dragonName);
  const en = sigilIsEn();
  
  const canvas = document.createElement("canvas");
  canvas.width = 650;
  canvas.height = 940;
  const ctx = canvas.getContext("2d");

  // 1. Rich Dark Radial Gradient Background
  const grad = ctx.createRadialGradient(325, 470, 50, 325, 470, 540);
  grad.addColorStop(0, "#1f1836");
  grad.addColorStop(0.6, "#100b1e");
  grad.addColorStop(1, "#07040d");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 650, 940);

  // 2. Metallic Golden Card Outer & Inner Borders
  ctx.strokeStyle = "#ffd700";
  ctx.lineWidth = 8;
  ctx.strokeRect(18, 18, 614, 904);

  ctx.strokeStyle = "#e9c46a";
  ctx.lineWidth = 2;
  ctx.strokeRect(28, 28, 594, 884);

  // 3. Corner Filigree Diamonds (◆)
  ctx.fillStyle = "#ffd700";
  ctx.font = "bold 20px serif";
  ctx.textAlign = "center";
  ctx.fillText("◆", 38, 45);
  ctx.fillText("◆", 612, 45);
  ctx.fillText("◆", 38, 905);
  ctx.fillText("◆", 612, 905);

  // 4. Header Badge & Title
  ctx.fillStyle = "#e9c46a";
  ctx.font = "bold 13px sans-serif";
  ctx.fillText(en ? "✨ DRACONIAN ALCHEMY EMBLEM • OFFICIAL EDITION ✨" : "✨ EMBLEMA DE ALQUIMIA DRACONIANA • EDICIÓN OFICIAL ✨", 325, 66);

  ctx.fillStyle = "#ffd700";
  ctx.font = "bold 28px serif";
  ctx.fillText(en ? "SACRED DRACONIAN SIGIL" : "SIGILO SAGRADO DRACONIANO", 325, 100);

  ctx.fillStyle = "#ffffff";
  ctx.font = "italic 17px serif";
  ctx.fillText(en 
    ? `Sacred Pact between "${SIGIL_STATE.userName}" and "${SIGIL_STATE.dragonName}"` 
    : `Pacto Sagrado entre "${SIGIL_STATE.userName}" y "${SIGIL_STATE.dragonName}"`, 325, 128);

  // 5. Render High-Res SVG onto Canvas
  const svgData = renderSigilSVG(SIGIL_STATE, consonants, 460, 460);
  const img = new Image();
  const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);

  img.onload = () => {
    // Draw Sigil Medallion Plate
    ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
    ctx.beginPath();
    ctx.arc(325, 385, 215, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 215, 0, 0.4)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw SVG Sigil
    ctx.drawImage(img, 95, 155, 460, 460);

    // 6. Metadata Footer Box
    ctx.fillStyle = "rgba(10, 14, 23, 0.88)";
    ctx.fillRect(38, 630, 574, 242);
    ctx.strokeStyle = SIGIL_STATE.isConsecrated ? "#ffd700" : "rgba(233,196,106,0.6)";
    ctx.lineWidth = 2;
    ctx.strokeRect(38, 630, 574, 242);

    // Line 1: Consonantes
    ctx.fillStyle = "#ffd700";
    ctx.font = "bold 20px serif";
    ctx.fillText(`${en ? "SACRED MATRIX" : "MATRIZ SAGRADA"}: ${consonants.join(" • ")}`, 325, 668);

    // Line 2: Elemento y Anatomía
    const bodyLabel = (en ? BODY_LABELS_EN[SIGIL_STATE.bodyType] : BODY_LABELS_ES[SIGIL_STATE.bodyType]) || (en ? "Classic Draco" : "Draco Clásico");
    const hornLabel = (en ? HORN_LABELS_EN[SIGIL_STATE.hornStyle] : HORN_LABELS_ES[SIGIL_STATE.hornStyle]) || (en ? "Classic Horns" : "Cuernos Clásicos");
    const elemLabel = en ? (ELEMENT_NAMES_EN[SIGIL_STATE.element] || SIGIL_STATE.element) : SIGIL_STATE.element;

    ctx.fillStyle = "#ffffff";
    ctx.font = "15px sans-serif";
    ctx.fillText(en ? `Element: ${elemLabel}  |  Anatomy: ${bodyLabel}` : `Elemento: ${elemLabel}  |  Anatomía: ${bodyLabel}`, 325, 705);

    // Line 3: Cuernos y Resonancia
    ctx.fillStyle = "#4cc9f0";
    ctx.font = "15px sans-serif";
    const resValue = Math.min(99, 84 + consonants.length * 2);
    ctx.fillText(en ? `Horns: ${hornLabel}  |  Resonance: ${resValue}%` : `Cuernos: ${hornLabel}  |  Resonancia: ${resValue}%`, 325, 740);

    // Line 4: Sello / Registro Oficial
    ctx.fillStyle = SIGIL_STATE.isConsecrated ? "#ffd700" : "#2a9d8f";
    ctx.font = "bold 14px sans-serif";
    ctx.fillText(en ? "📜 REGISTERED AT THE SECRET SANCTUARY OF DRAGONS" : "📜 REGISTRADO EN EL SANTUARIO SECRETO DE DRAGONES", 325, 782);

    // Line 5: Estado de Consagración
    ctx.fillStyle = SIGIL_STATE.isConsecrated ? "#ffb703" : "#e9c46a";
    ctx.font = "italic 13px sans-serif";
    const subSeal = SIGIL_STATE.isConsecrated
      ? (en ? "🔥 Consecrated with Dragon Breath" : "🔥 Consagrado con Aliento de Dragón")
      : (en ? "Official Vector Emblem" : "Emblema Vectorial Oficial");
    ctx.fillText(subSeal, 325, 814);

    // Download PNG
    const link = document.createElement("a");
    link.download = en 
      ? `Draconian_Sigil_${SIGIL_STATE.userName}_${SIGIL_STATE.dragonName}.png`
      : `Sigilo_Draconiano_${SIGIL_STATE.userName}_${SIGIL_STATE.dragonName}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
    URL.revokeObjectURL(url);
  };

  img.src = url;
}

// Window globals for cross-module accessibility
if (typeof window !== "undefined") {
  window.renderSigilForgeUI = renderSigilForgeUI;
  window.initSigilForge = initSigilForge;
  window.exportSigilCardPNG = exportSigilCardPNG;
  window.SIGIL_STATE = SIGIL_STATE;
}




let currentMagicPage = "fundamentos";
let currentMagicRing = 1;
let currentAltarTool = "varita";

function magicIsEn() {
  return typeof window !== "undefined" && window.I18N && window.I18N.currentLang === "en";
}

// Global interactive translator for Dragon Script
window.updateDragonScriptTranslator = function() {
  const input = document.getElementById("ds-translator-input");
  const outputContainer = document.getElementById("ds-translator-output");
  const downloadBtn = document.getElementById("ds-download-all-btn");
  if (!input || !outputContainer) return;

  const isEn = magicIsEn();
  const val = input.value.trim();
  if (!val) {
    outputContainer.innerHTML = isEn
      ? `<span style="color: var(--text-muted); font-style: italic;">Write your name or wish above to see it converted into Dragon Script...</span>`
      : `<span style="color: var(--text-muted); font-style: italic;">Escribí tu nombre o deseo arriba para verlo convertido al Escrito del Dragón...</span>`;
    if (downloadBtn) downloadBtn.style.display = "none";
    return;
  }

  const translated = translateToDragonScript(val);

  outputContainer.innerHTML = translated.map(item => `
    <div class="ds-char-box">
      <div class="ds-char-glyph-wrap" style="color: var(--gold-main);">
        ${item.info.svg || `<span style="font-size:1.6rem;">${item.info.glyph}</span>`}
      </div>
      <span style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px; font-weight: 700; user-select: none;">${item.char}</span>
    </div>
  `).join("");

  if (downloadBtn) downloadBtn.style.display = "inline-flex";
};

// Genera un Canvas con los caracteres SVG exactos de Dragon Script en alta resolución dorada para descargar
function generateDragonScriptCanvas(items, callback) {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  const charWidth = 60;
  const charHeight = 70;
  const totalWidth = Math.max(120, items.length * charWidth + 40);
  const totalHeight = charHeight + 50;

  canvas.width = totalWidth;
  canvas.height = totalHeight;

  // Fondo místico oscuro
  ctx.fillStyle = "#0c0b14";
  ctx.fillRect(0, 0, totalWidth, totalHeight);

  // Borde dorado
  ctx.strokeStyle = "#e9c46a";
  ctx.lineWidth = 3;
  ctx.strokeRect(4, 4, totalWidth - 8, totalHeight - 8);

  let loadedImages = 0;
  const validItems = items.filter(it => it.char !== ' ');

  if (validItems.length === 0) {
    callback(canvas);
    return;
  }

  items.forEach((it, idx) => {
    if (it.char === ' ') return;
    const svgStr = it.info.svg;
    if (!svgStr) return;

    // Colorear el SVG con oro puro para el renderizado en canvas
    const coloredSvg = svgStr.replace(/currentColor/g, '#e9c46a');
    const svgBlob = new Blob([coloredSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();

    img.onload = function() {
      const x = 20 + idx * charWidth + (charWidth - 44) / 2;
      const y = 14;
      ctx.drawImage(img, x, y, 44, 44);
      URL.revokeObjectURL(url);
      loadedImages++;

      // Letra latina pequeña abajo
      ctx.fillStyle = "#888899";
      ctx.font = "bold 13px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(it.char, 20 + idx * charWidth + charWidth / 2, y + 56);

      if (loadedImages >= validItems.length) {
        callback(canvas);
      }
    };
    img.src = url;
  });
}

// Descargar todo el mensaje traducido en PNG transparente/alta calidad
window.downloadDragonScriptImage = function() {
  const input = document.getElementById("ds-translator-input");
  if (!input || !input.value.trim()) return;

  const translated = translateToDragonScript(input.value.trim());
  generateDragonScriptCanvas(translated, (canvas) => {
    canvas.toBlob((blob) => {
      downloadCanvasBlob(blob, `dragon_script_${input.value.trim().toLowerCase()}.png`);
      playSound("chime");
    });
  });
};

function downloadCanvasBlob(blob, filename) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

window.playRuneSound = function(letter) {
  if (typeof playSound === "function") playSound("rune");
  const badge = document.getElementById("ds-rune-preview");
  const info = DRAGON_SCRIPT_MAP[letter];
  const isEn = magicIsEn();
  if (badge && info) {
    const descText = (isEn && info.desc_en) ? info.desc_en : info.desc;
    badge.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: center; gap: 14px; animation: fadeIn 0.3s ease; width: 100%;">
        <div class="ds-char-box" style="padding: 8px 12px; min-width: 50px;">
          <div class="ds-char-glyph-wrap" style="color: var(--gold-main);">
            ${info.svg || `<span style="font-size:2rem;">${info.glyph}</span>`}
          </div>
        </div>
        <div style="text-align: left;">
          <strong style="color: var(--gold-light); font-size: 1.15rem;">${isEn ? "Letter" : "Letra"} ${letter} — ${info.glyph}</strong>
          <p style="margin: 2px 0 0 0; color: var(--text-main); font-size: 0.92rem;">${descText}</p>
        </div>
      </div>
    `;
  }
};



// Global navigation functions for inline onclick handlers
window.switchMagicSubPage = function(page) {
  if (typeof playSound === "function") playSound("click");
  currentMagicPage = page;
  const container = document.getElementById("magic-container");
  if (container) renderMagicSection(container);
  window.scrollTo({ top: 200, behavior: "smooth" });
};

window.switchAltarTool = function(tool) {
  if (typeof playSound === "function") playSound("click");
  currentAltarTool = tool;
  const container = document.getElementById("magic-container");
  if (container) renderAltarSubPage(container);
};

window.switchMagicRing = function(ringNum) {
  if (typeof playSound === "function") playSound("click");
  currentMagicRing = ringNum;
  const container = document.getElementById("magic-container");
  if (container) renderAcademiaSubPage(container);
};

function initMagicModule(containerId = "magic-container") {
  const container = document.getElementById(containerId);
  if (!container) return;

  renderMagicSection(container);
}

if (typeof window !== "undefined") {
  window.renderFundamentosView = renderFundamentosView;
  window.renderAltarSubPage = renderAltarSubPage;
  window.renderAcademiaSubPage = renderAcademiaSubPage;
  window.renderRingContent = renderRingContent;
  window.renderMagicSection = renderMagicSection;
}

function renderMagicSubNavHtml(activePage) {
  const isEn = window.I18N && window.I18N.currentLang === "en";
  return `
    <div class="margin-top-md magic-sub-nav">
      <a href="/magia-draconiana.html" class="chip ${activePage === "fundamentos" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; ${activePage !== "fundamentos" ? "background: rgba(233,196,106,0.15);" : ""}">${isEn ? "📜 1. Foundations" : "📜 1. Fundamentos"}</a>
      <a href="/altar-draconiano.html" class="chip ${activePage === "altar" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; ${activePage !== "altar" ? "background: rgba(233,196,106,0.15);" : ""}">${isEn ? "⚒️ 2. The Altar" : "⚒️ 2. El Altar"}</a>
      <a href="/academia-draconiana.html" class="chip ${activePage === "academia" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; ${activePage !== "academia" ? "background: rgba(233,196,106,0.15);" : ""}">${isEn ? "🎓 3. Academy (5 Rings)" : "🎓 3. Academia (5 Anillos)"}</a>
      <a href="/forja-de-sigilos.html" class="chip ${activePage === "sigilos" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; ${activePage !== "sigilos" ? "background: rgba(233,196,106,0.15);" : ""}">${isEn ? "🔮 4. Sigil Forge" : "🔮 4. Forja de Sigilos"}</a>
    </div>
  `;
}

function syncMagicRouteWithUrl() {
  if (typeof window === "undefined" || !window.location) return;
  const p = window.location.pathname;
  if (p.includes("altar-varita")) {
    currentMagicPage = "altar";
    currentAltarTool = "varita";
  } else if (p.includes("altar-pentaculo")) {
    currentMagicPage = "altar";
    currentAltarTool = "pentaculo";
  } else if (p.includes("altar-espejo")) {
    currentMagicPage = "altar";
    currentAltarTool = "espejo";
  } else if (p.includes("altar-dragonscript")) {
    currentMagicPage = "altar";
    currentAltarTool = "dragonscript";
  } else if (p.includes("altar-draconiano")) {
    currentMagicPage = "altar";
  } else if (p.includes("academia-anillo-")) {
    currentMagicPage = "academia";
    for (let r = 1; r <= 5; r++) {
      if (p.includes(`academia-anillo-${r}`)) {
        currentMagicRing = r;
        break;
      }
    }
  } else if (p.includes("academia-draconiana")) {
    currentMagicPage = "academia";
  } else if (p.includes("forja-de-sigilos")) {
    currentMagicPage = "sigilos";
  } else if (p.includes("magia-draconiana")) {
    currentMagicPage = "fundamentos";
  }
}

function renderMagicSection(container) {
  if (!container) container = document.getElementById("magic-container");
  if (!container) return;

  syncMagicRouteWithUrl();

  if (currentMagicPage === "fundamentos") {
    renderFundamentosView(container);
  } else if (currentMagicPage === "altar") {
    renderAltarSubPage(container);
  } else if (currentMagicPage === "academia") {
    renderAcademiaSubPage(container);
  } else if (currentMagicPage === "sigilos") {
    renderSigilSubPage(container);
  }
}

function renderSigilSubPage(container) {
  // Render Sigil Forge inner UI and inject sub-navigation at top
  renderSigilForgeUI(container);

  // Prepend sub-navigation to container wrapper
  const heroBanner = container.querySelector(".fantasy-panel.text-center");
  if (heroBanner && !heroBanner.querySelector(".magic-sub-nav")) {
    const navDiv = document.createElement("div");
    navDiv.className = "magic-sub-nav";
    navDiv.innerHTML = renderMagicSubNavHtml("sigilos");
    heroBanner.appendChild(navDiv);
  }
}

// Window globals for cross-module reactivity
if (typeof window !== "undefined") {
  window.renderMagicSection = renderMagicSection;
  window.renderSigilSubPage = renderSigilSubPage;
}

// SUB-PÁGINA 1: FUNDAMENTOS Y LEYES
function renderFundamentosView(container) {
  const isEn = magicIsEn();
  container.innerHTML = `
    <div class="magic-section-wrapper" style="display: flex; flex-direction: column; gap: 2rem;">
      
      <!-- HERO BANNER DE MAGIA -->
      <div class="magic-hero fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(42,157,143,0.15), rgba(200,85,61,0.15)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div class="quiz-step-tag" style="font-size: 0.95rem;">${isEn ? "✨ The Ancestral Path ✨" : "✨ El Sendero Ancestral ✨"}</div>
        <h2 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 2.3rem;">${isEn ? "Draconian Magic: Foundations & Laws" : "Magia Draconiana: Fundamentos y Leyes"}</h2>
        <p style="color: var(--text-main); font-size: 1.1rem; max-width: 800px; margin: 12px auto 0 auto; line-height: 1.6;">
          ${isEn 
            ? "Welcome to the path of secret wisdom. Draconian Magic is an ancient tradition based on respect, friendship with ancient beings, and the responsible use of universal energy." 
            : "Te damos la bienvenida al camino de la sabiduría secreta. La Magia Draconiana es una tradición milenaria basada en el respeto, la amistad con seres antiguos y el uso responsable de la energía universal."}
        </p>
        
        <!-- SUB-NAV SWITCHER -->
        ${renderMagicSubNavHtml("fundamentos")}
      </div>

      <!-- GRILLA DE LEYES Y FUNDAMENTOS DRACONIANOS -->
      <div class="magic-laws-grid" style="display: flex; flex-direction: column; gap: 1.5rem;">
        
        <!-- 🌟 1. La Regla de Oro del Mago (HEADER ANCHO COMPLETO CON ILUSTRACIÓN) -->
        <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid #ff4757; background: linear-gradient(135deg, rgba(255,71,87,0.12), rgba(255,165,2,0.06));">
          <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
            <span style="font-size: 2.2rem;">🌟</span>
            <h3 style="color: #ff4757; margin: 0; font-size: 1.6rem;">${isEn ? "The Wizard's Golden Rule: If you're not having fun, it's not magic!" : "La Regla de Oro del Mago: ¡Si no te divertís, no es magia!"}</h3>
          </div>
          <div style="display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 280px;">
              <p style="color: var(--text-main); font-size: 1.05rem; line-height: 1.7; margin: 0; font-weight: 500;">
                ${isEn 
                  ? "Listen closely, young wizard! There is a secret that many grimoires forget to tell, but which true sages and dragons know very well: <strong>magic was invented to be enjoyed and bring joy</strong>." 
                  : "¡Escuchá con atención, joven mago! Hay un secreto que muchos libros olvidan contar, pero que los verdaderos sabios y los dragones conocen muy bien: <strong>la magia se inventó para disfrutarse y ser feliz</strong>."}
              </p>
              <p style="color: var(--text-main); font-size: 0.98rem; line-height: 1.7; margin-top: 12px;">
                ${isEn 
                  ? "In Draconian Magic, having fun isn't just an extra—it is the very engine that makes your spells work! If you are ever practicing an exercise, meditating, or drawing a sigil and begin to feel bored, frightened, sad, or stressed, the golden rule instructs you to stop at once. <strong>If you're having a hard time, that isn't true magic!</strong>" 
                  : "En la Magia Draconiana, la diversión no es solo un extra, ¡es el motor que hace que tus hechizos funcionen! Si alguna vez estás practicando un ejercicio, haciendo una meditación o dibujando un sigilo y empezás a sentirte aburrido, asustado, triste o muy estresado, la regla de oro te dice que debés detenerte de inmediato. <strong>Si la estás pasando mal, ¡eso no es verdadera magia!</strong>"}
              </p>
            </div>
            <div style="width: 100%; max-width: 280px; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); box-shadow: 0 6px 18px rgba(0,0,0,0.6); flex-shrink: 0; margin: 0 auto;">
              <img src="/assets/patriarch_dragon_laws.webp" alt="${isEn ? "Wise patriarch dragon with the tablets of draconian commandments" : "Dragón patriarca sabio con las tablas de los mandamientos draconianos"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
            </div>
          </div>
        </div>

        <!-- FILA 1: COMPAÑERISMO & 24H SILENCIO -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;" class="display-grid">
          
          <!-- 🤝 2. La Regla del Compañerismo -->
          <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid var(--color-teal); background: rgba(42,157,143,0.08); display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 2rem;">🤝</span>
                <h3 style="color: var(--color-teal); margin: 0; font-size: 1.45rem;">${isEn ? "The Rule of Companionship" : "La Regla del Compañerismo"}</h3>
              </div>
              <p style="color: var(--text-gold); font-size: 0.95rem; font-weight: 700; margin-top: 8px;">${isEn ? "Dragons are not pets!" : "¡Los dragones no son mascotas!"}</p>
              <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-top: 8px;">
                ${isEn 
                  ? "Dragons are ancient, exceptionally wise, and independent beings. Draconian magic is rooted in cooperation and friendship, never in domination. Never attempt to order them around or treat them as servants. Treat them as your equals: with respect, trust, affection, and as true companions." 
                  : "Los dragones son seres antiguos, muy sabios e independientes. La magia draconiana se basa en la cooperación y la amistad, jamás en dominar. Nunca intentes ordenarles o tratarlos como sirvientes. Tratalos como a tus iguales: con respeto, confianza, cariño y como verdaderos compañeros de equipo."}
              </p>
            </div>
          </div>

          <!-- 💬 3. Las 24 Horas de Silencio -->
          <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid #9b5de5; background: rgba(155,93,229,0.08); display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 2rem;">💬</span>
                <h3 style="color: #9b5de5; margin: 0; font-size: 1.45rem;">${isEn ? "The 24 Hours of Silence" : "Las 24 Horas de Silencio"}</h3>
              </div>
              <p style="color: var(--text-gold); font-size: 0.95rem; font-weight: 700; margin-top: 8px;">${isEn ? "Don't let your energy escape!" : "¡No dejes escapar tu energía!"}</p>
              <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-top: 8px;">
                ${isEn 
                  ? "Whenever you cast a spell, trace a sigil, or make a petition to your dragon, keep absolute secrecy for at least a full day. Speaking of your magical workings prematurely disperses your energy. Dragons act in quiet stillness: allow your intention to gather its full strength." 
                  : "Cuando hagas un hechizo, dibujes un sigilo o hagas una petición a tu dragón, guardá el secreto absoluto por al menos un día entero. Hablar de tus trabajos mágicos antes de tiempo disipa tu energía. Los dragones actúan en silencio: dejá que tu deseo se concentre con toda su fuerza."}
              </p>
            </div>
          </div>

        </div>

        <!-- FILA 2: PALABRA DE ACERO & LEY DEL ECO -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;" class="display-grid">

          <!-- 🔐 4. Tu Palabra es de Acero -->
          <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid var(--gold-main); background: rgba(233,196,106,0.08); display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 2rem;">🔐</span>
                <h3 style="color: var(--gold-main); margin: 0; font-size: 1.45rem;">${isEn ? "Your Word is Made of Steel" : "Tu Palabra es de Acero"}</h3>
              </div>
              <p style="color: var(--text-gold); font-size: 0.95rem; font-weight: 700; margin-top: 8px;">${isEn ? "The law of sacred trust" : "La ley de la confianza sagrada"}</p>
              <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-top: 8px;">
                ${isEn 
                  ? "Words act as invisible contracts with the cosmos. Therefore, your word is your sacred bond. If you promise your dragon (or yourself) to tidy your room, study, or tend your altar, see it through! Steadfastness keeps your energy resolute and sacred trust unbroken." 
                  : "Las palabras actúan como contratos invisibles con el universo. Por eso, tu palabra es tu promesa sagrada. Si le prometés a tu dragón (o a vos mismo) ordenar tu cuarto, estudiar o cuidar tu altar, ¡cumplilo! La constancia mantiene tu energía fuerte y la confianza intacta."}
              </p>
            </div>
          </div>

          <!-- 🕸️ 5. La Ley del Eco y la Red Tripartita -->
          <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid var(--color-rust); background: rgba(200,85,61,0.08); display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 2rem;">🕸️</span>
                <h3 style="color: var(--color-rust); margin: 0; font-size: 1.45rem;">${isEn ? "The Law of the Echo & Cosmic Web" : "La Ley del Eco y la Red Cósmica"}</h3>
              </div>
              <p style="color: var(--text-gold); font-size: 0.95rem; font-weight: 700; margin-top: 8px;">${isEn ? '"What befalls a stone is mirrored in all"' : '"Lo que le pasa a una piedra, se refleja en todas"'}</p>
              <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-top: 8px;">
                ${isEn 
                  ? "Everything across the Multiverse is woven into a vast web of energy. The <strong>Threefold Law</strong> reigns: whatever you send forth (kindness or harsh vibes) shall return to you threefold. If you nurture nature and walk gently, the universe will answer with joy and fortune." 
                  : "Todo en el Multiverso está conectado en una gran telaraña de energía. Rige la <strong>Ley Tripartita</strong>: lo que envíes (amabilidad o mala vibra) volverá a vos multiplicado por tres. Si cuidás la naturaleza y sos amable, el universo te devolverá felicidad y buena suerte."}
              </p>
            </div>
          </div>

        </div>

        <!-- 📜 6. El Código de Honor del Mago (PIE DE PÁGINA ANCHO COMPLETO) -->
        <div class="fantasy-panel" style="padding: 1.8rem; border-left: 6px solid #4cc9f0; background: rgba(76,201,240,0.08);">
          <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 2rem;">📜</span>
            <h3 style="color: #4cc9f0; margin: 0; font-size: 1.5rem;">${isEn ? "The Draconian Mage's Code of Honor" : "El Código de Honor del Mago Draconiano"}</h3>
          </div>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin-top: 14px;">
            <div style="background: rgba(0,0,0,0.3); padding: 12px 16px; border-radius: 10px; border-left: 3px solid #4cc9f0;">
              <strong style="color: #4cc9f0;">${isEn ? "🛡️ Pure Intent:" : "🛡️ Intención Pura:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Never use magic to manipulate, frighten, or harm other beings or animals." : "Nunca uses la magia para manipular, asustar o dañar a otras personas o animales."}</p>
            </div>
            <div style="background: rgba(0,0,0,0.3); padding: 12px 16px; border-radius: 10px; border-left: 3px solid var(--gold-main);">
              <strong style="color: var(--gold-main);">${isEn ? "🌿 Elemental Reverence:" : "🌿 Respeto Elemental:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Always protect nature, trees, and every living creature on the planet." : "Protegé siempre a la naturaleza, a los árboles y a todos los seres vivos del planeta."}</p>
            </div>
            <div style="background: rgba(0,0,0,0.3); padding: 12px 16px; border-radius: 10px; border-left: 3px solid #9b5de5;">
              <strong style="color: #9b5de5;">${isEn ? "🔮 Secrecy & Discretion:" : "🔮 Sigilo y Discreción:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Keep your tools, altar, and Magical Name in quiet confidence to guard your power." : "Guardá en secreto tus herramientas, tu altar y tu Nombre Mágico para conservar tu fuerza."}</p>
            </div>
          </div>
        </div>

      </div>

      <!-- BANNER DE NAVEGACIÓN A HERRAMIENTAS -->
      <div class="fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(233,196,106,0.1), rgba(42,157,143,0.1)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div style="font-size: 3rem;">⚒️</div>
        <h3 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 1.9rem;">${isEn ? "Next Step: Craft Your Tools" : "Próximo Paso: Confeccioná tus Herramientas"}</h3>
        <p style="color: var(--text-main); max-width: 700px; margin: 8px auto 0 auto; font-size: 1.05rem; line-height: 1.6;">
          ${isEn 
            ? "Discover how to prepare your wand or staff, your pentacle, and your magic mirror in the Tools sanctuary." 
            : "Descubrí cómo preparar tu varita o bastón, tu pentáculo y tu espejo mágico en la sección de Herramientas."}
        </p>
        <button type="button" class="btn btn-gold btn-lg margin-top-md" onclick="switchMagicSubPage('altar')" style="padding: 12px 28px; font-weight: 700; cursor: pointer;">
          ${isEn ? "⚒️ Go to The Altar & Tools" : "⚒️ Ir a El Altar y Herramientas"}
        </button>
      </div>

    </div>
  `;
}

// SUB-PÁGINA 2: EL ALTAR Y LAS HERRAMIENTAS
function renderAltarSubPage(container) {
  if (typeof window !== "undefined" && window.location) {
    const p = window.location.pathname;
    if (p.includes("altar-varita")) currentAltarTool = "varita";
    else if (p.includes("altar-pentaculo")) currentAltarTool = "pentaculo";
    else if (p.includes("altar-espejo")) currentAltarTool = "espejo";
    else if (p.includes("altar-dragonscript")) currentAltarTool = "dragonscript";
  }

  const isEn = magicIsEn();
  let toolContentHtml = "";

  if (currentAltarTool === "varita") {
    toolContentHtml = `
      <!-- GUIA COMPLETA DE CREACION DE VARITA Y BASTON -->
      <div class="fantasy-panel" style="padding: 2rem; background: rgba(15, 23, 42, 0.7); border: 2px solid var(--gold-main); border-radius: 18px;">
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 1rem;">
          <div style="font-size: 2.5rem;">✨</div>
          <div>
            <h3 style="color: var(--gold-main); margin: 0; font-size: 1.8rem;">${isEn ? "The Draconian Wand or Staff" : "La Varita o Bastón Draconiano"}</h3>
            <p style="color: var(--text-muted); margin: 4px 0 0 0; font-size: 0.95rem;">${isEn ? "Complete manual of crafting, attuning, and safety for young wizards" : "Manual completo de confección, sintonización y seguridad para jóvenes magos"}</p>
          </div>
        </div>

        <div style="background: rgba(233,196,106,0.1); border-left: 4px solid var(--gold-main); padding: 14px 18px; border-radius: 8px; margin-bottom: 1.5rem;">
          <p style="color: var(--text-main); margin: 0; font-size: 1rem; line-height: 1.6;">
            ${isEn 
              ? "<strong>✨ The Wizards' Great Secret:</strong> No tool, no matter how beautiful, possesses magical power on its own. True power comes from within you and from your connection with the universe. Your wand or staff simply functions like a lens or laser beam that helps you concentrate and direct your invisible energy, preventing it from dispersing." 
              : "<strong>✨ El Gran Secreto de los Magos:</strong> Ninguna herramienta, por muy hermosa que sea, posee poder mágico por sí sola. El verdadero poder proviene de tu interior y de tu conexión con el universo. Tu varita o bastón funciona simplemente como una lente o rayo láser que te ayuda a concentrar y dirigir tu energía invisible, evitando que se disperse."}
          </p>
        </div>

        <!-- PASO 1 Y 2 -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem;">
          <div style="background: rgba(255,255,255,0.03); padding: 1.2rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
            <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "1. The Quest for Your Magical Material" : "1. La Búsqueda de tu Material Mágico"}</h4>
            <div style="width: 100%; max-width: 380px; margin: 0 auto 1rem auto; border-radius: 12px; overflow: hidden; border: 1px solid var(--border-gold); box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
              <img src="/assets/magic_wand_material.webp" alt="${isEn ? "Searching for a mystical branch on the beach" : "Búsqueda de rama mística en la playa"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
            </div>
            <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5;">${isEn ? "You don't need to spend your savings or search for super-rare woods! The most powerful tools are the ones you craft yourself or find in unusual ways:" : "¡No necesitás gastar tus ahorros ni buscar maderas súper raras! Las herramientas más poderosas son las que vos mismo fabricás o encontrás de formas inusuales:"}</p>
            <ul style="color: var(--text-main); font-size: 0.9rem; line-height: 1.5; padding-left: 1.2rem;">
              <li style="margin-bottom: 6px;">${isEn ? "<strong>Gifts of Nature:</strong> Walk through a park, forest, or beach and look for a fallen branch or driftwood worn by the sea. <em>Golden Rule: Never harm a living tree.</em> Walk with a calm mind and your intuition will tell you which one is right." : "<strong>Regalos de la Naturaleza:</strong> Caminá por un parque, bosque o playa y buscá una rama caída o madera desgastada por el mar. <em>Regla de Oro: Nunca lastimes a un árbol vivo.</em> Caminá con mente tranquila y tu intuición te dirá cuál es la adecuada."}</li>
              <li>${isEn ? "<strong>Hidden Wands:</strong> You can use a smooth wooden dowel, a copper tube, or a clear plastic tube. Plastic is very sturdy and looks great if you fill it!" : "<strong>Varitas Ocultas:</strong> Podés usar una varilla lisa de madera, un tubo de cobre o un tubo de plástico transparente. ¡El plástico es muy resistente y se ve genial si lo rellenás!"}</li>
            </ul>
          </div>

          <div style="background: rgba(255,255,255,0.03); padding: 1.2rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
            <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "2. The Measure of the Wizard" : "2. La Medida del Mago"}</h4>
            <div style="width: 100%; max-width: 380px; margin: 0 auto 1rem auto; border-radius: 12px; overflow: hidden; border: 1px solid var(--border-gold); box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
              <img src="/assets/magic_wand_measurement.webp" alt="${isEn ? "Young wizard tuning his wand's measure in his room" : "Joven mago sintonizando la medida de su varita en su cuarto"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
            </div>
            <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5;">${isEn ? "In draconian magic, the dimensions of your tools depend on your own body:" : "En la magia draconiana, la dimensión de tus herramientas depende de tu propio cuerpo:"}</p>
            <ul style="color: var(--text-main); font-size: 0.9rem; line-height: 1.5; padding-left: 1.2rem;">
              <li style="margin-bottom: 6px;">${isEn ? "<strong>For a Wand (Air Element):</strong> Serves to project your willpower. It should not be longer than the distance <strong>from your elbow to the tips of your fingers</strong>. If it is longer, it becomes clumsy inside the magic circle." : "<strong>Para una Varita (Elemento Aire):</strong> Sirve para proyectar tu fuerza de voluntad. No debe ser más larga que la distancia <strong>desde tu codo hasta la punta de tus dedos</strong>. Si es más larga, resulta torpe dentro del círculo mágico."}</li>
              <li>${isEn ? "<strong>For a Staff (Spirit Element):</strong> Acts as a bridge to astral planes. For walking outdoors, it should reach <strong>only up to your shoulder height</strong> to avoid bumping and knocking items off the altar." : "<strong>Para un Bastón (Elemento Espíritu):</strong> Funciona como puente hacia los planos astrales. Para caminar al aire libre, debe llegar <strong>solo hasta la altura de tus hombros</strong> para evitar golpear y tirar objetos del altar."}</li>
            </ul>
          </div>
        </div>

        <!-- PASO 3 -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.2rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: var(--gold-main); margin-top: 0; font-size: 1.2rem;">${isEn ? "3. The Art of Decorating Your Tool" : "3. El Arte de Decorar tu Herramienta"}</h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem;">
            <div>
              <strong style="color: #e9c46a;">${isEn ? "💎 Power Tip:" : "💎 Punta de Poder:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Glue a quartz crystal point or shiny gemstone at the tip as an energy focus. If you use a transparent tube, fill it with colored pebbles and cap it with a black or dark stone." : "Pegá una punta de cuarzo o gema brillante en el extremo como foco de energía. Si usás un tubo transparente, rellenalo con piedritas de colores y tapalo con una piedra negra u oscura."}</p>
            </div>
            <div>
              <strong style="color: #e9c46a;">${isEn ? "⚡ Copper & Leather:" : "⚡ Cobre y Cuero:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Wrap the center with copper wire to empower the stones. Tie leather strips around the grip to insulate static electricity." : "Envolvé el centro con alambre de cobre para potenciar las piedras. Atá tiras de cuero en el agarre para aislar la electricidad estática."}</p>
            </div>
            <div>
              <strong style="color: #e9c46a;">${isEn ? "🎨 Elemental Colors:" : "🎨 Colores Elementales:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Tie ribbons of the 4 elements: Red (Fire), Yellow (Air), Blue (Water), and Green/Black (Earth)." : "Atá cintas de los 4 elementos: Rojo (Fuego), Amarillo (Aire), Azul (Agua) y Verde/Negro (Tierra)."}</p>
            </div>
            <div>
              <strong style="color: #e9c46a;">${isEn ? "🔔 Dragon Music & Name:" : "🔔 Música para Dragones & Nombre:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Add small bells to the ribbons to attract dragons with their vibrations. Paint your Magical Name in " : "Agregá campanitas en las cintas para atraer dragones con sus vibraciones. Pintá tu Nombre Mágico en "}<a href="javascript:void(0)" onclick="switchAltarTool('dragonscript')" style="color: var(--gold-main); font-weight: 700; text-decoration: underline;">${isEn ? "Dragon Script Alphabet" : "Alfabeto Draconiano (Dragon Script)"}</a>.</p>
            </div>
          </div>
        </div>

        <!-- PASO 4: REGLA DE SEGURIDAD -->
        <div style="background: rgba(230, 57, 70, 0.15); border: 2px solid #e63946; padding: 1.2rem; border-radius: 12px; margin-bottom: 1.5rem;">
          <h4 style="color: #ff4d6d; margin-top: 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
            ${isEn ? "⚠️ Dragon Safety Rule (Very Important!)" : "⚠️ Regla de Seguridad del Dragón (¡Muy Importante!)"}
          </h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin: 0;">
            ${isEn 
              ? "Your wand <strong>is not a toy or a pretend sword</strong>. Once you use it in magic, it charges with concentrated energy. <strong>Never point or wave your wand at people or pets</strong>: the energy streams out like a laser beam and would hit their Aura (protective shield), potentially causing fatigue, bad moods, or poor fortune. Treat your tools with absolute respect!" 
              : "Tu varita <strong>no es un juguete ni una espada de mentira</strong>. Una vez que la usás en magia, se carga de energía concentrada. <strong>Nunca apuntés ni agités tu varita hacia personas o mascotas</strong>: la energía sale como un rayo láser e incidiría en su Aura (escudo protector), pudiendo causarles cansancio, mal humor o mala suerte. ¡Tratá tus herramientas con absoluto respeto!"}
          </p>
        </div>

        <!-- PASO 5: RITUAL DE DESPERTAR -->
        <div style="background: linear-gradient(135deg, rgba(42,157,143,0.15), rgba(138,43,226,0.15)); border: 1px solid var(--color-teal); padding: 1.4rem; border-radius: 12px;">
          <h4 style="color: var(--color-teal); margin-top: 0; font-size: 1.25rem;">${isEn ? "5. The Awakening Ritual (Consecration)" : "5. El Ritual de Despertar (Consagración)"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5; margin-bottom: 10px;">
            ${isEn ? "Preferably performed on a <strong>Full or Waxing Moon</strong> night:" : "Se realiza preferentemente en noche de <strong>Luna Llena o Creciente</strong>:"}
          </p>
          <ol style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; padding-left: 1.2rem;">
            <li style="margin-bottom: 8px;">${isEn 
              ? 'Gently sprinkle the wand with droplets of pure water and say aloud:<br><em style="color: var(--gold-main); font-weight: bold;">"I ask the dragons to cleanse this wand with spiritual energy"</em>.' 
              : 'Rociá suavemente la varita con gotitas de agua pura y di en voz alta:<br><em style="color: var(--gold-main); font-weight: bold;">"Pido a los dragones que limpien esta varita con energía espiritual"</em>.'}</li>
            <li style="margin-bottom: 8px;">${isEn ? "Pass it over incense smoke while reciting this incantation:" : "Pasala sobre el humo de incienso recitando este conjuro:"}
              <div style="background: rgba(0,0,0,0.4); padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid var(--gold-main); color: var(--text-gold); font-style: italic;">
                ${isEn 
                  ? '"Mighty dragons, ancient and bold,<br>Fill this wand with power untold.<br>Teach me its virtues, light over dark,<br>And make it shine with your sacred spark"' 
                  : '"Poderosos dragones, fuertes y ancianos,<br>Llenen mi varita con poder en mis manos.<br>Enséñenme sus usos, el bien sobre el mal,<br>Y háganla brillar con su canción magistral"'}
              </div>
            </li>
            <li>${isEn ? "Leave it overnight next to the window exposed to the Full Moon light for at least 2 hours." : "Dejala durante la noche junto a la ventana expuesta a la luz de la Luna Llena por al menos 2 horas."}</li>
          </ol>
        </div>
      </div>
    `;
  } else if (currentAltarTool === "pentaculo") {
    toolContentHtml = `
      <div class="fantasy-panel" style="padding: 2rem; background: rgba(15, 23, 42, 0.7); border: 2px solid var(--color-teal); border-radius: 18px;">

        <!-- ENCABEZADO -->
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 1rem;">
          <div style="font-size: 2.5rem;">⭐</div>
          <div>
            <h3 style="color: var(--color-teal); margin: 0; font-size: 1.8rem;">${isEn ? "The Dragon's Pentacle" : "El Pentáculo del Dragón"}</h3>
            <p style="color: var(--text-muted); margin: 4px 0 0 0; font-size: 0.95rem;">${isEn ? "Your magical shield and badge of authority before dragons" : "Tu escudo mágico y medalla de autoridad ante los dragones"}</p>
          </div>
        </div>

        <!-- INTRODUCCIÓN CON ILUSTRACIÓN -->
        <div style="background: rgba(42,157,143,0.1); border-left: 4px solid var(--color-teal); padding: 16px 20px; border-radius: 12px; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap;">
          <div style="flex: 1; min-width: 280px;">
            <p style="color: var(--text-main); margin: 0; font-size: 1rem; line-height: 1.7;">
              ${isEn 
                ? "Every great magical lab equipment needs a safe foundation! In Draconian Magic, that base is the <strong>Dragon's Pentacle</strong>. It is not an attacking weapon, but acts as an <strong>energy shield</strong>, a balancer, and your magical 'badge of authority'. When dragons see your Pentacle, they immediately know you are a serious, friendly wizard worthy of respect." 
                : "¡Todo gran equipo de laboratorio mágico necesita una base segura! En la Magia Draconiana, esa base es el <strong>Pentáculo del Dragón</strong>. No es un arma para atacar, sino que funciona como un <strong>escudo de energía</strong>, un equilibrador y tu 'medalla de autoridad' mágica. Cuando los dragones ven tu Pentáculo, saben de inmediato que sos un mago serio, amigable y digno de respeto."}
            </p>
          </div>
          <div style="width: 100%; max-width: 260px; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); box-shadow: 0 6px 18px rgba(0,0,0,0.6); flex-shrink: 0; margin: 0 auto;">
            <img src="/assets/clay_pentacle_altar.webp" alt="${isEn ? "The Dragon's Pentacle made of clay on the altar" : "El Pentáculo del Dragón hecho de arcilla en el altar"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
          </div>
        </div>

        <!-- PASO 1: FABRICAR -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "1. Craft Your Own Pentacle!" : "1. ¡Fabrica tu propio Pentáculo!"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-bottom: 10px;">
            ${isEn 
              ? "The Pentacle is usually a flat disc drawn with a five-pointed star (a pentagram). Dragons don't care if it's made of gold or paper; what matters to them is that <strong>you make it yourself</strong>!" 
              : "El Pentáculo suele ser un disco plano con el dibujo de una estrella de cinco puntas (un pentagrama). A los dragones no les importa si está hecho de oro o de papel, ¡lo que les importa es que <strong>lo hagas vos mismo</strong>!"}
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem;">
            <div style="background: rgba(233,196,106,0.07); padding: 10px 14px; border-radius: 8px; border-left: 3px solid var(--gold-main);">
              <strong style="color: var(--gold-main);">${isEn ? "🪵 Materials:" : "🪵 Materiales:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 6px 0 0 0; line-height: 1.5;">${isEn ? "Find a flat wooden circle at a craft store, use a clay disc you sculpt yourself, or cut a perfect circle out of thick, sturdy cardboard." : "Buscá un círculo de madera plano en una tienda de manualidades, usá un disco de arcilla que modeles vos mismo, o recortá un círculo perfecto en cartón grueso y resistente."}</p>
            </div>
            <div style="background: rgba(233,196,106,0.07); padding: 10px 14px; border-radius: 8px; border-left: 3px solid var(--gold-main);">
              <strong style="color: var(--gold-main);">${isEn ? "🎨 The Drawing:" : "🎨 El Dibujo:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 6px 0 0 0; line-height: 1.5;">${isEn ? "Draw a five-pointed star in the center with your best markers. It is very powerful to draw a dragon embracing the star or holding it with its claws! Use the colors you like best." : "Dibujá una estrella de cinco puntas en el centro con tus mejores marcadores. ¡Es muy poderoso dibujar un dragón abrazando la estrella o sosteniéndola con sus garras! Usá los colores que más te gusten."}</p>
            </div>
          </div>
        </div>

        <!-- PASO 2: LAS CINCO PUNTAS -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "2. The Secret of the Five Points" : "2. El Secreto de las Cinco Puntas"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1rem;">
            ${isEn ? "Why a star? In ancient magic, the universe is made of great forces. Each point of your star represents an element:" : "¿Por qué una estrella? En la magia antigua, el universo está formado por grandes fuerzas. Cada punta de tu estrella representa un elemento:"}
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 8px; text-align: center; margin-bottom: 1rem;">
            <div style="background: rgba(139,90,43,0.2); padding: 10px 8px; border-radius: 10px; border: 1px solid rgba(139,90,43,0.4);">
              <div style="font-size: 1.6rem;">🌍</div>
              <strong style="color: #c4a35a; font-size: 0.85rem;">${isEn ? "Earth" : "Tierra"}</strong>
            </div>
            <div style="background: rgba(100,180,255,0.15); padding: 10px 8px; border-radius: 10px; border: 1px solid rgba(100,180,255,0.4);">
              <div style="font-size: 1.6rem;">💨</div>
              <strong style="color: #7ecef4; font-size: 0.85rem;">${isEn ? "Air" : "Aire"}</strong>
            </div>
            <div style="background: rgba(230,57,70,0.15); padding: 10px 8px; border-radius: 10px; border: 1px solid rgba(230,57,70,0.4);">
              <div style="font-size: 1.6rem;">🔥</div>
              <strong style="color: #ff6b6b; font-size: 0.85rem;">${isEn ? "Fire" : "Fuego"}</strong>
            </div>
            <div style="background: rgba(30,100,200,0.15); padding: 10px 8px; border-radius: 10px; border: 1px solid rgba(30,100,200,0.4);">
              <div style="font-size: 1.6rem;">💧</div>
              <strong style="color: #74c0fc; font-size: 0.85rem;">${isEn ? "Water" : "Agua"}</strong>
            </div>
            <div style="background: rgba(138,43,226,0.2); padding: 10px 8px; border-radius: 10px; border: 2px solid rgba(138,43,226,0.6);">
              <div style="font-size: 1.6rem;">✨</div>
              <strong style="color: #c77dff; font-size: 0.85rem;">${isEn ? "Spirit ↑" : "Espíritu ↑"}</strong>
              <p style="color: var(--text-muted); font-size: 0.75rem; margin: 3px 0 0 0;">${isEn ? "Your magic!" : "¡Tu magia!"}</p>
            </div>
          </div>
          <p style="color: var(--text-main); font-size: 0.9rem; line-height: 1.6; margin: 0;">
            ${isEn 
              ? "Having your Pentacle on the altar helps keep all these energies calm and in perfect balance, acting like a &quot;vacuum&quot; that catches bad vibes and keeps your room safe." 
              : "Tener tu Pentáculo en el altar ayuda a que todas estas energías se mantengan tranquilas y en perfecto equilibrio, funcionando como una &quot;aspiradora&quot; que atrapa las malas vibras y mantiene tu cuarto seguro."}
          </p>
        </div>

        <!-- PASO 3: REGLA DE SEGURIDAD + DIAGRAMA SÍ/NO -->
        <div style="background: rgba(230, 57, 70, 0.12); border: 2px solid #e63946; padding: 1.4rem; border-radius: 12px; margin-bottom: 1.5rem;">
          <h4 style="color: #ff4d6d; margin-top: 0; font-size: 1.2rem;">${isEn ? "⚠️ The Great Safety Rule (Very Important!)" : "⚠️ La Gran Regla de Seguridad (¡Muy Importante!)"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.2rem;">
            ${isEn 
              ? "The Pentacle is a symbol of harmony, health, and mystical powers, but it has a <strong>golden rule</strong> you must never forget:" 
              : "El Pentáculo es un símbolo de armonía, salud y poderes místicos, pero tiene una <strong>regla de oro</strong> que nunca debés olvidar:"}
          </p>

          <!-- DIAGRAMA SÍ / NO -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; max-width: 500px; margin: 0 auto;">
            <!-- SÍ -->
            <div style="background: rgba(42,157,143,0.15); border: 2px solid var(--color-teal); border-radius: 12px; padding: 1rem; text-align: center;">
              <div style="font-size: 2rem; margin-bottom: 4px;">✅</div>
              <div style="font-size: 2.5rem; line-height: 1; margin-bottom: 6px; filter: drop-shadow(0 0 6px rgba(42,200,150,0.8));">⭐</div>
              <strong style="color: var(--color-teal); font-size: 1rem;">${isEn ? "YES!" : "¡SÍ!"}</strong>
              <p style="color: var(--text-main); font-size: 0.8rem; margin: 6px 0 0 0; line-height: 1.4;">${isEn ? "A single point <strong>pointing upward</strong> (to the sky). Attracts good magic and friendly dragons. ✨🐉" : "Una sola punta <strong>apuntando hacia arriba</strong> (al cielo). Atrae buena magia y dragones amigables. ✨🐉"}</p>
            </div>
            <!-- NO -->
            <div style="background: rgba(230,57,70,0.12); border: 2px solid #e63946; border-radius: 12px; padding: 1rem; text-align: center;">
              <div style="font-size: 2rem; margin-bottom: 4px;">❌</div>
              <div style="font-size: 2.5rem; line-height: 1; margin-bottom: 6px; transform: rotate(180deg); display: inline-block; filter: drop-shadow(0 0 6px rgba(230,57,70,0.7));">⭐</div>
              <strong style="color: #ff4d6d; font-size: 1rem;">${isEn ? "NO!" : "¡NO!"}</strong>
              <p style="color: var(--text-main); font-size: 0.8rem; margin: 6px 0 0 0; line-height: 1.4;">${isEn ? "Inverted with <strong>two points facing up</strong>. Attracts confusion, bad mood, and chaotic magic. 😵🌀" : "Invertida con <strong>dos puntas hacia arriba</strong>. Atrae confusiones, mal humor y magia caótica. 😵🌀"}</p>
            </div>
          </div>
        </div>

        <!-- PASO 4: CONSAGRACIÓN -->
        <div style="background: linear-gradient(135deg, rgba(42,157,143,0.15), rgba(138,43,226,0.15)); border: 1px solid var(--color-teal); padding: 1.4rem; border-radius: 12px;">
          <h4 style="color: var(--color-teal); margin-top: 0; font-size: 1.25rem;">${isEn ? "4. The Awakening Spell (Consecration)" : "4. El Hechizo de Despertar (Consagración)"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5; margin-bottom: 1rem;">
            ${isEn ? "Once finished painting and decorating your disc, you must purify it to fill it with magic:" : "Una vez terminado de pintar y decorar tu disco, tienes que purificarlo para llenarlo de magia:"}
          </p>
          <ol style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; padding-left: 1.2rem; margin-bottom: 1rem;">
            <li style="margin-bottom: 10px;">${isEn 
              ? "Ask an adult to help you light an incense stick that smells delicious (<strong>apple, sandalwood, or lavender</strong> are beloved by dragons). Take your Pentacle with your <strong>power hand</strong> (the hand you write with) and pass it slowly through the smoke while saying:" 
              : "Pedile a un adulto que te ayude a encender una varita de incienso que huela muy rico (el de <strong>manzana, sándalo o lavanda</strong> les encanta a los dragones). Toma tu Pentáculo con tu <strong>mano de poder</strong> (la mano con la que escribes) y pasalo lentamente a través del humo mientras dices:"}
              <div style="background: rgba(0,0,0,0.4); padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid var(--color-teal); color: #a8dadc; font-style: italic; line-height: 1.6;">
                ${isEn ? '"Element of Spirit, by the power of the Dragon, I call you purified!"' : '"Elemento del Espíritu, por el poder del Dragón, ¡te llamo purificado!"'}
              </div>
            </li>
            <li style="margin-bottom: 10px;">${isEn 
              ? "Raise your Pentacle before you, facing <strong>East</strong>, and present it to your guardians saying:" 
              : "Levanta tu Pentáculo frente a vos, mirando hacia el <strong>Este</strong>, y presentalo a tus guardianes diciendo:"}
              <div style="background: rgba(0,0,0,0.4); padding: 12px; border-radius: 8px; margin: 8px 0; border-left: 4px solid var(--gold-main); color: var(--text-gold); font-style: italic; line-height: 1.6;">
                ${isEn ? '"Dragons of magic, behold my symbol and be my allies"' : '"Dragones de la magia, contemplen mi símbolo y sean mis aliados"'}
              </div>
            </li>
            <li>${isEn 
              ? "Done! Place your Pentacle at the <strong>center of your altar</strong>. Now you can place your amulets, stones, or Wand on top of it to recharge them with clean, balanced energy. 🐉⭐" 
              : "¡Listo! Pon tu Pentáculo en el <strong>centro de tu altar</strong>. Ahora podés poner encima de él tus amuletos, tus piedras o tu Varita para recargarlos de energía limpia y equilibrada. 🐉⭐"}</li>
          </ol>
        </div>

      </div>
    `;
  } else if (currentAltarTool === "espejo") {
    toolContentHtml = `
      <div class="fantasy-panel" style="padding: 2rem; background: rgba(15, 23, 42, 0.7); border: 2px solid var(--color-rust); border-radius: 18px;">
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 1rem;">
          <div style="font-size: 2.5rem;">👁️</div>
          <div>
            <h3 style="color: var(--color-rust); margin: 0; font-size: 1.8rem;">${isEn ? "The Magic Mirror (Dragon's Eye)" : "El Espejo Mágico (Ojo de Dragón)"}</h3>
            <p style="color: var(--text-muted); margin: 4px 0 0 0; font-size: 0.95rem;">${isEn ? "Deflecting shield, imagination screen, and eye into the dragon realm" : "Escudo rebotador, pantalla de imaginación y ojo al mundo de los dragones"}</p>
          </div>
        </div>

        <!-- INTRODUCCIÓN CON ILUSTRACIÓN -->
        <div style="background: rgba(200,85,61,0.1); border-left: 4px solid var(--color-rust); padding: 16px 20px; border-radius: 12px; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap;">
          <div style="flex: 1; min-width: 280px;">
            <p style="color: var(--text-main); margin: 0; font-size: 1rem; line-height: 1.7;">
              ${isEn 
                ? "So far you have your Wand (to direct your energy) and your Pentacle (your safe base). But a draconian wizard's equipment is not complete without the <strong>Magic Mirror</strong>! In dragon magic, the mirror represents the <strong>Earth element</strong> and is not used for grooming. It is used as the <strong>'Dragon\'s Eye'</strong>: a super-secret tool to catch good ideas, protect you from bad vibes, and peer into the world of imagination." 
                : "Hasta ahora tenés tu Varita (para dirigir tu energía) y tu Pentáculo (tu base segura). ¡Pero el equipo de un mago draconiano no está completo sin el <strong>Espejo Mágico</strong>! En la magia de los dragones, el espejo representa el <strong>elemento Tierra</strong> y no se usa para peinarse. Se usa como el <strong>'Ojo del Dragón'</strong>: una herramienta súper secreta para atrapar buenas ideas, protegerte de las malas vibras y asomarte al mundo de la imaginación."}
            </p>
          </div>
          <div style="width: 100%; max-width: 260px; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); box-shadow: 0 6px 18px rgba(0,0,0,0.6); flex-shrink: 0; margin: 0 auto;">
            <img src="/assets/magic_mirror_wooden.webp" alt="${isEn ? "The Magic Mirror with mystical wooden frame" : "El Espejo Mágico con marco de madera místico"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
          </div>
        </div>

        <!-- PASO 1: CREAR EL ESPEJO -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "1. Create Your Own Dragon's Eye!" : "1. ¡Crea tu propio Ojo de Dragón!"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5; margin-bottom: 1.2rem;">${isEn ? "Magic mirrors are very easy to make. You can choose between <strong>two incredible types</strong>:" : "Los espejos mágicos son muy fáciles de hacer. Podés elegir entre <strong>dos tipos increíbles</strong>:"}</p>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem;">
            <!-- ESPEJO BRILLANTE -->
            <div style="background: rgba(233,196,106,0.07); border: 1px solid rgba(233,196,106,0.3); border-radius: 12px; padding: 1.2rem;">
              <div style="font-size: 1.8rem; margin-bottom: 6px;">✨</div>
              <strong style="color: var(--gold-main); font-size: 1.05rem;">${isEn ? "The Shiny Mirror" : "El Espejo Brillante"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 8px 0 0 0; line-height: 1.5;">${isEn ? "Get any small mirror that has a flat wooden or plastic frame. The older and more mysterious the frame looks, the better!" : "Conseguí cualquier espejo pequeño que tenga un marco de madera o de plástico plano. ¡Entre más viejo y misterioso se vea el marco, mejor!"}</p>
            </div>
            <!-- ESPEJO OSCURO -->
            <div style="background: rgba(20,20,30,0.6); border: 2px solid rgba(200,85,61,0.5); border-radius: 12px; padding: 1.2rem; position: relative; overflow: hidden;">
              <div style="font-size: 1.8rem; margin-bottom: 6px;">🌑</div>
              <strong style="color: #c8553d; font-size: 1.05rem;">${isEn ? "The Dark Mirror" : "El Espejo Oscuro"} <span style="color: var(--text-muted); font-size: 0.8rem;">${isEn ? "(The sorcerers' secret)" : "(El secreto de los hechiceros)"}</span></strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 8px 0 0 0; line-height: 1.5;">${isEn ? "Dragons love peering through &ldquo;black mirrors&rdquo;. To make one:" : "A los dragones les encanta asomarse por &ldquo;espejos negros&rdquo;. Para hacer uno:"}</p>
              <ol style="color: var(--text-main); font-size: 0.88rem; line-height: 1.5; padding-left: 1.2rem; margin: 8px 0 0 0;">
                <li style="margin-bottom: 4px;">${isEn ? "Get a small picture frame." : "Conseguí un portarretratos pequeño."}</li>
                <li style="margin-bottom: 4px;">${isEn ? "Ask an adult to help you remove the glass." : "Pedile a un adulto que te ayude a sacar el vidrio."}</li>
                <li style="margin-bottom: 4px;">${isEn ? "Paint only one side of the glass with plenty of <strong>black acrylic paint</strong>." : "Pintá solo un lado del vidrio con mucha <strong>pintura acrílica negra</strong>."}</li>
                <li style="margin-bottom: 4px;">${isEn ? "When dry, reassemble the picture frame with the painted part facing back." : "Cuando seque, volvé a armar el portarretratos con la parte pintada hacia atrás."}</li>
                <li>${isEn ? "The front will look like a super shiny, mysterious black mirror! 🖤" : "¡El frente se verá como un espejo negro súper brillante y misterioso! 🖤"}</li>
              </ol>
            </div>
          </div>
        </div>

        <!-- PASO 2: CONJURO DEL MARCO -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "2. The Frame Incantation (The Secret Alphabet)" : "2. El Conjuro del Marco (El Alfabeto Secreto)"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1rem;">
            ${isEn ? "For the mirror to awaken, you must write a magical instruction on it. Use a <strong>permanent marker</strong> (gold or silver looks great) to write all around the frame:" : "Para que el espejo despierte, tenés que escribirle una instrucción mágica. Usá un <strong>marcador permanente</strong> (dorado o plateado se ve genial) para escribir alrededor de todo el marco:"}
          </p>
          <div style="background: rgba(0,0,0,0.5); border: 2px solid var(--gold-main); padding: 1.2rem 1.5rem; border-radius: 12px; text-align: center; margin-bottom: 1rem;">
            <p style="color: var(--gold-main); font-style: italic; font-size: 1.05rem; line-height: 1.7; margin: 0;">
              ${isEn 
                ? "By the power of the Dragon's Eye,<br>I capture visionary thoughts<br>and bounce back discordant energy" 
                : "Por el poder del Ojo del Dragón,<br>atrapo los pensamientos mágicos<br>y reboto la mala energía"}
            </p>
          </div>
          <div style="background: rgba(138,43,226,0.12); border-left: 4px solid #9b5de5; padding: 12px 16px; border-radius: 8px;">
            <p style="color: var(--text-main); font-size: 0.92rem; margin: 0; line-height: 1.6;">
              💡 <strong>${isEn ? "Super Tip!" : "¡Súper Tip!"}</strong> ${isEn 
                ? 'If you want it to look like a true ancient artifact, use the <a href="javascript:void(0)" onclick="switchAltarTool(\'dragonscript\'); window.scrollTo({top: 300, behavior: \'smooth\'});" style="color: var(--gold-main); font-weight: bold; text-decoration: underline; background: rgba(255,215,0,0.15); padding: 2px 8px; border-radius: 6px; border: 1px solid var(--gold-main);">📜 Dragon Script Alphabet</a> from our secret codes section to write this message. No one but wizards will be able to read it! 🐉🔮' 
                : 'Si querés que se vea como un verdadero artefacto antiguo, usá el <a href="javascript:void(0)" onclick="switchAltarTool(\'dragonscript\'); window.scrollTo({top: 300, behavior: \'smooth\'});" style="color: var(--gold-main); font-weight: bold; text-decoration: underline; background: rgba(255,215,0,0.15); padding: 2px 8px; border-radius: 6px; border: 1px solid var(--gold-main);">📜 Alfabeto de los Dragones (Dragon Script)</a> de nuestra sección de códigos secretos para escribir este mensaje. ¡Nadie más que los magos podrá leerlo! 🐉🔮'}
            </p>
          </div>
        </div>

        <!-- PASO 3: LOS DOS SUPERPODERES -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 1.5rem;">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "3. The Two Superpowers of Your Mirror" : "3. Los Dos Súper Poderes de tu Espejo"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.5; margin-bottom: 1rem;">${isEn ? "Once ready, your magic mirror has <strong>two main functions</strong>:" : "Una vez que está listo, tu espejo mágico tiene <strong>dos funciones principales</strong>:"}</p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem;">

            <!-- PODER 1: ESCUDO REBOTADOR -->
            <div style="background: linear-gradient(135deg, rgba(42,157,143,0.1), rgba(42,157,143,0.05)); border: 2px solid var(--color-teal); border-radius: 12px; padding: 1.2rem;">
              <div style="font-size: 2rem; margin-bottom: 6px;">🛡️</div>
              <strong style="color: var(--color-teal); font-size: 1.05rem;">${isEn ? "The Deflecting Shield" : "El Escudo Rebotador"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 8px 0 0 0; line-height: 1.5;">
                ${isEn ? "If you had a bad day, or someone said hurtful words that made you feel sad (we call this &ldquo;harmful energy&rdquo;), don't let them stay with you!" : "Si tuviste un mal día, o alguien te dijo palabras feas que te hicieron sentir triste (a esto le llamamos &ldquo;energía dañina&rdquo;), ¡no dejes que se queden con vos!"}
              </p>
              <div style="background: rgba(0,0,0,0.3); border-radius: 8px; padding: 10px 12px; margin-top: 10px; border-left: 3px solid var(--color-teal);">
                <p style="color: var(--text-main); font-size: 0.88rem; margin: 0; line-height: 1.5;">
                  ${isEn 
                    ? 'Hold the mirror in front of you with the reflective side pointing <strong>outward</strong> (toward the world) and imagine the figure of a giant dragon appearing in the glass. Think with great focus:<br><em style="color: var(--color-teal);">"May bad energy return to where it came from!"</em><br>The mirror will bounce the bad mood away from you. 💚' 
                    : 'Sostené el espejo frente a vos con la parte que refleja apuntando <strong>hacia afuera</strong> (hacia el mundo) e imaginá que la figura de un dragón gigante aparece en el cristal. Pensá con mucha fuerza:<br><em style="color: var(--color-teal);">"¡Que la mala energía regrese a donde vino!"</em><br>El espejo rebotará el mal humor lejos de vos. 💚'}
                </p>
              </div>
            </div>

            <!-- PODER 2: PANTALLA DE IMAGINACIÓN -->
            <div style="background: linear-gradient(135deg, rgba(138,43,226,0.12), rgba(138,43,226,0.05)); border: 2px solid #9b5de5; border-radius: 12px; padding: 1.2rem;">
              <div style="font-size: 2rem; margin-bottom: 6px;">🔮</div>
              <strong style="color: #c77dff; font-size: 1.05rem;">${isEn ? "The Screen of Imagination" : "La Pantalla de la Imaginación"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 8px 0 0 0; line-height: 1.5;">
                ${isEn ? "The black mirror functions as a television for your intuition. Just with the mirror on your altar in a room with soft light:" : "El espejo negro funciona como una televisión para tu intuición. Solo con el espejo en tu altar en una habitación con luz suave:"}
              </p>
              <ol style="color: var(--text-main); font-size: 0.88rem; line-height: 1.5; padding-left: 1.2rem; margin: 8px 0 0 0;">
                <li style="margin-bottom: 4px;">${isEn ? "Sit, relax, and look deeply into the glass <strong>without straining your eyes</strong>, letting your vision soften slightly." : "Sentate, relajate y mirá profundamente el cristal <strong>sin esforzar los ojos</strong>, dejando que tu vista se vuelva un poco borrosa."}</li>
                <li style="margin-bottom: 4px;">${isEn ? "<strong>Do not try to force images!</strong> Just let your mind become quiet." : "¡<strong>No trates de forzar imágenes!</strong> Solo dejá que tu mente se calme."}</li>
                <li>${isEn ? "Sometimes you'll see colors, feel great ideas come out of nowhere, or even catch a glimpse of your <strong>Guardian Dragon</strong> greeting you. 🐉✨" : "A veces verás colores, sentirás que se te ocurren ideas geniales de la nada, o incluso podrías ver un destello de tu <strong>Dragón Guardián</strong> saludándote. 🐉✨"}</li>
              </ol>
            </div>

          </div>
        </div>

        <!-- PASO 4: REGLA DE LIMPIEZA -->
        <div style="background: rgba(42,157,143,0.1); border: 1px solid var(--color-teal); padding: 1.4rem; border-radius: 12px;">
          <h4 style="color: var(--color-teal); margin-top: 0; font-size: 1.2rem;">${isEn ? "💧 The Cleansing Rule (Washing Astral Dust)" : "💧 La Regla de Limpieza (Lavando el &quot;Polvo Astral&quot;)"}</h4>
          <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin: 0;">
            ${isEn 
              ? "Because mirrors catch thoughts and bounce away bad moods, they sometimes get <em>soiled with invisible energy</em>. If you feel your mirror no longer shines the same or you are grumpy when using it, it is time for a magic bath! Wash it with a little <strong>pure water and gentle soap</strong> to remove all &quot;astral dust&quot; and let it rest. 🌊✨" 
              : "Como los espejos atrapan pensamientos y rebotan el mal humor, a veces se <em>&quot;ensucian&quot; de energía invisible</em>. Si sentís que tu espejo ya no brilla igual o estás de mal humor cuando lo usás, ¡es hora de un baño mágico! Lavalo con un poquito de <strong>agua pura y jabón suave</strong> para quitarle todo el &quot;polvo astral&quot; y dejalo descansar. 🌊✨"}
          </p>
        </div>

      </div>
    `;
  } else if (currentAltarTool === "dragonscript") {
    toolContentHtml = `
      <div class="fantasy-panel" style="padding: 2rem; background: rgba(15, 23, 42, 0.75); border: 2px solid var(--gold-main); border-radius: 18px;">
        
        <!-- ENCABEZADO -->
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 1rem;">
          <div style="font-size: 2.5rem;">📜</div>
          <div>
            <h3 style="color: var(--gold-main); margin: 0; font-size: 1.8rem;">${isEn ? "The Alphabet of Dragons: Dragon Script" : "El Alfabeto de los Dragones: Dragon Script"}</h3>
            <p style="color: var(--text-muted); margin: 4px 0 0 0; font-size: 0.95rem;">${isEn ? "The ancient mystical cipher for communicating with draconian beings" : "El cifrado místico antiguo para comunicarte con los seres draconianos"}</p>
          </div>
        </div>

        <!-- INTRODUCCIÓN CON ILUSTRACIÓN -->
        <div style="background: rgba(233,196,106,0.1); border-left: 4px solid var(--gold-main); padding: 16px 20px; border-radius: 12px; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap;">
          <div style="flex: 1; min-width: 280px;">
            <p style="color: var(--text-main); margin: 0; font-size: 1rem; line-height: 1.7;">
              ${isEn 
                ? "Can you imagine having a secret alphabet that only you and dragons can read? Well, it exists! In the wondrous world of draconian magic, this writing system is known as <strong>Dragon Script</strong> (or the Dragon's Runes). Dragons are immensely intelligent beings and know all human languages, but ancient teachings reveal that <strong>they pay much closer attention to things written using this special alphabet</strong>. It is like sending them a message sealed with a &quot;Super Important!&quot; stamp!" 
                : "¿Te imaginás tener un alfabeto secreto que solo vos y los dragones puedan leer? ¡Pues existe! En el maravilloso mundo de la magia draconiana, este sistema de escritura se conoce como <strong>Dragon Script</strong> (o el Escrito del Dragón). Los dragones son seres sumamente inteligentes y conocen todos los idiomas humanos, pero las fuentes nos revelan que <strong>ellos prestan muchísima más atención a las cosas que escribís usando este alfabeto especial</strong>. ¡Es como enviarles un mensaje con un sello de &quot;¡Súper Importante!&quot;!"}
            </p>
          </div>
          <div style="width: 100%; max-width: 260px; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); box-shadow: 0 6px 18px rgba(0,0,0,0.6); flex-shrink: 0; margin: 0 auto;">
            <img src="/assets/scholar_dragon_script.webp" alt="${isEn ? "Scholar dragon writing manuscript in Dragon Script in gothic hall" : "Dragón erudito escribiendo manuscrito en Dragon Script en salón gótico"}" style="width: 100%; height: auto; display: block; object-fit: cover;" />
          </div>
        </div>

        <!-- CONTENIDO PRINCIPAL: TEXTOS E HISTORIA -->
        <div style="display: flex; flex-direction: column; gap: 1.5rem; margin-bottom: 2rem;">
          
          <!-- 🌟 HISTORIA -->
          <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
            <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">${isEn ? "🌟 The Lore of the Mysterious Script" : "🌟 La Historia del Alfabeto Misterioso"}</h4>
            <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin: 0;">
              ${isEn 
                ? "No one knows with scientific certainty who originally invented this alphabet or how many thousands of years ago it was created, as its origin is a great mystery. What we do know is that it was taught to humans by a wise spiritual entity of Irish-Celtic origin who communicated with mages through dreams and deep meditations. If you look closely at its letters, you will notice they resemble other legendary alphabets such as <strong>Viking Runes</strong>, <strong>Celtic Ogham</strong>, and the ciphers of medieval alchemists." 
                : "Nadie sabe con certeza científica quién inventó originalmente este alfabeto o hace cuántos miles de años se creó, pues su origen es un gran misterio. Lo que sí sabemos es que fue enseñado a los humanos por una sabia entidad espiritual de origen irlandés-celta que se comunicaba con los magos a través de sueños y profundas meditaciones. Si mirás con atención sus letras, notarás que se parecen a otros alfabetos legendarios como las <strong>Runas vikingas</strong>, el <strong>Ogham celta</strong> y los códigos de los alquimistas medievales."}
            </p>
          </div>

          <!-- ⚡ POR QUÉ HACE TU MAGIA MÁS FUERTE -->
          <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
            <h4 style="color: var(--gold-main); margin-top: 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">${isEn ? "⚡ Why Does Writing in Dragon Script Make Your Magic Stronger?" : "⚡ ¿Por qué escribir en Dragon Script hace tu magia más fuerte?"}</h4>
            <p style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6; margin: 0;">
              ${isEn 
                ? "You might wonder: <em>&quot;Why not simply write in my normal letters?&quot;</em> The answer is a secret of wise enchanters! When you write a petition or your name using this alphabet, you must go slowly, letter by letter, consulting the symbol chart to avoid mistakes. That extra effort demands all your <strong>Concentration</strong>. By drawing each curve and mysterious stroke patiently, you are focusing your mind and <strong>transferring your own personal energy and willpower into the object</strong>. That is why tools and wishes inscribed in Dragon Script hum with incredible magical power!" 
                : "Seguramente te preguntarás: <em>&quot;¿Por qué no escribir simplemente con mis letras normales?&quot;</em> ¡La respuesta es un secreto de los sabios encantadores! Cuando escribís una petición o tu nombre usando este alfabeto, tenés que ir despacio, letra por letra, mirando la tabla de símbolos para no equivocarte. Ese esfuerzo extra requiere de toda tu <strong>Concentración</strong>. Al dibujar cada curva y cada línea misteriosa con paciencia, estás enfocando tu mente y <strong>traspasando tu propia energía personal y tu fuerza de voluntad al objeto</strong>. ¡Es por eso que las herramientas y los deseos escritos en Dragon Script se llenan de un poder mágico increíble!"}
            </p>
          </div>

          <!-- 🧩 TRADUCTOR INTERACTIVO ÚNICO Y OFICIAL -->
          <div style="background: linear-gradient(135deg, rgba(138,43,226,0.15), rgba(42,157,143,0.15)); border: 2px solid var(--color-teal); padding: 1.6rem; border-radius: 16px;">
            <div style="text-align: center; margin-bottom: 1rem;">
              <span style="font-size: 2.2rem;">🧩</span>
              <h4 style="color: var(--color-teal); margin: 6px 0 0 0; font-size: 1.4rem;">${isEn ? "Magical Dragon Script Translator" : "Traductor Mágico al Dragon Script"}</h4>
              <p style="color: var(--text-main); font-size: 0.95rem; margin-top: 4px;">${isEn ? "Type your real name, nickname, or intention to automatically translate each letter onto the digital scroll:" : "Escribí tu nombre real, apodo o deseo para traducir automáticamente cada letra al pergamino digital:"}</p>
            </div>

            <div style="max-width: 500px; margin: 0 auto 1.2rem auto;">
              <input type="text" id="ds-translator-input" oninput="updateDragonScriptTranslator()" placeholder="${isEn ? "Type your name or wish here (e.g. ARTHUR)..." : "Escribí tu nombre o deseo acá (ej: MATIAS)..."}" style="width: 100%; padding: 12px 16px; border-radius: 10px; border: 1px solid var(--gold-main); background: rgba(10,9,17,0.95); color: var(--text-main); font-size: 1.1rem; outline: none; font-weight: 700; text-align: center;" />
            </div>

            <!-- PERGAMINO OUTPUT -->
            <div style="background: rgba(0,0,0,0.5); padding: 4px; border-radius: 14px; box-shadow: 0 6px 20px rgba(0,0,0,0.5);">
              <div style="background: rgba(15, 12, 25, 0.92); backdrop-filter: blur(4px); padding: 1.5rem; border-radius: 10px; border: 1px solid var(--gold-main); min-height: 90px; display: flex; align-items: center; justify-content: center; gap: 8px; flex-wrap: wrap;" id="ds-translator-output">
                <span style="color: var(--text-muted); font-style: italic;">${isEn ? "Type your name or wish above to see it converted into Dragon Script..." : "Escribí tu nombre o deseo arriba para verlo convertido al Escrito del Dragón..."}</span>
              </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; flex-wrap: wrap; gap: 10px;">
              <span style="font-size: 0.85rem; color: var(--text-muted);">
                ✨ <em>${isEn ? "Check the equivalence of each rune or download the full composition in high resolution:" : "Mirá la equivalencia de cada letra o descargá la composición completa en alta resolución:"}</em>
              </span>
              <div>
                <button id="ds-download-all-btn" type="button" class="btn btn-gold btn-sm" style="display: none; padding: 8px 18px; font-weight: 700;" onclick="downloadDragonScriptImage()">
                  ${isEn ? "📥 Download Dragon Script Image" : "📥 Descargar Imagen Dragon Script"}
                </button>
              </div>
            </div>
          </div>

        </div>

        <!-- TABLA INTERACTIVA DE SÍMBOLOS CON SONIDO -->
        <div style="background: rgba(0,0,0,0.4); border: 1px solid var(--border-gold); padding: 1.5rem; border-radius: 14px; margin-bottom: 2rem;">
          <h4 style="color: var(--gold-main); margin-top: 0; font-size: 1.25rem; text-align: center;">
            ${isEn ? "🔊 Interactive Resonance Keyboard (Click any rune)" : "🔊 Teclado Interactivo de Resonancia (Hacé clic en cualquier letra)"}
          </h4>
          <p style="color: var(--text-muted); font-size: 0.9rem; text-align: center; margin-bottom: 1.2rem;">
            ${isEn ? "Click any letter to hear its harmonic rune resonance and reveal its spiritual meaning:" : "Tocá cualquier letra para escuchar su resonancia armónica de runa y ver su significado espiritual:"}
          </p>

          <!-- PREVIEW BADGE -->
          <div id="ds-rune-preview" style="min-height: 65px; background: rgba(233,196,106,0.08); border: 1px dashed var(--gold-main); border-radius: 10px; padding: 10px; margin-bottom: 1.2rem; display: flex; align-items: center; justify-content: center; text-align: center;">
            <span style="color: var(--text-muted); font-style: italic;">${isEn ? "Click a letter on the mystic keyboard below..." : "Hacé clic en una letra del teclado mágico inferior..."}</span>
          </div>

          <!-- GRID DE LETRAS CON VECTORES SVG OFICIALES -->
          <div id="ds-rune-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(54px, 1fr)); gap: 10px;">
            ${Object.keys(DRAGON_SCRIPT_MAP).map(letter => `
              <button type="button" class="btn btn-secondary" onclick="playRuneSound('${letter}')" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 10px 4px; font-weight: 700; border-radius: 10px; color: var(--gold-main);">
                ${DRAGON_SCRIPT_MAP[letter].svg || `<span style="font-size: 1.3rem;">${DRAGON_SCRIPT_MAP[letter].glyph}</span>`}
                <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: bold; margin-top: 4px;">${letter}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- 🛠️ ¿CÓMO PUEDES USAR EL DRAGON SCRIPT? -->
        <div style="background: rgba(255,255,255,0.03); padding: 1.4rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
          <h4 style="color: #4cc9f0; margin-top: 0; font-size: 1.2rem;">${isEn ? "🛠️ How Can You Use Dragon Script in Your Daily Life?" : "🛠️ ¿Cómo podés usar el Dragon Script en tu día a día?"}</h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <div style="background: rgba(233,196,106,0.07); padding: 12px 14px; border-radius: 8px; border-left: 3px solid var(--gold-main);">
              <strong style="color: var(--gold-main);">${isEn ? "1. Protect Your Wand or Staff:" : "1. Protegé tu Varita o Bastón:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "Paint your 'Magical Name' along the wood of your wand with gold or black marker using these characters. That way your wand will know it belongs to you alone." : "Pintá tu 'Nombre Mágico' a lo largo de la madera de tu varita con marcador dorado o negro usando estos caracteres. Así la varita sabrá que te pertenece solo a vos."}</p>
            </div>
            <div style="background: rgba(42,157,143,0.07); padding: 12px 14px; border-radius: 8px; border-left: 3px solid var(--color-teal);">
              <strong style="color: var(--color-teal);">${isEn ? "2. Magic Mirror Incantation:" : "2. Hechizo de tu Espejo Mágico:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "To activate your 'Dragon\'s Eye', inscribe around its frame the phrase: <em>&quot;By the power of the dragon\'s eye, I capture visionary thoughts&quot;</em> in Dragon Script." : "Para activar tu 'Ojo de Dragón', escribí en su marco la frase: <em>&quot;Por el poder del ojo del dragón, atrapo los pensamientos mágicos&quot;</em> en Dragon Script."}</p>
            </div>
            <div style="background: rgba(138,43,226,0.07); padding: 12px 14px; border-radius: 8px; border-left: 3px solid #9b5de5;">
              <strong style="color: #c77dff;">${isEn ? "3. Intention & Wish Scrolls:" : "3. Tus Cartas de Deseos:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "If you wish to ask your guardian dragon for advice on wisdom, courage, or calm, write your petition on parchment in Dragon Script and keep it in your secret diary." : "Si necesitás pedirle un consejo de sabiduría, valentía o calma a tu dragón guardián, escribí tu petición en un pergamino en Dragon Script y guardalo en tu diario secreto."}</p>
            </div>
            <div style="background: rgba(200,85,61,0.07); padding: 12px 14px; border-radius: 8px; border-left: 3px solid var(--color-rust);">
              <strong style="color: var(--color-rust);">${isEn ? "4. Intention Candles:" : "4. Velas de Deseos:"}</strong>
              <p style="color: var(--text-main); font-size: 0.9rem; margin: 4px 0 0 0; line-height: 1.5;">${isEn ? "With an adult's help, you can use a pointed stylus to carve your goals or intentions into the wax of a colored candle before lighting it for your ritual." : "Con la ayuda de un adulto, podés usar un objeto puntiagudo para tallar tus metas o deseos en la cera de una vela de color antes de encenderla para tu ritual."}</p>
            </div>
          </div>
        </div>

      </div>
    `;
  }

  container.innerHTML = `
    <div class="magic-section-wrapper" style="display: flex; flex-direction: column; gap: 2rem;">
      <div class="magic-hero fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(233,196,106,0.15), rgba(200,85,61,0.15)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div class="quiz-step-tag" style="font-size: 0.95rem;">${isEn ? "⚒️ The Wizard's Workshop ⚒️" : "⚒️ El Taller del Mago ⚒️"}</div>
        <h2 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 2.3rem;">${isEn ? "The Altar & Wizard's Tools" : "El Altar y las Herramientas del Mago"}</h2>
        <p style="color: var(--text-main); font-size: 1.1rem; max-width: 800px; margin: 12px auto 0 auto; line-height: 1.6;">
          ${isEn 
            ? "Choose one of the 4 artifact sections to learn their crafting, secret scripts, and sacred lore:" 
            : "Elegí una de las 4 subsecciones de artefactos y saberes para aprender su confección, alfabetos y reglas mágicas:"}
        </p>
        ${renderMagicSubNavHtml("altar")}
        
        <!-- BARRA DE SELECCIÓN DE HERRAMIENTAS -->
        <div class="margin-top-md text-center" style="display: flex; justify-content: center; gap: 8px; flex-wrap: wrap;">
          <a href="/altar-varita.html" class="chip ${currentAltarTool === "varita" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "✨ 1. Wand or Staff" : "✨ 1. Varita o Bastón"}</a>
          <a href="/altar-pentaculo.html" class="chip ${currentAltarTool === "pentaculo" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "⭐ 2. Pentacle (5 Elements)" : "⭐ 2. Pentáculo (5 Elementos)"}</a>
          <a href="/altar-espejo.html" class="chip ${currentAltarTool === "espejo" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "👁️ 3. Magic Mirror" : "👁️ 3. Espejo Mágico"}</a>
          <a href="/altar-dragonscript.html" class="chip ${currentAltarTool === "dragonscript" ? "active" : ""}" style="font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "📜 4. Dragon Script" : "📜 4. Dragon Script"}</a>
        </div>
      </div>

      ${toolContentHtml}

      <div class="fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(138,43,226,0.15), rgba(233,196,106,0.15)); border: 2px solid #8a2be2; border-radius: 20px;">
        <div style="font-size: 3rem;">🎓</div>
        <h3 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 1.9rem;">${isEn ? "Ready to Advance Through the 5 Rings?" : "¿Listo para avanzar en los 5 Anillos?"}</h3>
        <p style="color: var(--text-main); max-width: 700px; margin: 8px auto 0 auto; font-size: 1.05rem; line-height: 1.6;">
          ${isEn 
            ? "Enter the <strong>Draconian Academy</strong> and begin your training from Ring 1 through Ring 5 of graduation." 
            : "Entrá a la <strong>Academia Draconiana</strong> y comenzá tu entrenamiento desde el Anillo 1 hasta el Anillo 5 de graduación."}
        </p>
        <button type="button" class="btn btn-gold btn-lg margin-top-md" onclick="switchMagicSubPage('academia')" style="padding: 12px 28px; font-weight: 700; cursor: pointer;">
          ${isEn ? "🎓 Enter the Draconian Academy" : "🎓 Entrar a la Academia Draconiana"}
        </button>
      </div>
    </div>
  `;
}

// SUB-PÁGINA 3: LA ACADEMIA DRACONIANA (5 ANILLOS)
function renderAcademiaSubPage(container) {
  if (typeof window !== "undefined" && window.location) {
    const p = window.location.pathname;
    for (let r = 1; r <= 5; r++) {
      if (p.includes(`academia-anillo-${r}`)) {
        currentMagicRing = r;
        break;
      }
    }
  }

  const isEn = magicIsEn();
  container.innerHTML = `
    <div class="magic-section-wrapper" style="display: flex; flex-direction: column; gap: 2rem;">
      
      <!-- HERO BANNER DE ACADEMIA SUB-PAGE -->
      <div class="magic-hero fantasy-panel text-center" style="padding: 2.2rem; background: linear-gradient(135deg, rgba(233,196,106,0.15), rgba(138,43,226,0.15)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div class="quiz-step-tag" style="font-size: 0.95rem;">${isEn ? "🎓 Center of Mastery 🎓" : "🎓 Centro de Maestría 🎓"}</div>
        <h2 class="panel-title margin-top-xs" style="color: var(--gold-main); font-size: 2.3rem;">${isEn ? "The Draconian Academy" : "La Academia Draconiana"}</h2>
        <p style="color: var(--text-main); font-size: 1.1rem; max-width: 800px; margin: 12px auto 0 auto; line-height: 1.6;">
          ${isEn 
            ? "Advance step by step through the 5 Inner Rings of Lore to master focus, enchantments, shamanic healing, protection, and dragon mysticism." 
            : "Avanzá paso a paso a través de los 5 Anillos Internos del Saber para dominar la concentración, los encantamientos, la sanación, la protección y el misticismo."}
        </p>

        <!-- SUB-NAV SWITCHER -->
        ${renderMagicSubNavHtml("academia")}
      </div>

      <!-- NAVEGACIÓN POR LOS 5 ANILLOS -->
      <div class="fantasy-panel" style="padding: 2rem;">
        <div class="text-center">
          <h3 class="panel-title" style="color: var(--gold-main); font-size: 1.8rem;">${isEn ? "The Five Inner Rings of Lore" : "Los Cinco Anillos Internos del Saber"}</h3>
          <p style="color: var(--text-muted); font-size: 1rem; margin-top: 6px;">
            ${isEn ? "Select a Ring to study its lesson and complete its sacred quests:" : "Seleccioná un Anillo para estudiar su lección y completar sus misiones:"}
          </p>
        </div>

        <!-- Navigation Chips for 5 Rings -->
        <div class="magic-rings-nav display-flex justify-center flex-wrap gap-sm margin-top-lg" style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
          <a href="/academia-anillo-1.html" class="chip ${currentMagicRing === 1 ? "active" : ""}" style="padding: 10px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "🌱 Ring 1: Apprentice" : "🌱 Anillo 1: El Aprendiz"}</a>
          <a href="/academia-anillo-2.html" class="chip ${currentMagicRing === 2 ? "active" : ""}" style="padding: 10px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "📜 Ring 2: Enchanter" : "📜 Anillo 2: El Encantador"}</a>
          <a href="/academia-anillo-3.html" class="chip ${currentMagicRing === 3 ? "active" : ""}" style="padding: 10px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "🌿 Ring 3: Shaman" : "🌿 Anillo 3: El Chamán"}</a>
          <a href="/academia-anillo-4.html" class="chip ${currentMagicRing === 4 ? "active" : ""}" style="padding: 10px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "🛡️ Ring 4: Warrior" : "🛡️ Anillo 4: El Guerrero"}</a>
          <a href="/academia-anillo-5.html" class="chip ${currentMagicRing === 5 ? "active" : ""}" style="padding: 10px 18px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center;">${isEn ? "🔮 Ring 5: Mystic" : "🔮 Anillo 5: El Místico"}</a>
        </div>

        <!-- Ring Content Container -->
        <div class="ring-detail-box margin-top-lg fantasy-panel" id="ring-detail-box" style="padding: 1.8rem; background: rgba(0,0,0,0.4); border-radius: 16px;">
          ${renderRingContent(currentMagicRing)}
        </div>
      </div>

    </div>
  `;
}

function renderRingContent(ringNumber) {
  const isEn = magicIsEn();
  switch (ringNumber) {
    case 1:
      return `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          
          <!-- Encabezado del Anillo 1 -->
          <div style="display: flex; align-items: center; gap: 14px; background: rgba(42,157,143,0.15); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--color-teal);">
            <span style="font-size: 2.8rem;">🌱</span>
            <div>
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.7rem;">${isEn ? "Level 1: The Dragon Apprentice" : "Nivel 1: El Aprendiz de Dragón"}</h3>
              <p style="color: var(--text-gold); font-style: italic; margin: 4px 0 0 0; font-size: 1.05rem;">
                ${isEn 
                  ? "&quot;Welcome to the First Ring! Becoming a draconian wizard is an incredible journey that will expand your mind.&quot;" 
                  : "&quot;¡Bienvenido al Primer Anillo! Convertirse en un mago draconiano es una aventura increíble que abrirá tu mente.&quot;"}
              </p>
            </div>
          </div>

          <p style="line-height: 1.6; color: var(--text-main); font-size: 1.05rem;">
            ${isEn 
              ? "Every great wizard must begin by mastering the most fundamental arts: <strong>concentration</strong>, <strong>visualization</strong> (the art of directing your imagination with purpose), and <strong>patience</strong>." 
              : "Todo gran mago debe empezar por dominar las habilidades más básicas: la <strong>concentración</strong>, la <strong>visualización</strong> (el arte de usar tu imaginación con fuerza) y la <strong>paciencia</strong>."}
          </p>

          <!-- Código y Símbolos del Aprendiz -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">${isEn ? "🔮 The Apprentice's Code & Symbols" : "🔮 El Código y los Símbolos del Aprendiz"}</h4>
            
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(233,196,106,0.08); padding: 1rem; border-radius: 10px; border-left: 4px solid var(--gold-main);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📜 Your Magical Motto:" : "📜 Tu Lema Mágico:"}</h5>
                <p style="margin-top: 4px; font-style: italic; color: var(--text-gold); font-size: 1rem; font-weight: 600;">
                  ${isEn ? "&quot;To be called is to have a destiny. Know thyself well.&quot;" : "&quot;Ser llamado es tener un destino. Conócete bien a vos mismo.&quot;"}
                </p>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "This reminds us that every being plays a meaningful part in this world. To practice magic safely, you must first be completely honest with yourself about your own feelings, your gifts, and your shortcomings." 
                    : "Esto significa que todos tenemos un papel importante en este mundo. Para hacer magia de forma segura, primero debés ser honesto sobre tus propios sentimientos, tus talentos y tus defectos."}
                </p>
              </div>

              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem;">
                <div style="background: rgba(42,157,143,0.1); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-teal);">
                  <h5 style="color: var(--color-teal); margin: 0; font-size: 1.1rem;">${isEn ? "🟦 Your Color: Pure Blue" : "🟦 Tu Color: El Azul"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "The color of serene emotions and inner mind clarity. Find a blue ribbon (about 60 cm) to drape across your shoulders whenever you sit to meditate or cast your exercises." 
                      : "Es el color de las emociones tranquilas y la magia de la mente. Conseguí un listón azul (de unos 60 cm) para ponértelo sobre los hombros cada vez que vayas a practicar tus hechizos o a meditar."}
                  </p>
                </div>

                <div style="background: rgba(200,85,61,0.1); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-rust);">
                  <h5 style="color: var(--color-rust); margin: 0; font-size: 1.1rem;">${isEn ? "⭐ Your Symbol: The Elven Star" : "⭐ Tu Símbolo: La Estrella Élfica"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "The seven-pointed star (heptagram). Drawing it or tracing its path with your finger allows your mind to quiet down, opening gentle communion with dragon realms." 
                      : "La estrella de 7 puntas. Dibujarla o seguir su forma con el dedo ayuda a que tu mente se relaje y sea más fácil contactar con el mundo mágico."}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Tus Primeras Herramientas Mágicas -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "📚 Your First Magical Grimoires" : "📚 Tus Primeras Herramientas Mágicas"}</h4>
            <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">
              ${isEn ? "Every apprentice must acquire or craft two very special books:" : "Todo aprendiz necesita fabricar o conseguir dos libros muy especiales:"}
            </p>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📖 1. The Dragon's Secrets" : "📖 1. Los Secretos del Dragón"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A private journal where you write each day about your insights, vivid dreams, and how your daily life flourishes as you progress along the path." 
                    : "Un diario secreto donde escribirás todos los días tus pensamientos, tus sueños y cómo cambia tu vida a medida que avanzas en tus estudios mágicos."}
                </p>
              </div>

              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">📁 2. The Dragon's Hoard" : "📁 2. El Tesoro del Dragón"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A binder or ledger where you store your rituals, sacred drawings, and results. Inscribe upon its first page: <em>&quot;This Book of Wisdom is written by the hand of [Your Magical Name]!&quot;</em>" 
                    : "Una carpeta con anillas donde guardarás tus rituales, hechizos y resultados. Escribí en la primera página con tus mejores colores: <em>&quot;¡Este libro de secretos está escrito por la mano de [Tu Nombre Mágico]!&quot;</em>"}
                </p>
              </div>
            </div>
          </div>

          <!-- Tu Nuevo Mejor Amigo: El Dragón Guardián -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(233,196,106,0.08); border: 1px solid var(--gold-main);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "🐉 Your Guardian Dragon: First Companion" : "🐉 Tu Nuevo Mejor Amigo: El Dragón Guardián"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 1rem;">
              ${isEn 
                ? "At this stage you meet your very first magical companion. Guardian dragons are the youthful scouts of their clan; some are so petite they could nestle in the palm of your hand!" 
                : "En este nivel vas a conocer a tu primer compañero mágico. Los dragones guardianes son los más jóvenes de su especie, ¡y algunos son tan pequeños que caben en la palma de tu mano!"}
            </p>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 1rem;">
              ${isEn 
                ? "They are playful, inquisitive beings who delight in warming scents like <strong>ginger</strong>, enjoy joyful music, and love watching you dance without worry. They are allies and friends—never order them around or treat them as servants, or they will depart like morning mist!" 
                : "Son criaturas súper juguetonas a las que les encantan los aromas dulces y picantes, como el del <strong>jengibre</strong>, además de disfrutar la música y verte bailar libremente. Ellos serán tus colaboradores, así que recordá la regla de oro: nunca intentes darles órdenes ni tratarlos como sirvientes, ¡o se irán!"}
            </p>
          </div>

          <!-- Misión 1: El Ritual de Contacto -->
          <div class="fantasy-panel" style="padding: 1.6rem; border: 2px solid var(--color-teal); background: rgba(42,157,143,0.1);">
            <h4 style="color: var(--color-teal); margin: 0; font-size: 1.4rem; text-align: center;">${isEn ? "📜 Quest 1: The First Contact Ritual" : "📜 Misión 1: El Ritual de Contacto"}</h4>
            <p style="text-align: center; color: var(--text-gold); font-size: 0.95rem; margin-top: 4px;">
              ${isEn ? "Follow these 6 sacred steps to invite your guardian dragon and introduce yourself with warmth:" : "Seguí estos 6 pasos para invitar a tu dragón guardián a jugar y presentarte oficialmente:"}
            </p>

            <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 1.2rem;">
              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 1:" : "Paso 1:"}</strong> ${isEn ? "Find a quiet sanctuary in your room where you will not be disturbed, and place your blue Apprentice ribbon across your shoulders." : "Andá a un lugar tranquilo de tu cuarto donde nadie te interrumpa y colocate tu listón azul de Aprendiz sobre los hombros."}
              </div>

              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 2:" : "Paso 2:"}</strong> ${isEn ? "Sit comfortably, close your eyes, breathe deeply to unwind, and speak aloud with sincerity:" : "Sentate cómodamente, cerrá los ojos, respirá profundo para relajarte y decí en voz alta:"}
                <p style="margin: 8px 0 0 0; font-style: italic; color: var(--text-gold); background: rgba(233,196,106,0.1); padding: 10px; border-radius: 8px;">
                  ${isEn 
                    ? "&quot;I rest secure within the circle of the Dragon Apprentice. In this sanctuary, I invite and call my guardian dragon to dwell beside me. I offer you loyal and heartfelt friendship.&quot;" 
                    : "&quot;Estoy a salvo en el poderoso anillo del Dragón Aprendiz. Mientras me siento en este espacio, invito y llamo a mi dragón guardián para que esté aquí conmigo. Te ofrezco una amistad leal y cálida.&quot;"}
                </p>
              </div>

              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 3:" : "Paso 3:"}</strong> ${isEn ? "Allow your thoughts to drift without tense expectation. Soon, you may sense a faint breeze on your neck, a subtle tingle on your skin, or an unmistakable certainty that you are no longer alone." : "Dejá que tus pensamientos vuelen sin esperar nada en particular. En poco tiempo, es posible que sientas una ligera brisa en el cuello, un leve roce en tu piel, o simplemente una sensación muy fuerte de que ya no estás solo en tu cuarto."}
              </div>

              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 4:" : "Paso 4:"}</strong> ${isEn ? "Dragons often perch quietly behind you—do not expect them to hover before physical eyes. Instead, look through your imagination: you might glimpse iridescent scales, a twitching tail, or a warm luminous eye." : "A los dragones les gusta pararse detrás de vos, así que no esperes verlos flotando frente a tus ojos físicos. En cambio, míralo a través de tu imaginación con los ojos cerrados: puede que veas un destello de su cuerpo o un gran ojo amigable mirándote."}
              </div>

              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 5:" : "Paso 5:"}</strong> ${isEn ? "Send a wave of mental friendship. In return, your dragon will surround you with reassuring warmth, like a gentle invisible hug. From this moment forth, you are companions." : "Envíale mentalmente un gran saludo de amistad. A cambio, tu dragón guardián te rodeará con un sentimiento muy cálido, ¡como si te diera un gran abrazo invisible! Desde ese momento serán inseparables."}
              </div>

              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "Step 6:" : "Paso 6:"}</strong> ${isEn ? "Open your eyes gently, rest the palms of your hands upon the floor to ground any surplus energy, and thank your dragon friend for answering the call." : "Abrí los ojos lentamente, poné las palmas de tus manos en el suelo para soltar la energía sobrante y dale las gracias a tu nuevo compañero mágico por haber venido."}
              </div>
            </div>
          </div>

        </div>
      `;

    case 2:
      return `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          
          <!-- Encabezado del Anillo 2 -->
          <div style="display: flex; align-items: center; gap: 14px; background: rgba(42,157,143,0.15); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--color-teal);">
            <span style="font-size: 2.8rem;">📜</span>
            <div>
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.7rem;">${isEn ? "Level 2: The Dragon Enchanter" : "Nivel 2: El Encantador de Dragones"}</h3>
              <p style="color: var(--text-gold); font-style: italic; margin: 4px 0 0 0; font-size: 1.05rem;">
                ${isEn 
                  ? "&quot;Congratulations on reaching the Second Ring! It is time to learn the ancient craft of spells, nature potions, and magical amulets.&quot;" 
                  : "&quot;¡Felicidades por avanzar al Segundo Anillo! Es hora de aprender el antiguo arte de los hechizos, las pociones de la naturaleza y los amuletos mágicos.&quot;"}
              </p>
            </div>
          </div>

          <!-- Código y Símbolos del Encantador -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">${isEn ? "🌿 The Enchanter's Code & Symbols" : "🌿 Tu Código y Símbolos de Encantador"}</h4>
            
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(233,196,106,0.08); padding: 1rem; border-radius: 10px; border-left: 4px solid var(--gold-main);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📜 Your Magical Motto:" : "📜 Tu Lema Mágico:"}</h5>
                <p style="margin-top: 4px; font-style: italic; color: var(--text-gold); font-size: 1rem; font-weight: 600;">
                  ${isEn ? "&quot;Magic is both an art and a science. Always treat it with reverence.&quot;" : "&quot;La magia es tanto un arte como una ciencia. Trátala siempre con respeto.&quot;"}
                </p>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "As an Enchanter, you will learn to work with gifts of nature. Remember the supreme law: magic is invoked to aid, heal, and elevate—never to manipulate or control others. Dragons abhor tyrants and will never lend aid to anyone seeking dominion." 
                    : "Como Encantador, aprenderás a usar ingredientes de la naturaleza, pero recuerda la regla más grande: la magia se usa para ayudar, sanar y mejorar, ¡nunca para tratar de controlar a otras personas! A los dragones no les gustan los tiranos y no ayudarán a quien intente ser uno."}
                </p>
              </div>

              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem;">
                <div style="background: rgba(42,157,143,0.1); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-teal);">
                  <h5 style="color: var(--color-teal); margin: 0; font-size: 1.1rem;">${isEn ? "🟩 Your Color: Radiant Green" : "🟩 Tu Color: El Verde Brillante"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "Symbolizes the vigorous growth of living nature, prosperity, and radiant intent. Wear a bright green ribbon across your shoulders during your magical crafts." 
                      : "Representa el crecimiento de la naturaleza, la prosperidad y la magia positiva. Conseguí un listón verde y ponértelo en los hombros cada vez que vayas a trabajar en tus proyectos mágicos."}
                  </p>
                </div>

                <div style="background: rgba(200,85,61,0.1); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-rust);">
                  <h5 style="color: var(--color-rust); margin: 0; font-size: 1.1rem;">${isEn ? "🔺 Your Symbol: The Upward Triangle" : "🔺 Tu Símbolo: El Triángulo Ascendente"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "The triangle pointing toward the heavens. Inscribe it in your book of secrets to focus the elemental warmth of fire and conscious will." 
                      : "El triángulo apuntando hacia arriba. Podés dibujarlo en tu cuaderno de secretos para enfocar la fuerza del fuego y la mente."}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Tu Laboratorio Mágico: Nuevas Herramientas -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "🧪 Your Magical Workshop: Crafting Tools" : "🧪 Tu Laboratorio Mágico: Nuevas Herramientas"}</h4>
            <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">
              ${isEn ? "To practice the art of an Enchanter, assemble your sacred toolkit:" : "Para hacer la magia de un Encantador, necesitarás reunir tu propio equipo de laboratorio:"}
            </p>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "✨ The Magic Wand" : "✨ La Varita Mágica"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "Your primary focus for projecting benevolent energy. Find a fallen branch worn by nature, or craft a smooth dowel adorned with a quartz crystal tip." 
                    : "Tu herramienta principal para dirigir buena energía. Podés buscar en el parque una rama caída que te guste, o usar un tubo transparente con piedritas de colores y un cristal de cuarzo en la punta."}
                </p>
              </div>

              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🥣 Mortar & Glass Vials" : "🥣 El Mortero y Frasquitos"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A small grinding bowl and clean glass jars with lids. Here you will carefully grind and preserve aromatic herbs and floral blossoms." 
                    : "Un mortero pequeño (un tazón grueso para machacar) y varios frasquitos vacíos limpios con tapa. Aquí guardarás y molerás tus hierbas mágicas."}
                </p>
              </div>

              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🧵 Colorful Fabrics" : "🧵 Telas de Colores"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "Collect remnants of green, white, and red cotton fabric with ribbons to sew miniature charm bags and mojo pouches." 
                    : "Reuní pedacitos de tela (verde, blanca, roja) e hilos de colores. Te servirán para confeccionar pequeñas bolsitas mágicas."}
                </p>
              </div>
            </div>
          </div>

          <!-- Misión 1: Amuletos y Talismanes de Poder -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(233,196,106,0.08); border: 1px solid var(--gold-main);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "✨ Quest 1: Amulets and Talismans of Might" : "✨ Misión 1: Amuletos y Talismanes de Poder"}</h4>
            <p style="margin-top: 6px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Did you know they are not the same? Understanding the difference will help you craft true tools of good fortune:" 
                : "¿Sabías que no son lo mismo? Conocer la diferencia te ayudará a crear tus propias herramientas de buena suerte:"}
            </p>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.05rem;">${isEn ? "🪨 Amulets (Gifts of Nature):" : "🪨 Los Amuletos (Naturaleza):"}</h5>
                <p style="margin-top: 6px; font-size: 0.9rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "Tokens shaped by nature itself: an intriguing river stone, a spiraled seashell, or an acorn (which shields you and imparts endurance). Simply discover and carry them." 
                    : "Son regalitos creados por la naturaleza, como una piedra con forma curiosa, una concha de mar o una bellota (que te protege y te da fuerza). Solo tenés que encontrarlos y llevarlos con vos."}
                </p>
              </div>
              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.05rem;">${isEn ? "🎨 Talismans (Handcrafted Creations):" : "🎨 Los Talismanes (Creación Propia):"}</h5>
                <p style="margin-top: 6px; font-size: 0.9rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "Objects you fashion with your own hands. Craft a clay disc, inscribe your monogram or a dragon rune upon it, and hold it whenever you need courage!" 
                    : "Son objetos creados por vos. Podés hacer una pequeña moneda de arcilla, dibujarle tu inicial o un símbolo de dragón con marcador mágico, ¡y usarla para llenarte de valentía!"}
                </p>
              </div>
            </div>
          </div>

          <!-- Misión 2: Polvo de "Amistad de Dragón" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-teal); background: rgba(42,157,143,0.1);">
            <h4 style="color: var(--color-teal); margin: 0; font-size: 1.4rem;">${isEn ? "🌸 Quest 2: Dragon Friendship Dust" : "🌸 Misión 2: Polvo de &quot;Amistad de Dragón&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Learn to blend pure, gentle ritual powders using unscented talcum or baking soda as your base. In your mortar, gently blend it with dried fragrant rose petals or dried herbs." 
                : "Aprendé a hacer polvos mágicos inofensivos usando una base de talco sin aroma o bicarbonato. En tu tazón, mezclá el polvo con hojas secas de flores que huelan muy rico (como pétalos de rosa)."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "Blending Chanted Verse:" : "Conjuro de Mezcla:"}</strong>
              <p style="margin: 6px 0 0 0; font-style: italic; color: var(--text-gold); font-size: 0.95rem;">
                ${isEn 
                  ? "&quot;Dragons near and dragons far, join with me beneath each star. A happy heart I share with thee, when we meet and when we part in glee.&quot;" 
                  : "&quot;Llamo a los dragones, cerca y lejos, para que se unan a mí dondequiera que estén. Compartiré con ustedes un corazón feliz, cuando nos encontremos y cuando nos despidamos.&quot;"}
              </p>
            </div>
            <p style="margin-top: 10px; font-size: 0.9rem; color: var(--text-muted);">
              ${isEn 
                ? "Keep it in a small vial, and sprinkle a pinch near your altar space whenever you wish to invite young guardian dragons to play." 
                : "Guárdalo en tu frasco, y espolvoreá un poquito en tu cuarto cuando quieras invitar a los pequeños dragones guardianes a que te hagan compañía."}
            </p>
          </div>

          <!-- Misión 3: Pociones de "Agua de la Naturaleza" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-rust); background: rgba(200,85,61,0.1);">
            <h4 style="color: var(--color-rust); margin: 0; font-size: 1.4rem;">${isEn ? "💧 Quest 3: Potions of Living Nature Water" : "💧 Misión 3: Pociones de &quot;Agua de la Naturaleza&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Enchanters brew subtle infusions known as &quot;fluid condensers&quot; that absorb elemental vitality. With an adult's guidance, warm clean spring water and infuse it with fresh garden mint, lavender, or rose petals. Strain when cool and store in a glass flacon." 
                : "Los Encantadores preparan pociones de agua llamadas &quot;condensadores de fluidos&quot;, que sirven para atrapar la energía de los elementos. Pedile a un adulto que te ayude a calentar un poquito de agua pura y agrégale hojas frescas de tu jardín (como menta, rosas o lavanda). Déjala enfriar por completo, cuélala y guárdala en una botellita."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "Blessing Incantation:" : "Encantamiento de Cierre:"}</strong>
              <p style="margin: 6px 0 0 0; font-style: italic; color: var(--text-gold); font-size: 0.95rem;">
                ${isEn 
                  ? "&quot;Dragons of water, subtle and bold, bless this bottle that I hold. I trust your wisdom and your might, aiding my craft this sacred night.&quot;" 
                  : "&quot;Dragones de agua, sutiles pero audaces, energicen esta botella que sostengo. Confío en su sabiduría y en su poder, que me ayuda a hacer magia en esta hora.&quot;"}
              </p>
            </div>
            <p style="margin-top: 10px; font-size: 0.9rem; color: var(--text-muted);">
              ${isEn 
                ? "Dab a few drops of this herbal elixir onto your talismans to consecrate them with clear, uplifting energy." 
                : "Podés poner unas gotitas de esta agua mágica en tus amuletos para recargarlos de energía limpia y positiva."}
            </p>
          </div>

        </div>
      `;

    case 3:
      return `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          
          <!-- Encabezado del Anillo 3 -->
          <div style="display: flex; align-items: center; gap: 14px; background: rgba(200,85,61,0.15); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--color-rust);">
            <span style="font-size: 2.8rem;">🌿</span>
            <div>
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.7rem;">${isEn ? "Level 3: The Dragon Shaman (Energy Healer)" : "Nivel 3: El Chamán de Dragones (Sanador de Energía)"}</h3>
              <p style="color: var(--text-gold); font-style: italic; margin: 4px 0 0 0; font-size: 1.05rem;">
                ${isEn 
                  ? "&quot;Splendid! You have attained the Third Ring. You step beyond simple charms to walk deeply with the spirit realm as a Walker Between Worlds.&quot;" 
                  : "&quot;¡Increíble! Has llegado al Tercer Anillo. Dejarás de ser un aprendiz para trabajar profundamente con el mundo espiritual y convertirte en un 'Caminante entre Mundos'.&quot;"}
              </p>
            </div>
          </div>

          <p style="line-height: 1.6; color: var(--text-main); font-size: 1.05rem;">
            ${isEn 
              ? "Shamans work alongside dragons to soothe emotional distress, heal energetic fatigue, and preserve the subtle balance of the living earth." 
              : "Los chamanes trabajan junto a los dragones para sanar la energía, calmar las emociones y mantener el equilibrio invisible de las cosas."}
          </p>

          <!-- Código y Símbolos de Chamán -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">${isEn ? "✨ The Shaman's Code & Symbols" : "✨ Tu Código y Símbolos de Chamán"}</h4>
            
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(233,196,106,0.08); padding: 1rem; border-radius: 10px; border-left: 4px solid var(--gold-main);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📜 Your Magical Motto:" : "📜 Tu Lema Mágico:"}</h5>
                <p style="margin-top: 4px; font-style: italic; color: var(--text-gold); font-size: 1rem; font-weight: 600;">
                  ${isEn ? "&quot;To benefit all, I journey and learn throughout the Multiverse. I am a Walker Between Worlds.&quot;" : "&quot;Para beneficiar a todos, debo viajar y aprender en el Multiverso. Soy un Caminante entre Mundos.&quot;"}
                </p>
              </div>

              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem;">
                <div style="background: rgba(200,85,61,0.15); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-rust);">
                  <h5 style="color: var(--color-rust); margin: 0; font-size: 1.1rem;">${isEn ? "🔴 Your Color: Radiant Crimson" : "🔴 Tu Color: El Rojo Brillante"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "Embodying action, vital vitality, and the potent current of healing. Adorn your shoulders with a scarlet ribbon when doing healing work." 
                      : "Este color representa la acción, el esfuerzo y el gran poder para sanar. Conseguí un listón rojo para ponerlo en tus hombros en tus prácticas."}
                  </p>
                </div>

                <div style="background: rgba(42,157,143,0.15); padding: 1rem; border-radius: 10px; border: 1px solid var(--color-teal);">
                  <h5 style="color: var(--color-teal); margin: 0; font-size: 1.1rem;">${isEn ? "🍃 Your Symbol: Leaf of the World Tree" : "🍃 Tu Símbolo: La Hoja Verde del Árbol del Mundo"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "A vibrant leaf representing Yggdrasil and universal renewal. Wear a leaf pin or sketch it upon your diary as your badge of initiation." 
                      : "Una hoja verde que representa el Árbol del Mundo y la naturaleza. Podés dibujarla o buscar un prendedor con esta forma para usarlo como tu medalla."}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Tus Herramientas de Sanación -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "💎 Your Healing Mineral Allies" : "💎 Tus Herramientas de Sanación"}</h4>
            <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">
              ${isEn ? "A Shaman employs two complementary stones to balance living energy:" : "Un Chamán necesita piedras muy especiales (que podés buscar en el parque o en un río) para ayudar a los demás:"}
            </p>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🖤 The Absorbing Stone" : "🖤 La Piedra &quot;Aspiradora&quot;"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A smooth black stone (such as obsidian, onyx, or river jet). Operates like an astral vacuum to draw away tension, grumpy moods, and heavy stagnant vibrations." 
                    : "Una piedra negra y de superficie suave (como el ónix o la obsidiana). Sirve como una aspiradora mágica para absorber y limpiar el mal humor, el estrés o la energía negativa del ambiente."}
                </p>
              </div>

              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🤍 The Sealing Quartz" : "🤍 El Cristal Sellador"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A white or clear quartz crystal applied right after the black stone to seal the cleansed aura with sparkling light and golden protection." 
                    : "Una piedra blanca (como el cuarzo nevado) que se usa inmediatamente después de la piedra negra, para 'sellar' y rellenar de luz y buena energía el espacio que limpiaste."}
                </p>
              </div>
            </div>
          </div>

          <!-- Misión 1: Sentir el Aura -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-teal); background: rgba(42,157,143,0.1);">
            <h4 style="color: var(--color-teal); margin: 0; font-size: 1.4rem;">${isEn ? "🖐️ Quest 1: Sensing the Aura (Your Invisible Field)" : "🖐️ Misión 1: Sentir el Aura (Tu Campo de Fuerza Invisible)"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Every person, animal, and living tree is enveloped by a luminous biometric field known as the <strong>Aura</strong>. Some perceive it as radiant colors, others as soft white radiance, and others simply feel its temperature and texture." 
                : "¿Sabías que todas las personas, animales e incluso las cosas están rodeados por un campo electromagnético invisible llamado <strong>Aura</strong>? Algunos magos la ven como luces de colores, otros como luz blanca, y otros simplemente la 'sienten'."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "How to Practice:" : "Cómo practicar:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Ask a trusted family member or friend to sit relaxed. With peaceful breathing, slowly sweep your open palms through the air roughly 15 cm from their shoulders, without physical touch. With patience, you will notice warmth, cool patches, or gentle tingling. Shamans use this skill to perceive where comforting energy is needed!" 
                  : "Pídele a un amigo o familiar que se siente tranquilo. Relajá tu mente y mové tus manos muy despacio en el aire, a unos 15 centímetros de su cuerpo, sin tocarlo en ningún momento. Con práctica, empezarás a 'sentir' el aura: podés notar lugares que se sienten más fríos, más calientes, o un leve cosquilleo. ¡Los chamanes usan este ejercicio para descubrir dónde necesita una persona un abrazo de energía mágica!"}
              </p>
            </div>
          </div>

          <!-- Misión 3: El Sonido que Cura -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-rust); background: rgba(200,85,61,0.1);">
            <h4 style="color: var(--color-rust); margin: 0; font-size: 1.4rem;">${isEn ? "🎵 Quest 2: The Healing Dragon Resonance" : "🎵 Misión 2: El Sonido que Cura"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Shamans discovered that the vibration of sound and voice acts as a direct balm for troubled spirits." 
                : "Los chamanes descubrieron que la vibración de la voz es una gran herramienta de sanación."}
            </p>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-top: 10px;">
              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--color-teal);">${isEn ? "🌬️ Tone &quot;AAHH&quot; (Soothing Relaxation):" : "🌬️ Sonido &quot;AAHH&quot; (Relajación):"}</strong>
                <p style="margin-top: 4px; font-size: 0.9rem; color: var(--text-main);">
                  ${isEn 
                    ? "When feeling weary or upset, gently intone a sustained, soft <em>&quot;aahh&quot;</em> sound. It dissolves worry and unties mental knots." 
                    : "Si tú o alguien de tu familia se siente cansado, cantá en voz alta y suavemente el sonido <em>&quot;aahh&quot;</em>, que ayuda a sanar y relajar la mente y el cuerpo."}
                </p>
              </div>
              <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px;">
                <strong style="color: var(--gold-main);">${isEn ? "⚡ Tone &quot;EEEE&quot; (Vital Awakening):" : "⚡ Sonido &quot;EEEE&quot; (Energización):"}</strong>
                <p style="margin-top: 4px; font-size: 0.9rem; color: var(--text-main);">
                  ${isEn 
                    ? "When you need to awaken resolve and banish sluggishness, softly hum the crisp <em>&quot;eeee&quot;</em> sound while holding your healing stones." 
                    : "Si lo que necesitan es despertar y llenarse de energía positiva, el sonido mágico es <em>&quot;eeee&quot;</em>. ¡Pruébalo mientras sostienes tus piedras curativas en las manos!"}
                </p>
              </div>
            </div>
          </div>

        </div>
      `;

    case 4:
      return `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          
          <!-- Encabezado del Anillo 4 -->
          <div style="display: flex; align-items: center; gap: 14px; background: rgba(233,196,106,0.15); padding: 1.2rem; border-radius: 14px; border: 1px solid var(--gold-main);">
            <span style="font-size: 2.8rem;">🛡️</span>
            <div>
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.7rem;">${isEn ? "Level 4: The Dragon Warrior (Valiant Guardian)" : "Nivel 4: El Guerrero Dragón (El Protector Valiente)"}</h3>
              <p style="color: var(--text-gold); font-style: italic; margin: 4px 0 0 0; font-size: 1.05rem;">
                ${isEn 
                  ? "&quot;Welcome to the Fourth Ring! A Dragon Warrior never raises fists! A warrior uses luminous confidence, energetic shields, and keen wit to triumph over discord.&quot;" 
                  : "&quot;¡Bienvenido al Cuarto Anillo! ¡Un Guerrero Dragón no usa los puños! Usa su súper confianza, escudos de energía e inteligencia para triunfar sobre cualquier problema.&quot;"}
              </p>
            </div>
          </div>

          <!-- Código y Símbolos de Guerrero -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">${isEn ? "✨ The Warrior's Code & Symbols" : "✨ Tu Código y Símbolos de Guerrero"}</h4>
            
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(233,196,106,0.08); padding: 1rem; border-radius: 10px; border-left: 4px solid var(--gold-main);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📜 Your Magical Motto:" : "📜 Tu Lema Mágico:"}</h5>
                <p style="margin-top: 4px; font-style: italic; color: var(--text-gold); font-size: 1rem; font-weight: 600;">
                  ${isEn 
                    ? "&quot;I stand for truth, protect my inner spark, and seek no quarreling where none exists. Common sense is my armor!&quot;" 
                    : "&quot;Defiendo la verdad, protejo mi energía y nunca busco problemas donde no los hay. ¡Uso mi sentido común!&quot;"}
                </p>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "The true power of a warrior lies in knowing when to step aside with dignity and preserve unshakable peace." 
                    : "El verdadero poder de un guerrero es saber cuándo alejarse de una pelea y mantenerse tranquilo."}
                </p>
              </div>

              <div style="background: rgba(233,196,106,0.12); padding: 1rem; border-radius: 10px; border: 1px solid var(--gold-main);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🟡 Your Color: Brilliant Gold or Solar Amber" : "🟡 Tu Color: El Dorado o Amarillo Brillante"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "The radiance of strength and unbreachable psychic safety. Wear a golden ribbon during your courage rituals." 
                    : "El color de la fuerza y la protección invencible. Podés conseguir un listón de este color para usarlo en tus meditaciones de fortaleza."}
                </p>
              </div>
            </div>
          </div>

          <!-- Tus Herramientas de Defensa -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.3rem;">${isEn ? "🛡️ Your Shields of Defense" : "🛡️ Tus Herramientas de Defensa"}</h4>
            <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">
              ${isEn ? "A Dragon Warrior relies on two steadfast emotional shields:" : "Un Guerrero Dragón cuenta con dos poderosos escudos emocionales:"}
            </p>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🔮 1. The Mirror of Deflection" : "🔮 1. El Espejo Brillante"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A pocket mirror used to deflect harsh energy or mean remarks back into the universe without harboring bitterness." 
                    : "Un espejo pequeño que usarás para 'rebotar' las malas energías o las palabras feas sin guardarte rencor."}
                </p>
              </div>

              <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 10px; border: 1px solid var(--border-panel);">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🌿 2. The Staff of Balance" : "🌿 2. El Bastón de Equilibrio"}</h5>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "A sturdy wooden staff that steadies your heart and reminds you to stand rooted whenever challenges arise." 
                    : "Una vara larga de madera (puedes buscar una rama firme en el parque). Sirve para mantener tu equilibrio emocional cuando sientes que te vas a caer o a rendir."}
                </p>
              </div>
            </div>
          </div>

          <!-- Misión 1: El Hechizo del "Espejo Rebotador" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--gold-main); background: rgba(233,196,106,0.08);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.4rem;">${isEn ? "🔮 Quest 1: The Mirror Deflection Ward" : "🔮 Misión 1: El Hechizo del &quot;Espejo Rebotador&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Sometimes at school or on the street, you may encounter grumpy spirits or unkind words. Never let them stick to your heart!" 
                : "A veces, en la escuela o en la calle, te puedes encontrar con personas que están de muy mal humor o que dicen cosas hirientes (a esto le llamamos 'energía dañina'). ¡No dejes que se pegue a vos!"}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "Your Warrior Practice:" : "Tu tarea de Guerrero:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Hold your mirror facing outward toward the world. Envision your guardian dragon gazing through the glass with benevolent fire, and chant:" 
                  : "Toma tu Espejo Brillante y sostenlo frente a vos con la parte que refleja apuntando hacia afuera (hacia el mundo). Imagina que tu dragón guardián está proyectando su imagen en ese espejo para protegerte. Luego, repite este conjuro especial:"}
              </p>
              <p style="margin: 8px 0 0 0; font-style: italic; color: var(--text-gold); background: rgba(233,196,106,0.1); padding: 10px; border-radius: 8px;">
                ${isEn 
                  ? "&quot;In this mirror bright and clear, dragon courage leaves no fear. Safe and peaceful I remain, return discordant thoughts again!&quot;" 
                  : "&quot;En este espejo brillante y protector, un gran dragón refleja su valor. Me quedo aquí seguro y sin temor, ¡que la mala energía se aleje a su creador!&quot;"}
              </p>
              <p style="margin-top: 8px; font-size: 0.9rem; color: var(--text-muted);">
                ${isEn 
                  ? "Afterward, rinse the mirror under cool water to wash away whatever heavy feelings were neutralized." 
                  : "Después, lava tu espejo con un poco de agua para limpiarlo de cualquier mala vibra que haya atrapado."}
              </p>
            </div>
          </div>

          <!-- Misión 2: Caminar con la Confianza del Dragón -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-teal); background: rgba(42,157,143,0.1);">
            <h4 style="color: var(--color-teal); margin: 0; font-size: 1.4rem;">${isEn ? "🐉 Quest 2: Walking with Dragon Confidence" : "🐉 Misión 2: Caminar con la Confianza del Dragón"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "The greatest secret of Dragon Warriors is their unshakeable inner self-trust, enabling them to meet every challenge with grace." 
                : "El secreto más grande de los Guerreros Dragón es que desarrollan una confianza en sí mismos tan gigante que los ayuda a superar cualquier cosa."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--color-teal);">${isEn ? "Your Attitude Quest:" : "Tu tarea de Actitud:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Whenever nervous before a speech or test, grip your Staff of Balance. Stand tall, inhale deeply, and picture majestic dragon wings unfurling behind your shoulders. Walk with calm majesty. Every obstacle shrinks before such courage!" 
                  : "La próxima vez que te sientas nervioso (antes de un examen o de hablar en público), toma tu Bastón de Equilibrio con fuerza. Párate muy derecho, respira hondo e imagina que unas enormes alas de dragón se abren a tus espaldas. Camina sintiendo que eres invencible. ¡Esa actitud hará que cualquier obstáculo parezca diminuto!"}
              </p>
            </div>
          </div>

          <!-- Misión 3: La Regla del "No-Problema" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--color-rust); background: rgba(200,85,61,0.1);">
            <h4 style="color: var(--color-rust); margin: 0; font-size: 1.4rem;">${isEn ? "📜 Quest 3: The Golden Rule of Non-Conflict" : "📜 Misión 3: La Regla del &quot;No-Problema&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "To be a warrior means bearing great capability, and true capability demands wise restraint." 
                : "Ser un guerrero significa tener mucho poder, y tener poder significa ser muy responsable."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--color-rust);">${isEn ? "Ring Pledge:" : "Promesa del Anillo:"}</strong>
              <p style="margin-top: 6px; font-style: italic; color: var(--text-gold); font-size: 1rem;">
                ${isEn ? "&quot;Do not breed trouble where none exists.&quot;" : "&quot;No hagas problemas donde no los hay.&quot;"}
              </p>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "If a pointless argument begins, be the wisest person in the room and walk away. A true warrior maintains an open heart but guards their peace!" 
                  : "Si ves que una discusión está a punto de empezar, sé el más inteligente de la habitación y aléjate. Un guerrero siempre tiene la mente abierta, ¡pero usa su sentido común para mantenerse a salvo!"}
              </p>
            </div>
          </div>

        </div>
      `;

    case 5:
    default:
      return `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          
          <!-- Encabezado del Anillo 5 -->
          <div style="display: flex; align-items: center; gap: 14px; background: linear-gradient(135deg, rgba(138,43,226,0.2), rgba(233,196,106,0.15)); padding: 1.2rem; border-radius: 14px; border: 1px solid #8a2be2;">
            <span style="font-size: 2.8rem;">🔮</span>
            <div>
              <h3 style="color: var(--gold-main); margin: 0; font-size: 1.7rem;">${isEn ? "Level 5: The Mystic Dragon (Master of the Cosmic Web)" : "Nivel 5: El Místico Dragón (Maestro de la Red de la Vida)"}</h3>
              <p style="color: var(--text-gold); font-style: italic; margin: 4px 0 0 0; font-size: 1.05rem;">
                ${isEn 
                  ? "&quot;Congratulations, noble wizard! You have arrived at the Fifth Ring, the highest pinnacle. You stand as a guardian of nature and the cosmos.&quot;" 
                  : "&quot;¡Felicidades, joven mago! Has llegado al Quinto Anillo, el último y más alto nivel. Te conviertes en un guardián de la naturaleza y del universo.&quot;"}
              </p>
            </div>
          </div>

          <!-- Código y Símbolos de Místico -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3);">
            <h4 style="color: var(--gold-main); margin: 0 0 10px 0; font-size: 1.3rem;">${isEn ? "✨ The Mystic's Code & Symbols" : "✨ Tu Código y Símbolos de Místico"}</h4>
            
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
              <div style="background: rgba(138,43,226,0.1); padding: 1rem; border-radius: 10px; border-left: 4px solid #8a2be2;">
                <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "📜 Your Magical Motto:" : "📜 Tu Lema Mágico:"}</h5>
                <p style="margin-top: 4px; font-style: italic; color: var(--text-gold); font-size: 1rem; font-weight: 600;">
                  ${isEn 
                    ? "&quot;We are all strands in the Web of Life. All things, animate and inanimate, are woven as one.&quot;" 
                    : "&quot;Todos somos parte de la Red de la Vida. Todas las cosas, animadas e inanimadas, están conectadas.&quot;"}
                </p>
                <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                  ${isEn 
                    ? "Every word, intention, and deed is like a pebble dropped into clear water: ripples travel onward and touch all living beings around you!" 
                    : "Esto significa que todo lo que haces, dices o piensas es como lanzar una piedrita en un estanque: ¡crea ondas que viajan y tocan todo a tu alrededor!"}
                </p>
              </div>

              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem;">
                <div style="background: rgba(138,43,226,0.15); padding: 1rem; border-radius: 10px; border: 1px solid #8a2be2;">
                  <h5 style="color: #b19ffb; margin: 0; font-size: 1.1rem;">${isEn ? "🟣 Your Color: Royal Violet or Starlit Silver" : "🟣 Tu Color: El Violeta o Gris Plateado"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "The hues of celestial nebulas, starlight, and boundless wisdom. Wear this ribbon with honor at your graduation." 
                      : "Los colores del universo, de las estrellas y de la magia más profunda. Conseguí un listón de este color para celebrar tu gran graduación."}
                  </p>
                </div>

                <div style="background: rgba(233,196,106,0.1); padding: 1rem; border-radius: 10px; border: 1px solid var(--gold-main);">
                  <h5 style="color: var(--gold-main); margin: 0; font-size: 1.1rem;">${isEn ? "🌠 Your Symbol: The Shooting Star" : "🌠 Tu Símbolo: La Estrella Fugaz"}</h5>
                  <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                    ${isEn 
                      ? "The nine-pointed star or shooting comet, embodying an eternal pilgrimage of discovery, wonder, and illumination." 
                      : "La estrella fugaz (o estrella de 9 puntas). Representa un viaje lleno de sorpresas maravillosas, sabiduría e iluminación."}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- El Secreto Supremo: El Elemento Tormenta -->
          <div class="fantasy-panel" style="padding: 1.4rem; background: rgba(0,0,0,0.3); border: 1px solid var(--color-teal);">
            <h4 style="color: var(--color-teal); margin: 0; font-size: 1.3rem;">${isEn ? "⚡ The Supreme Mystery: The Storm Element" : "⚡ El Secreto Supremo: El Elemento Tormenta"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "While earlier stages work with Air, Fire, Water, and Earth, the Mystic embraces the mysterious <strong>Storm Element</strong>. Storms bring profound renewal, and a Mystic welcomes change as the wind beneath dragon wings!" 
                : "Mientras que otros niveles trabajan con el Aire, Fuego, Agua y Tierra, el Místico trabaja con el misterioso <strong>elemento de la Tormenta</strong>. Las tormentas traen cambios, y un Místico sabe que cambiar y crecer es parte de la vida. ¡Un Místico no le teme a los cambios, los usa para volar más alto!"}
            </p>
          </div>

          <!-- Misión 1: Sentir la "Red de la Vida" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid #8a2be2; background: rgba(138,43,226,0.1);">
            <h4 style="color: #b19ffb; margin: 0; font-size: 1.4rem;">${isEn ? "🌱 Quest 1: Feeling the Web of Life" : "🌱 Misión 1: Sentir la &quot;Red de la Vida&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Step out into a garden, park, or stand before your favorite houseplant for this communion." 
                : "Para esta misión, sal a un parque, a tu jardín o siéntate junto a tu planta favorita."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "Your Connection Practice:" : "Tu tarea de Conexión:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Touch tree bark or fresh leaves gently. Close your eyes and visualize a thread of luminous light flowing from your heart to the tree. Trace that thread as it reaches flying birds, clouds, loved ones, and distant constellations. Feel the embrace of the whole living cosmos. You are never alone—you are part of everything!" 
                  : "Toca suavemente la corteza de un árbol o las hojas de una planta. Cierra los ojos e imagina que un hilo de luz brillante y muy delgadito sale de tu corazón y se conecta con el árbol. Luego, imagina que ese hilo se conecta con los pajaritos, con las nubes, con tu familia y con las estrellas. Siente cómo la energía de todo el universo te abraza. ¡Nunca estás solo, porque estás conectado con todo lo que existe!"}
              </p>
            </div>
          </div>

          <!-- Misión 2: Despertar tu "Corazón de Dragón Oculto" -->
          <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--gold-main); background: rgba(233,196,106,0.08);">
            <h4 style="color: var(--gold-main); margin: 0; font-size: 1.4rem;">${isEn ? "💖 Quest 2: Awakening Your Hidden Dragon Heart" : "💖 Misión 2: Despertar tu &quot;Corazón de Dragón Oculto&quot;"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 0.95rem;">
              ${isEn 
                ? "Ancient dragon masters teach that deep within your consciousness rests an invaluable treasure: your <strong>Hidden Dragon Heart</strong>." 
                : "Los maestros draconianos enseñan que muy en el fondo de tu mente (justo detrás de tus ojos) se esconde un tesoro invaluable: tu <strong>Corazón de Dragón Oculto</strong>."}
            </p>
            <div style="background: rgba(0,0,0,0.4); padding: 1rem; border-radius: 10px; margin-top: 10px;">
              <strong style="color: var(--gold-main);">${isEn ? "Your Illumination Quest:" : "Tu tarea de Iluminación:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Sit quietly, breathe deeply, and picture a small radiant violet sun glowing behind your eyes. That is your Dragon Heart—the seat of calm, bravery, and insight. Whenever faced with uncertainty or sadness, close your eyes and commune with this radiant spark. It will show you the noble path!" 
                  : "Siéntate en silencio, respira profundo y visualiza que dentro de tu cabeza hay un pequeño sol brillante de color violeta. Ese es tu Corazón de Dragón. Es el lugar donde guardas toda tu valentía, tu paz y tu inteligencia. Cuando te sientas triste, asustado o no sepas qué hacer, solo cierra los ojos, respira y conéctate con esta luz. ¡Te dará la respuesta correcta!"}
              </p>
            </div>
          </div>

          <!-- Misión 3: El Gran Viaje (Tu Graduación) -->
          <div class="fantasy-panel text-center" style="padding: 1.8rem; border: 2px solid var(--gold-main); background: linear-gradient(135deg, rgba(233,196,106,0.15), rgba(138,43,226,0.2)); border-radius: 18px;">
            <div style="font-size: 3rem;">🎓</div>
            <h4 style="color: var(--gold-main); margin: 6px 0 0 0; font-size: 1.6rem;">${isEn ? "🎓 Quest 3: The Grand Journey (Your Graduation)" : "🎓 Misión 3: El Gran Viaje (Tu Graduación)"}</h4>
            <p style="margin-top: 8px; color: var(--text-main); line-height: 1.6; font-size: 1rem; max-width: 700px; margin: 8px auto 0 auto;">
              ${isEn 
                ? "The quest of a Mystic Dragon never truly ends, for there are ever new wonders to explore and understand in the boundless universe." 
                : "El viaje de un Místico nunca termina realmente, porque siempre hay cosas nuevas y emocionantes por descubrir y aprender en el universo."}
            </p>
            <div style="background: rgba(0,0,0,0.5); padding: 1.2rem; border-radius: 12px; margin-top: 1.2rem; text-align: left;">
              <strong style="color: var(--gold-main);">${isEn ? "Your Graduation Oath:" : "Tu Juramento de Graduación:"}</strong>
              <p style="margin-top: 6px; font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">
                ${isEn 
                  ? "Open your Dragon Secrets Journal and draw a grand shooting star upon the final leaf. Inscribe beneath:" 
                  : "Toma tu 'Diario de Secretos del Dragón' (tu cuaderno mágico) y dibuja una estrella fugaz grande en la última página. Escribí debajo:"}
              </p>
              <p style="margin: 8px 0 0 0; font-style: italic; color: var(--text-gold); background: rgba(233,196,106,0.1); padding: 10px; border-radius: 8px; font-weight: 700; text-align: center;">
                ${isEn 
                  ? "&quot;I vow to use my magic to uplift the world and continue learning each and every day.&quot;" 
                  : "&quot;Prometo usar mi magia para ayudar al mundo y seguir aprendiendo todos los días.&quot;"}
              </p>
              <p style="margin-top: 10px; font-size: 0.9rem; color: var(--text-muted); text-align: center;">
                ${isEn 
                  ? "Seal with your Magical Name and celebrate joyfully with your Guardian Dragon! 🎉🐉✨" 
                  : "¡Firma con tu Nombre Mágico y celebra con tu Dragón Guardián! 🎉🐉✨"}
              </p>
            </div>
          </div>

        </div>
      `;
  }
}



const QUIZ_QUESTIONS = [
  {
    question: "1. Si pudieras volar hacia cualquier lugar ahora mismo, ¿a dónde irías?",
    question_en: "1. If you could fly anywhere right now, where would you go?",
    options: [
      { text: "A la cima de un volcán hirviendo con lava y fuego", text_en: "To the peak of a roaring volcano boiling with lava and fire", element: "Fuego", dragonId: 2 },
      { text: "A los picos nevados y helados del Polo Norte", text_en: "To the frosted peaks and glaciers of the North Pole", element: "Hielo", dragonId: 8 },
      { text: "A explorar el palacio secreto en lo profundo del océano", text_en: "To explore the secret palace deep beneath the ocean", element: "Agua", dragonId: 26 },
      { text: "A volar entre las estrellas y las galaxias lejanas", text_en: "To soar among the radiant stars and distant galaxies", element: "Luz", dragonId: 94 }
    ]
  },
  {
    question: "2. ¿Cuál es tu superpoder favorito si fueras un dragón legendario?",
    question_en: "2. What is your favorite superpower if you were a legendary dragon?",
    options: [
      { text: "Lanzar llamaradas doradas que iluminan la noche", text_en: "Unleashing golden firestorms that illuminate the night", element: "Fuego", dragonId: 46 },
      { text: "Volverme invisible y deslizarme por las sombras", text_en: "Becoming invisible and gliding silently through shadows", element: "Sombra", dragonId: 54 },
      { text: "Controlar el clima, la lluvia y los rayos con el pensamiento", text_en: "Controlling the weather, storm clouds, and lightning at will", element: "Tormenta", dragonId: 21 },
      { text: "Convertir cualquier piedra en un diamante resplandeciente", text_en: "Transmuting rough stones into gleaming radiant crystals", element: "Cristal", dragonId: 35 }
    ]
  },
  {
    question: "3. Si alguien intentara quitarte tu tesoro, ¿qué harías?",
    question_en: "3. If someone tried to take your treasure, what would you do?",
    options: [
      { text: "Lanzar un rugido tan fuerte que haría temblar la tierra", text_en: "Release a thunderous roar that shakes the very earth", element: "Fuego", dragonId: 18 },
      { text: "Resolver un acertijo sabio para convencerlo de irse en paz", text_en: "Share an ancient riddle of wisdom to make peace", element: "Luz", dragonId: 100 },
      { text: "Engañarlo con una niebla mágica y esconder el tesoro en una cueva", text_en: "Cast an illusionary mist and conceal the hoard inside a cavern", element: "Sombra", dragonId: 27 },
      { text: "Regalarle una manzana dorada para hacernos amigos", text_en: "Offer a golden enchanted fruit and forge a friendship", element: "Naturaleza", dragonId: 11 }
    ]
  },
  {
    question: "4. ¿En qué momento del día sentís que tenés más energía?",
    question_en: "4. What time of day do you feel the most energetic?",
    options: [
      { text: "Al amanecer, cuando el sol dorado recién sale", text_en: "At sunrise, when the first golden beams break the dawn", element: "Luz", dragonId: 36 },
      { text: "Al mediodía, cuando el sol está bien caliente", text_en: "At high noon, under the blazing heat of the sun", element: "Magma", dragonId: 37 },
      { text: "Al atardecer, cuando las nubes se ponen violetas", text_en: "At twilight, when the clouds glow with purple hues", element: "Viento", dragonId: 38 },
      { text: "A la medianoche, bajo un cielo lleno de estrellas", text_en: "At midnight, beneath a sky brimming with constellations", element: "Sombra", dragonId: 97 }
    ]
  },
  {
    question: "5. ¿Qué cualidad describe mejor tu personalidad?",
    question_en: "5. Which quality describes your personality the best?",
    options: [
      { text: "Valiente y protector de mis amigos", text_en: "Brave, bold, and fiercely loyal to my friends", element: "Fuego", dragonId: 46 },
      { text: "Curioso, inteligente y apasionado por aprender cosas nuevas", text_en: "Curious, wise, and eager to learn new mysteries", element: "Luz", dragonId: 100 },
      { text: "Tranquilo, paciente y amante de la naturaleza", text_en: "Calm, patient, and deeply connected with nature", element: "Naturaleza", dragonId: 4 },
      { text: "Ágil, veloz y lleno de sorpresas divertidas", text_en: "Agile, swift, and brimming with joyful surprises", element: "Rayo", dragonId: 98 }
    ]
  }
];

let currentQuizStep = 0;
let userAnswers = [];
let quizState = "intro";

function initQuizModule(containerId = "quiz-container") {
  const container = document.getElementById(containerId);
  if (!container) return;

  renderQuizIntro(container);
}

function renderQuizIntro(container) {
  quizState = "intro";
  currentQuizStep = 0;
  userAnswers = [];

  const t = (k, fallback) => (window.I18N ? window.I18N.t(k) : fallback);

  container.innerHTML = `
    <div class="quiz-wrapper fantasy-panel" style="padding: 2rem;">
      <h2 class="panel-title" style="color: var(--gold-main); font-size: 1.6rem; margin-top: 0;">
        ${t("quiz_intro_title", "⭐ Descubrí tu Guardián Espiritual Draconiano")}
      </h2>
      <p style="font-size: 1.05rem; line-height: 1.7; color: var(--text-main);">
        ${t("quiz_intro_desc", "A lo largo de 5 dilemas sagrados, el Oráculo del Santuario evalúa tus instintos frente al peligro, tu hábitat predilecto, tu método de resolución de conflictos y tu afinidad elemental primordial (Fuego, Agua, Tierra, Viento, Luz o Sombra).")}
      </p>
      
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin: 1.5rem 0;">
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-panel); border-radius: 10px; padding: 1.2rem;">
          <h4 style="color: var(--gold-main); margin: 0 0 6px 0; font-size: 1.1rem;">${t("quiz_col1_title", "1. Tu Elemento Guía")}</h4>
          <p style="font-size: 0.9rem; margin: 0; color: var(--text-muted); line-height: 1.5;">${t("quiz_col1_desc", "Sintonía con el calor del fuego, la fluidez del agua, la solidez de la tierra o el abismo de las sombras.")}</p>
        </div>
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-panel); border-radius: 10px; padding: 1.2rem;">
          <h4 style="color: var(--gold-main); margin: 0 0 6px 0; font-size: 1.1rem;">${t("quiz_col2_title", "2. Hábitat Sagrado")}</h4>
          <p style="font-size: 0.9rem; margin: 0; color: var(--text-muted); line-height: 1.5;">${t("quiz_col2_desc", "Cavernas con gemas ancestrales, volcanes ardientes, cielos tempestuosos o fosas abisales.")}</p>
        </div>
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-panel); border-radius: 10px; padding: 1.2rem;">
          <h4 style="color: var(--gold-main); margin: 0 0 6px 0; font-size: 1.1rem;">${t("quiz_col3_title", "3. Vínculo del Códice")}</h4>
          <p style="font-size: 0.9rem; margin: 0; color: var(--text-muted); line-height: 1.5;">${t("quiz_col3_desc", "Conexión directa con uno de los 100 dragones registrados, su pergamino histórico y sus habilidades únicas.")}</p>
        </div>
      </div>

      <div class="text-center" style="margin-top: 2rem; text-align: center;">
        <button class="btn btn-gold btn-lg" id="btn-start-quiz" style="padding: 12px 32px; font-size: 1.15rem; font-weight: 700;">
          ${t("quiz_btn_start", "🔥 Comenzar el Test Draconiano")}
        </button>
      </div>
    </div>
  `;

  const btn = container.querySelector("#btn-start-quiz");
  if (btn) {
    btn.addEventListener("click", () => {
      playSound("click");
      renderQuizQuestion(container);
    });
  }
}

function renderQuizQuestion(container) {
  quizState = "question";
  if (currentQuizStep >= QUIZ_QUESTIONS.length) {
    renderQuizResult(container);
    return;
  }

  const q = QUIZ_QUESTIONS[currentQuizStep];
  const lang = (window.I18N && window.I18N.currentLang) || "es";
  const qText = (lang === "en" && q.question_en) ? q.question_en : q.question;
  const tagPregunta = window.I18N ? window.I18N.t("quiz_question_tag") : "Pregunta";
  const tagDe = window.I18N ? window.I18N.t("quiz_question_of") : "de";

  container.innerHTML = `
    <div class="quiz-wrapper fantasy-panel">
      <div class="quiz-progress-bar">
        <div class="progress-fill" style="width: ${((currentQuizStep + 1) / QUIZ_QUESTIONS.length) * 100}%"></div>
      </div>

      <span class="quiz-step-tag">${tagPregunta} ${currentQuizStep + 1} ${tagDe} ${QUIZ_QUESTIONS.length}</span>
      <h3 class="question-text">${qText}</h3>

      <div class="quiz-options-grid">
        ${q.options.map((opt, idx) => {
          const optText = (lang === "en" && opt.text_en) ? opt.text_en : opt.text;
          return `
            <button class="quiz-option-card" data-idx="${idx}">
              <span class="opt-bullet">🐉</span>
              <span class="opt-text">${optText}</span>
            </button>
          `;
        }).join("")}
      </div>
    </div>
  `;

  container.querySelectorAll(".quiz-option-card").forEach(card => {
    card.addEventListener("click", () => {
      const idx = parseInt(card.dataset.idx, 10);
      userAnswers.push(q.options[idx]);
      playSound("click");
      currentQuizStep++;
      renderQuizQuestion(container);
    });
  });
}

function renderQuizResult(container) {
  quizState = "result";
  const matchedDragonId = (userAnswers[userAnswers.length - 1] && userAnswers[userAnswers.length - 1].dragonId) || 100;
  const dragon = DRAGONS_DATA.find(d => d.id === matchedDragonId) || DRAGONS_DATA[99];

  playSound("chime");

  const lang = (window.I18N && window.I18N.currentLang) || "es";
  const enData = (window.DRAGONS_EN && window.DRAGONS_EN[dragon.id]) || {};

  const title = (lang === "en" && enData.title) ? enData.title : dragon.title;
  const myth = window.I18N ? window.I18N.translateMythology(dragon.mythology) : dragon.mythology;
  const elem = window.I18N ? window.I18N.translateElement(dragon.element) : dragon.element;
  const ability = (lang === "en" && enData.ability) ? enData.ability : dragon.ability;
  const scroll = (lang === "en" && enData.scroll) ? enData.scroll : dragon.scroll;

  const lblMyth = window.I18N ? window.I18N.t("stat_mythology") : "Mitología";
  const lblElem = window.I18N ? window.I18N.t("stat_element") : "Elemento";
  const lblAbility = window.I18N ? window.I18N.t("stat_ability") : "Habilidad Especial";
  const congrats = window.I18N ? window.I18N.t("quiz_result_congrats") : "🎉 ¡Tu Dragón Interior es";
  const btnRestartText = window.I18N ? window.I18N.t("quiz_btn_restart") : "🔄 Hacer el Test de Nuevo";

  const artworkSrc = getDragonArtworkSrc(dragon);
  const visualContent = artworkSrc
    ? `<div class="modal-img-frame" style="max-width: 440px; aspect-ratio: 4 / 3; width: 100%; height: auto; margin: 0 auto; background: #0c0b14;">
        <img src="${artworkSrc}" alt="${dragon.name}" class="modal-artwork-img" style="object-fit: contain;" />
       </div>`
    : renderDragonSVG(dragon, 280, 220);

  container.innerHTML = `
    <div class="quiz-wrapper fantasy-panel text-center">
      <h3 class="panel-title">${congrats} ${dragon.name}!</h3>
      <p class="quiz-result-subtitle">"${title}"</p>

      <div class="result-svg-box margin-top-md">
        ${visualContent}
      </div>

      <div class="result-details-box margin-top-md">
        <p><strong>${lblMyth}:</strong> ${myth} | <strong>${lblElem}:</strong> ${elem}</p>
        <p class="margin-top-sm"><strong>${lblAbility}:</strong> ${ability}</p>
        <p class="margin-top-sm italic-text">"${scroll}"</p>
      </div>

      <div class="margin-top-lg">
        <button class="btn btn-secondary btn-lg" id="btn-restart-quiz">${btnRestartText}</button>
      </div>
    </div>
  `;

  const btnRestart = container.querySelector("#btn-restart-quiz");
  if (btnRestart) {
    btnRestart.addEventListener("click", () => {
      playSound("click");
      renderQuizIntro(container);
    });
  }
}

window.renderQuizCurrentView = function() {
  const container = document.getElementById("quiz-container");
  if (!container) return;
  if (quizState === "question") {
    renderQuizQuestion(container);
  } else if (quizState === "result") {
    renderQuizResult(container);
  } else if (quizState === "intro") {
    renderQuizIntro(container);
  }
};
window.initQuizModule = initQuizModule;



// Arena de Dragones - Modos:
// 1. Duelo Rápido 1 vs 1
// 2. El Torneo del Santuario (Modo Copa / Roguelite)
// 3. Batalla de Escuadrones 5 vs 5 (Guerra de Clanes)

// Estado global de la Arena
let currentMode = "duel"; // "duel" | "tournament" | "squad"

// ==========================================
// ESTADO: MODO DUELO 1 VS 1
// ==========================================
let dragonA = null;
let dragonB = null;
let isBattling = false;
let battleInterval = null;
let duelWinner = null; // { winner, loser }

// ==========================================
// ESTADO: MODO TORNEO ROGUELITE
// ==========================================
let playerDragon = null;
let tournamentStage = 0; // 0 = selección, 1 = Cuartos, 2 = Semis, 3 = Final, 5 = Campeón, -1 = Derrota
let playerHp = 130;
let playerMaxHp = 130;
let playerAttackBonus = 0;
let playerDefenseBonus = 0;
let playerRelics = [];
let currentOpponent = null;
let opponentHp = 100;
let opponentMaxHp = 100;
let tournamentOpponents = [];
let isTournamentBattling = false;
let tournamentInterval = null;
let firstTournamentStrikeUsed = false;

// ==========================================
// ESTADO: MODO ESCUADRONES 5 VS 5
// ==========================================
let squadNameA = "Legión Dracónica";
let squadNameB = "Horda Ancestral";
let squadA = []; // 5 dragones
let squadB = []; // 5 dragones
let squadHpA = []; // [hp1, hp2, hp3, hp4, hp5]
let squadHpB = []; // [hp1, hp2, hp3, hp4, hp5]
let activeIndexA = 0; // 0 a 4
let activeIndexB = 0; // 0 a 4
let isSquadBattling = false;
let squadInterval = null;
let squadBattleEnded = false;
let squadWinnerTeam = null; // "A" | "B"

// ==========================================
// ESTADO: MODAL DE BÚSQUEDA RÁPIDA DE DRAGONES
// ==========================================
let activePickerContext = null; // { type: "duel", key: "A" } | { type: "tourney" } | { type: "squad", team: "A", index: 0 }
let pickerSearchQuery = "";
let pickerElementFilter = "Todos";


// Helpers de Internacionalización para la Arena
const t = (k, fallback = "") => (window.I18N ? window.I18N.t(k) : fallback || k);
const isEn = () => (window.I18N && window.I18N.currentLang === "en");

const getDragonTitle = (d) => {
  if (!d) return "";
  if (isEn() && window.DRAGONS_EN && window.DRAGONS_EN[d.id] && window.DRAGONS_EN[d.id].title) {
    return window.DRAGONS_EN[d.id].title;
  }
  return d.title;
};

const getDragonAbility = (d) => {
  if (!d) return "";
  if (isEn() && window.DRAGONS_EN && window.DRAGONS_EN[d.id] && window.DRAGONS_EN[d.id].ability) {
    return window.DRAGONS_EN[d.id].ability;
  }
  return d.ability;
};

const getDragonWeakness = (d) => {
  if (!d) return "";
  if (isEn() && window.DRAGONS_EN && window.DRAGONS_EN[d.id] && window.DRAGONS_EN[d.id].weakness) {
    return window.DRAGONS_EN[d.id].weakness;
  }
  return d.weakness;
};

const getDragonElement = (d) => {
  if (!d) return "";
  return window.I18N ? window.I18N.translateElement(d.element) : d.element;
};

const getDragonType = (d) => {
  if (!d) return "";
  return window.I18N ? window.I18N.translateType(d.type) : d.type;
};

const STAGE_NAMES_ES = [
  "Selección de Guardián",
  "Ronda 1: Cuartos de Final",
  "Ronda 2: Semifinal Épica",
  "Ronda 3: La Gran Final Ancestral",
  "🏆 ¡CAMPEÓN ABSOLUTO DEL SANTUARIO!"
];

const STAGE_NAMES_EN = [
  "Guardian Selection",
  "Round 1: Quarterfinals",
  "Round 2: Epic Semifinal",
  "Round 3: Grand Ancestral Final",
  "🏆 ABSOLUTE SANCTUARY CHAMPION!"
];

function getStageName(stageIndex) {
  const list = isEn() ? STAGE_NAMES_EN : STAGE_NAMES_ES;
  return list[stageIndex] || (isEn() ? "Tournament Battle" : "Combate del Torneo");
}

// Rueda de Ventajas Elementales
const ELEMENTAL_ADVANTAGE = {
  "Fuego": ["Hielo", "Naturaleza"],
  "Magma": ["Hielo", "Naturaleza", "Tierra"],
  "Agua": ["Fuego", "Magma", "Tierra"],
  "Hielo": ["Agua", "Naturaleza", "Viento"],
  "Tierra": ["Rayo", "Tormenta", "Fuego"],
  "Cristal": ["Rayo", "Luz", "Sombra"],
  "Rayo": ["Agua", "Viento"],
  "Tormenta": ["Agua", "Veneno", "Viento"],
  "Viento": ["Veneno", "Tierra"],
  "Naturaleza": ["Tierra", "Agua"],
  "Luz": ["Sombra", "Veneno"],
  "Sombra": ["Luz", "Naturaleza"],
  "Veneno": ["Naturaleza", "Luz"]
};

// Reliquias Ancestrales (Mejoras Roguelite)
const BLESSINGS_POOL = [
  { id: "ruby", name: "Rubí del Corazón de Dragón", name_en: "Dragon Heart Ruby", icon: "❤️‍🔥", desc: "+35 de Salud Máxima y cura 50 HP", desc_en: "+35 Max Health and heals 50 HP", apply: () => { playerMaxHp += 35; playerHp = Math.min(playerMaxHp, playerHp + 50); } },
  { id: "claw", name: "Garra de Titanita Ígnea", name_en: "Fire Titanite Claw", icon: "🗡️", desc: "+6 de Daño Físico y Mágico permanente", desc_en: "+6 Permanent Physical & Magic Damage", apply: () => { playerAttackBonus += 6; } },
  { id: "scale", name: "Escama de Diamante Astral", name_en: "Astral Diamond Scale", icon: "🛡️", desc: "-4 de Daño recibido en cada golpe enemigo", desc_en: "-4 Damage taken from each enemy strike", apply: () => { playerDefenseBonus += 4; } },
  { id: "breath", name: "Elixir del Aliento Infinito", name_en: "Infinite Breath Elixir", icon: "🧪", desc: "Aumenta la probabilidad de Golpe Crítico", desc_en: "Increases Critical Hit chance", apply: () => { playerRelics.push("crit_boost"); } },
  { id: "fountain", name: "Fuente de Rocío Draconiano", name_en: "Draconian Dew Fountain", icon: "💧", desc: "Restaura el 100% de la Salud actual", desc_en: "Restores 100% current Health", apply: () => { playerHp = playerMaxHp; } }
];

function ensureArenaInitialized() {
  if (typeof DRAGONS_DATA === "undefined" || !DRAGONS_DATA || !DRAGONS_DATA.length) return;
  if (!dragonA) dragonA = DRAGONS_DATA.find(d => d.id === 2) || DRAGONS_DATA[0];
  if (!dragonB) pickRandomRival();
  if (!playerDragon) playerDragon = DRAGONS_DATA.find(d => d.id === 1) || DRAGONS_DATA[0];
  if (!squadA || squadA.length !== 5 || !squadB || squadB.length !== 5) {
    initDefaultSquads();
  }
}

function initColiseoModule(containerId = "arena-container") {
  const container = document.getElementById("arena-container") || document.getElementById(containerId);
  if (!container) return;

  ensureArenaInitialized();
  window.isArenaMounted = true;

  renderArenaContainer(container);
}

function initDefaultSquads() {
  if (squadA.length === 5 && squadB.length === 5) return;

  squadA = [
    DRAGONS_DATA[0], // #1 Furia Nocturna
    DRAGONS_DATA[1], // #2 Fafnir
    DRAGONS_DATA[2], // #3 Quetzalcóatl
    DRAGONS_DATA[3], // #4 Leviatán
    DRAGONS_DATA[4]  // #5 Wyvern de Fuego
  ];
  squadHpA = [100, 100, 100, 100, 100];

  const pool = DRAGONS_DATA.slice(5);
  const shuffled = [...pool].sort(() => 0.5 - Math.random());
  squadB = shuffled.slice(0, 5);
  squadHpB = [100, 100, 100, 100, 100];

  activeIndexA = 0;
  activeIndexB = 0;
  isSquadBattling = false;
  squadBattleEnded = false;
}

function pickRandomRival() {
  const otherDragons = DRAGONS_DATA.filter(d => !dragonA || d.id !== dragonA.id);
  const randomIndex = Math.floor(Math.random() * otherDragons.length);
  dragonB = otherDragons[randomIndex] || DRAGONS_DATA[1];
}

// Switch entre Modos
window.switchArenaMode = function(mode) {
  if (isBattling || isTournamentBattling || isSquadBattling) return;
  currentMode = mode;
  playSound("click");
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

function renderArenaContainer(container) {
  ensureArenaInitialized();
  window.isArenaMounted = true;
  container.innerHTML = `
    <div style="max-width: 1100px; margin: 0 auto;">
      
      <!-- SELECTOR DE MODO DE JUEGO (TABS DE LA ARENA) -->
      <div style="display: flex; justify-content: center; gap: 10px; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <button type="button" class="btn ${currentMode === 'duel' ? 'btn-gold' : 'btn-secondary'}" onclick="switchArenaMode('duel')" style="padding: 9px 20px; font-weight: 700; font-size: 0.95rem; border-radius: 20px;">
          ${t("arena_tab_duel", "⚔️ Duelo 1 vs 1")}
        </button>
        <button type="button" class="btn ${currentMode === 'tournament' ? 'btn-gold' : 'btn-secondary'}" onclick="switchArenaMode('tournament')" style="padding: 9px 20px; font-weight: 700; font-size: 0.95rem; border-radius: 20px;">
          ${t("arena_tab_tourney", "🏆 El Torneo (Modo Copa)")}
        </button>
        <button type="button" class="btn ${currentMode === 'squad' ? 'btn-gold' : 'btn-secondary'}" onclick="switchArenaMode('squad')" style="padding: 9px 20px; font-weight: 700; font-size: 0.95rem; border-radius: 20px;">
          ${t("arena_tab_squad", "🛡️ Batalla 5 vs 5 (Escuadrones)")}
        </button>
      </div>

      <!-- CONTENIDO DEL MODO ACTIVO -->
      <div id="arena-mode-content">
        ${currentMode === 'duel' ? renderDuelViewHtml() : (currentMode === 'tournament' ? renderTournamentViewHtml() : renderSquadViewHtml())}
      </div>

      <!-- MODAL DE BÚSQUEDA RÁPIDA DE DRAGONES -->
      <div id="arena-picker-modal-root"></div>

    </div>
  `;
}

/* ==========================================================================
   1. MODO DUELO RÁPIDO 1 VS 1
   ========================================================================== */

function renderDuelViewHtml() {
  ensureArenaInitialized();
  if (!dragonA) dragonA = (typeof DRAGONS_DATA !== "undefined" && DRAGONS_DATA.length) ? DRAGONS_DATA[0] : null;
  if (!dragonB) pickRandomRival();
  if (duelWinner) {
    const { winner, loser } = duelWinner;
    return `
      <!-- PANTALLA DE VICTORIA DUELO 1 VS 1 (SIN COPA) -->
      <div class="fantasy-panel text-center" style="padding: 2.5rem 1.5rem; border: 3px solid var(--gold-main); border-radius: 20px; background: radial-gradient(circle, rgba(233,196,106,0.2) 0%, rgba(15,23,42,0.96) 100%); margin-bottom: 2rem; box-shadow: 0 10px 40px rgba(233,196,106,0.25);">
        <div style="font-size: 3.5rem; margin-bottom: 6px; animation: pulse 1.5s infinite;">👑⚔️✨</div>
        <h2 style="color: var(--gold-main); font-size: 2.3rem; font-family: var(--font-heading); margin: 0 0 10px 0;">${t("arena_duel_victory_title", "¡VICTORIA EN EL DUELO SINGULAR!")}</h2>
        <p style="color: #80ed99; font-size: 1.25rem; font-weight: 700; margin-bottom: 2rem;">
          ¡<strong>${winner.name}</strong> ha superado a <strong>${loser.name}</strong> demostrando la supremacía de su linaje ancestral!
        </p>

        <!-- DUELO DE RETRATOS: VENCEDOR Y DERROTADO -->
        <div style="display: flex; justify-content: center; align-items: center; gap: 2rem; flex-wrap: wrap; margin-bottom: 2rem;">
          <!-- DRAGÓN GANADOR -->
          <div class="fantasy-panel" style="max-width: 320px; width: 100%; padding: 1.5rem 1rem; border: 2px solid var(--gold-main); border-radius: 16px; background: rgba(10,9,17,0.9); box-shadow: 0 0 25px rgba(233,196,106,0.4);">
            <span class="badge" style="background: rgba(42,157,143,0.25); color: #80ed99; border: 1px solid #2a9d8f; font-weight: 800; margin-bottom: 10px; display: inline-block;">${t("arena_duel_winner_badge", "👑 Vencedor del Duelo")}</span>
            <div style="aspect-ratio: 4/3; width: 100%; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); margin-bottom: 12px; background: #0a0911;">
              <img src="${getDragonArtworkSrc(winner)}" alt="${winner.name}" style="width: 100%; height: 100%; object-fit: cover;" />
            </div>
            <h3 style="color: var(--gold-main); font-size: 1.35rem; margin: 0 0 4px 0;">${winner.name}</h3>
            <p style="color: var(--color-teal); font-style: italic; font-size: 0.95rem; margin: 0 0 10px 0;">"${getDragonTitle(winner)}"</p>
            <div style="display: flex; gap: 6px; flex-wrap: wrap; justify-content: center;">
              <span class="badge badge-element badge-${winner.element.toLowerCase()}">${getDragonElement(winner)}</span>
              <span class="badge badge-type">${getDragonType(winner)}</span>
              <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${winner.danger}/5</span>
            </div>
          </div>

          <div style="font-size: 2rem; color: var(--text-muted); font-weight: 800;">VS</div>

          <!-- DRAGÓN DERROTADO -->
          <div class="fantasy-panel" style="max-width: 240px; width: 100%; padding: 1.2rem 1rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 16px; background: rgba(10,9,17,0.6); opacity: 0.75;">
            <span class="badge badge-danger" style="margin-bottom: 10px; display: inline-block;">${t("arena_duel_defeated_badge", "💀 Derrotado")}</span>
            <div style="aspect-ratio: 4/3; width: 100%; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.2); margin-bottom: 10px; background: #0a0911; position: relative;">
              <img src="${getDragonArtworkSrc(loser)}" alt="${loser.name}" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.5;" />
              <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #ff4757; font-size: 2.2rem;">💀</div>
            </div>
            <h4 style="color: var(--text-main); font-size: 1.1rem; margin: 0 0 4px 0;">${loser.name}</h4>
            <span style="color: var(--text-muted); font-size: 0.85rem;">${getDragonElement(loser)} · ${getDragonType(loser)}</span>
          </div>
        </div>

        <div style="display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
          <button type="button" class="btn btn-gold btn-lg" onclick="resetDragonDuel()" style="padding: 14px 34px; font-weight: 800; font-size: 1.15rem; box-shadow: 0 6px 20px rgba(233,196,106,0.4);">
            ${t("arena_duel_again_btn", "⚔️ Disputar Otro Duelo")}
          </button>
        </div>
      </div>
    `;
  }

  return `
    <!-- HERO BANNER ARENA DUELO -->
    <div class="fantasy-panel text-center margin-bottom-lg" style="padding: 1.8rem; background: linear-gradient(135deg, rgba(230,57,70,0.18), rgba(233,196,106,0.12)); border: 2px solid #e63946; border-radius: 20px;">
      <div style="font-size: 2.5rem; margin-bottom: 4px;">⚔️🔥</div>
      <h2 style="color: var(--gold-main); font-size: 1.9rem; margin: 0; font-family: var(--font-heading);">${t("arena_duel_banner_title", "La Arena Ancestral: Duelo 1 vs 1")}</h2>
      <p style="color: var(--text-main); font-size: 1rem; max-width: 700px; margin: 6px auto 0 auto; line-height: 1.5;">
        ${t("arena_duel_banner_desc", "¡Elegí a dos titanes del Santuario y presenciá un combate legendario por turnos con ventajas elementales y cálculo de daño épico!")}
      </p>
    </div>

    <!-- ARENA DE COMBATE (LADO A VS LADO B) -->
    <div class="arena-grid">
      
      <!-- FICHA LUCHADOR 1 (IZQUIERDA) -->
      <div id="fighter-card-A" class="fantasy-panel fighter-card fighter-card-a">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-a">${t("arena_champion1", "🐲 Campeón 1")}</span>
            <button type="button" class="btn btn-secondary btn-sm" onclick="randomizeFighter('A')" ${isBattling ? "disabled" : ""}>${t("arena_random", "🎲 Al Azar")}</button>
          </div>

          <!-- BOTÓN SELECTOR RÁPIDO CON BÚSQUEDA -->
          <div style="margin-bottom: 12px;">
            <button type="button" class="arena-picker-btn" onclick="openDragonPicker('duel_A')" ${isBattling ? "disabled" : ""}>
              <span>🔍 ${dragonA ? dragonA.name + ' (' + getDragonElement(dragonA) + ')' : t("arena_choose_dragon", "Elegir Dragón")}</span>
              <span style="color: var(--gold-main); font-size: 0.8rem;">${t("arena_search_btn", "Buscar ▾")}</span>
            </button>
          </div>

          <div class="fighter-img-box">
            <img id="img-fighter-A" src="${getDragonArtworkSrc(dragonA)}" alt="${dragonA.name}" />
          </div>

          <h3 class="fighter-name">${dragonA.name}</h3>
          <p class="fighter-subtitle">"${getDragonTitle(dragonA)}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${dragonA.element.toLowerCase()}">${getDragonElement(dragonA)}</span>
            <span class="badge badge-type">${getDragonType(dragonA)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${dragonA.danger}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(dragonA)}
          </p>
          <p class="fighter-stat-text">
            <strong style="color: #ff6b6b);">${t("stat_weakness", "Debilidad")}:</strong> ${getDragonWeakness(dragonA)}
          </p>
        </div>

        <!-- BARRA DE VIDA LUCHADOR 1 -->
        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: var(--color-teal);">${t("arena_hp_label", "Puntos de Salud (HP)")}</span>
            <span id="hp-text-A" style="color: var(--color-teal);">100 / 100</span>
          </div>
          <div class="fighter-hp-track" style="border-color: var(--color-teal);">
            <div id="hp-bar-A" class="fighter-hp-fill-a"></div>
          </div>
        </div>
      </div>

      <!-- CENTRO: VERSUS & ACCIÓN -->
      <div class="arena-vs-panel">
        <div class="arena-vs-badge">VS</div>
        
        <button id="btn-start-duel" type="button" class="btn btn-gold btn-lg arena-btn-fight" onclick="startDragonDuel()" ${isBattling ? "disabled" : ""}>
          ${t("arena_fight_btn", "⚔️ ¡COMBATIR!")}
        </button>
        
        <button id="btn-reset-duel" type="button" class="btn btn-secondary btn-sm margin-top-sm" onclick="resetDragonDuel()" style="display: none;">
          ${t("arena_new_battle", "🔄 Nuevo Combate")}
        </button>
      </div>

      <!-- FICHA LUCHADOR 2 (DERECHA) -->
      <div id="fighter-card-B" class="fantasy-panel fighter-card fighter-card-b">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-b">${t("arena_champion2", "🐲 Campeón 2")}</span>
            <button type="button" class="btn btn-secondary btn-sm" onclick="randomizeFighter('B')" ${isBattling ? "disabled" : ""}>${t("arena_random", "🎲 Al Azar")}</button>
          </div>

          <!-- BOTÓN SELECTOR RÁPIDO CON BÚSQUEDA -->
          <div style="margin-bottom: 12px;">
            <button type="button" class="arena-picker-btn" onclick="openDragonPicker('duel_B')" ${isBattling ? "disabled" : ""}>
              <span>🔍 ${dragonB ? dragonB.name + ' (' + getDragonElement(dragonB) + ')' : t("arena_choose_dragon", "Elegir Dragón")}</span>
              <span style="color: var(--gold-main); font-size: 0.8rem;">${t("arena_search_btn", "Buscar ▾")}</span>
            </button>
          </div>

          <div class="fighter-img-box">
            <img id="img-fighter-B" src="${getDragonArtworkSrc(dragonB)}" alt="${dragonB.name}" />
          </div>

          <h3 class="fighter-name">${dragonB.name}</h3>
          <p class="fighter-subtitle">"${getDragonTitle(dragonB)}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${dragonB.element.toLowerCase()}">${getDragonElement(dragonB)}</span>
            <span class="badge badge-type">${getDragonType(dragonB)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${dragonB.danger}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(dragonB)}
          </p>
          <p class="fighter-stat-text">
            <strong style="color: #ff6b6b);">${t("stat_weakness", "Debilidad")}:</strong> ${getDragonWeakness(dragonB)}
          </p>
        </div>

        <!-- BARRA DE VIDA LUCHADOR 2 -->
        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: #ff6b6b;">${t("arena_hp_label", "Puntos de Salud (HP)")}</span>
            <span id="hp-text-B" style="color: #ff6b6b;">100 / 100</span>
          </div>
          <div class="fighter-hp-track" style="border-color: #ff4757;">
            <div id="hp-bar-B" class="fighter-hp-fill-b"></div>
          </div>
        </div>
      </div>

    </div>

    <!-- CRÓNICA DE BATALLA (BATTLE LOG) -->
    <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--border-gold); background: rgba(10, 9, 17, 0.95); border-radius: 16px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid var(--border-panel); padding-bottom: 8px;">
        <h3 style="color: var(--gold-main); margin: 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          ${t("arena_log_title", "📜 Crónica Épica de la Batalla")}
        </h3>
        <span id="round-indicator" style="color: var(--text-muted); font-size: 0.9rem; font-weight: bold;">${t("arena_ready_combat", "Listo para el combate")}</span>
      </div>

      <div id="battle-log-box" style="height: 180px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; padding-right: 8px; font-size: 0.95rem; line-height: 1.5; color: var(--text-main);">
        <div style="color: var(--text-muted); font-style: italic; text-align: center; padding-top: 50px;">
          ${t("arena_press_fight", "Presioná \"¡COMBATIR!\" para dar inicio a los rugidos en la Arena...")}
        </div>
      </div>
    </div>
  `;
}

window.selectDuelDragon = function(fighterKey, dragonId) {
  if (isBattling) return;
  const selected = DRAGONS_DATA.find(d => d.id === parseInt(dragonId));
  if (!selected) return;

  if (fighterKey === "A") dragonA = selected;
  else dragonB = selected;
  
  playSound("click");
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.randomizeFighter = function(fighterKey) {
  if (isBattling) return;
  playSound("click");
  const randomIndex = Math.floor(Math.random() * DRAGONS_DATA.length);
  if (fighterKey === "A") dragonA = DRAGONS_DATA[randomIndex];
  else dragonB = DRAGONS_DATA[randomIndex];

  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.resetDragonDuel = function() {
  if (battleInterval) clearInterval(battleInterval);
  isBattling = false;
  duelWinner = null;
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.startDragonDuel = function() {
  if (isBattling || !dragonA || !dragonB) return;
  if (dragonA.id === dragonB.id) {
    alert("¡Por favor elegí dos dragones distintos para el enfrentamiento!");
    return;
  }

  duelWinner = null;
  isBattling = true;
  playSound("roar");

  const btnStart = document.getElementById("btn-start-duel");
  const btnReset = document.getElementById("btn-reset-duel");
  if (btnStart) btnStart.style.display = "none";
  if (btnReset) btnReset.style.display = "none";

  const logBox = document.getElementById("battle-log-box");
  const roundIndicator = document.getElementById("round-indicator");
  if (logBox) logBox.innerHTML = "";

  let hpA = 100;
  let hpB = 100;
  let round = 1;

  const advA = (ELEMENTAL_ADVANTAGE[dragonA.element] || []).includes(dragonB.element);
  const advB = (ELEMENTAL_ADVANTAGE[dragonB.element] || []).includes(dragonA.element);

  const elemA = getDragonElement(dragonA);
  const elemB = getDragonElement(dragonB);
  if (isEn()) {
    appendBattleLog(`⚔️ <strong>The epic duel between ${dragonA.name} and ${dragonB.name} begins!</strong>`, "gold");
    if (advA) {
      appendBattleLog(`🔥 Elemental Advantage! ${dragonA.name}'s <strong>${elemA}</strong> element dominates ${dragonB.name}'s <strong>${elemB}</strong> element.`, "teal");
    } else if (advB) {
      appendBattleLog(`⚡ Elemental Advantage! ${dragonB.name}'s <strong>${elemB}</strong> element dominates ${dragonA.name}'s <strong>${elemA}</strong> element.`, "rust");
    }
  } else {
    appendBattleLog(`⚔️ <strong>¡Comienza el duelo épico entre ${dragonA.name} y ${dragonB.name}!</strong>`, "gold");
    if (advA) {
      appendBattleLog(`🔥 ¡Ventaja Elemental! El elemento <strong>${elemA}</strong> de ${dragonA.name} domina al <strong>${elemB}</strong> de ${dragonB.name}.`, "teal");
    } else if (advB) {
      appendBattleLog(`⚡ ¡Ventaja Elemental! El elemento <strong>${elemB}</strong> de ${dragonB.name} domina al <strong>${elemA}</strong> de ${dragonA.name}.`, "rust");
    }
  }

  battleInterval = setInterval(() => {
    if (roundIndicator) roundIndicator.textContent = `Asalto ${round}`;

    // Turno de A atacando a B
    const resultA = calculateAttack(dragonA, dragonB, advA);
    hpB = Math.max(0, hpB - resultA.damage);
    updateHpBars(hpA, hpB);

    playSound("hit");
    appendBattleLog(resultA.log, resultA.isCrit ? "gold" : "main");

    if (hpB <= 0) {
      endBattle(dragonA, dragonB);
      return;
    }

    // Turno de B atacando a A
    setTimeout(() => {
      if (hpB <= 0) return;
      const resultB = calculateAttack(dragonB, dragonA, advB);
      hpA = Math.max(0, hpA - resultB.damage);
      updateHpBars(hpA, hpB);

      playSound("hit");
      appendBattleLog(resultB.log, resultB.isCrit ? "rust" : "main");

      if (hpA <= 0) {
        endBattle(dragonB, dragonA);
      }
    }, 600);

    round++;
    if (round > 8 && hpA > 0 && hpB > 0) {
      hpA > hpB ? endBattle(dragonA, dragonB) : endBattle(dragonB, dragonA);
    }
  }, 1400);
};

function calculateAttack(attacker, defender, hasAdvantage) {
  const basePower = attacker.danger * 7 + Math.floor(Math.random() * 8);
  const elementBonus = hasAdvantage ? 8 : 0;
  const isCrit = Math.random() < 0.35 || hasAdvantage;
  const critMultiplier = isCrit ? 1.4 : 1.0;
  const totalDamage = Math.round((basePower + elementBonus) * critMultiplier);

  const en = isEn();
  const aName = attacker.name;
  const dName = defender.name;
  const aAbility = getDragonAbility(attacker);
  const aType = getDragonType(attacker);
  const aElement = getDragonElement(attacker);

  const attackNarratives = en ? [
    `<strong>${aName}</strong> unleashes <em>${aAbility}</em> dealing <strong>${totalDamage}</strong> damage!`,
    `<strong>${aName}</strong> strikes with the full force of its <em>${aType}</em> body, dealing <strong>${totalDamage}</strong> damage to ${dName}!`,
    `<strong>${aName}</strong> invokes a burst of <em>${aElement}</em> power, striking for <strong>${totalDamage}</strong> damage!`
  ] : [
    `¡<strong>${aName}</strong> desata su <em>${aAbility}</em> causando <strong>${totalDamage}</strong> de daño!`,
    `¡<strong>${aName}</strong> embiste con toda la fuerza de su cuerpo tipo <em>${aType}</em> propinando <strong>${totalDamage}</strong> de daño a ${dName}!`,
    `¡<strong>${aName}</strong> invoca una ráfaga de poder <em>${aElement}</em> impactando con <strong>${totalDamage}</strong> de daño!`
  ];

  let chosenNarrative = attackNarratives[Math.floor(Math.random() * attackNarratives.length)];
  if (isCrit) chosenNarrative = (en ? `💥 CRITICAL HIT! ` : `💥 ¡GOLPE CRÍTICO! `) + chosenNarrative;

  return { damage: totalDamage, isCrit, log: chosenNarrative };
}

function updateHpBars(hpA, hpB) {
  const barA = document.getElementById("hp-bar-A");
  const barB = document.getElementById("hp-bar-B");
  const textA = document.getElementById("hp-text-A");
  const textB = document.getElementById("hp-text-B");

  if (barA) barA.style.width = `${hpA}%`;
  if (barB) barB.style.width = `${hpB}%`;
  if (textA) textA.textContent = `${hpA} / 100`;
  if (textB) textB.textContent = `${hpB} / 100`;
}

function appendBattleLog(message, styleType = "main") {
  const logBox = document.getElementById("battle-log-box");
  if (!logBox) return;

  const entry = document.createElement("div");
  entry.style.padding = "6px 10px";
  entry.style.borderRadius = "6px";
  entry.style.animation = "fadeIn 0.3s ease";

  if (styleType === "gold") {
    entry.style.background = "rgba(233,196,106,0.15)";
    entry.style.borderLeft = "3px solid var(--gold-main)";
    entry.style.color = "var(--gold-light)";
  } else if (styleType === "teal") {
    entry.style.background = "rgba(42,157,143,0.15)";
    entry.style.borderLeft = "3px solid var(--color-teal)";
    entry.style.color = "#80ed99";
  } else if (styleType === "rust") {
    entry.style.background = "rgba(230,57,70,0.15)";
    entry.style.borderLeft = "3px solid #ff4757";
    entry.style.color = "#ff9f1c";
  } else {
    entry.style.background = "rgba(255,255,255,0.03)";
    entry.style.color = "var(--text-main)";
  }

  entry.innerHTML = message;
  logBox.appendChild(entry);
  logBox.scrollTop = logBox.scrollHeight;
}

function endBattle(winner, loser) {
  if (battleInterval) clearInterval(battleInterval);
  isBattling = false;
  playSound("victory");

  appendBattleLog(`⚔️👑 <strong>¡VICTORIA ÉPICA! ¡${winner.name} ha vencido en el duelo singular demostrando la supremacía de su linaje!</strong>`, "gold");

  const btnReset = document.getElementById("btn-reset-duel");
  if (btnReset) btnReset.style.display = "inline-block";

  setTimeout(() => {
    duelWinner = { winner, loser };
    const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
    if (container) renderArenaContainer(container);
  }, 1400);
}


/* ==========================================================================
   2. MODO EL TORNEO DEL SANTUARIO (MODO COPA / ROGUELITE)
   ========================================================================== */

const STAGE_NAMES = [
  "Selección de Guardián",
  "Ronda 1: Cuartos de Final",
  "Ronda 2: Semifinal Épica",
  "Ronda 3: La Gran Final Ancestral",
  "🏆 ¡CAMPEÓN ABSOLUTO DEL SANTUARIO!"
];

function renderTournamentViewHtml() {
  ensureArenaInitialized();
  if (!playerDragon) playerDragon = (typeof DRAGONS_DATA !== "undefined" && DRAGONS_DATA.length) ? DRAGONS_DATA[0] : null;
  if (tournamentStage > 0 && !currentOpponent) {
    if (tournamentOpponents.length >= tournamentStage) {
      currentOpponent = tournamentOpponents[tournamentStage - 1];
    } else if (typeof DRAGONS_DATA !== "undefined" && DRAGONS_DATA.length) {
      currentOpponent = DRAGONS_DATA.find(d => !playerDragon || d.id !== playerDragon.id) || DRAGONS_DATA[1];
    }
  }
  if (tournamentStage === 0) {
    return `
      <div class="fantasy-panel text-center margin-bottom-lg" style="padding: 2rem; background: linear-gradient(135deg, rgba(233,196,106,0.15), rgba(42,157,143,0.15)); border: 2px solid var(--gold-main); border-radius: 20px;">
        <div style="font-size: 3rem; margin-bottom: 6px;">🏆🔥</div>
        <h2 style="color: var(--gold-main); font-size: 2rem; margin: 0; font-family: var(--font-heading);">${t("arena_tourney_title", "El Torneo del Santuario")}</h2>
        <p style="color: var(--text-main); font-size: 1.05rem; max-width: 750px; margin: 8px auto 0 auto; line-height: 1.6;">
          ${t("arena_tourney_desc", "¡Elegí a tu dragón guardián y avanzá a través de 3 rondas eliminatorias consecutivas! Entre victoria y victoria podrás elegir Reliquias y Bendiciones Ancestrales para curarte y potenciar tus ataques.")}
        </p>
      </div>

      <div class="fantasy-panel" style="max-width: 600px; margin: 0 auto 2rem auto; padding: 2rem; border: 2px solid var(--border-gold); text-align: center; border-radius: 16px;">
        <h3 style="color: var(--gold-light); margin-top: 0; margin-bottom: 12px;">${t("arena_choose_champ", "Elegí a tu Campeón:")}</h3>

        <!-- BOTÓN SELECTOR RÁPIDO TORNEO -->
        <div style="margin-bottom: 15px;">
          <button type="button" class="arena-picker-btn" onclick="openDragonPicker('tourney')">
            <span>🔍 ${playerDragon ? playerDragon.name + ' (' + getDragonElement(playerDragon) + ') - ' + t("danger_prefix", "Peligro") + ' ' + playerDragon.danger + '/5' : t("arena_choose_champ_btn", "Elegir Campeón")}</span>
            <span style="color: var(--gold-main); font-size: 0.8rem;">${t("arena_search_btn", "Buscar ▾")}</span>
          </button>
        </div>

        <div style="width: 100%; height: 240px; border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-main); margin-bottom: 15px; background: #0a0911;">
          <img src="${getDragonArtworkSrc(playerDragon)}" alt="${playerDragon.name}" style="width: 100%; height: 100%; object-fit: cover;" />
        </div>

        <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-bottom: 15px;">
          <span class="badge badge-element badge-${playerDragon.element.toLowerCase()}">${getDragonElement(playerDragon)}</span>
          <span class="badge badge-type">${getDragonType(playerDragon)}</span>
          <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${playerDragon.danger}/5</span>
        </div>

        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 20px;">
          <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad Especial")}:</strong> ${getDragonAbility(playerDragon)}
        </p>

        <button type="button" class="btn btn-gold btn-lg" onclick="startTournamentRun()" style="width: 100%; padding: 14px; font-size: 1.2rem; font-weight: 800; box-shadow: 0 6px 20px rgba(233,196,106,0.4);">
          ${t("arena_start_tourney", "🏆 ¡INICIAR EL TORNEO!")}
        </button>
      </div>
    `;
  }

  if (tournamentStage === 5) {
    return `
      <div class="fantasy-panel text-center" style="padding: 2.5rem 1.5rem; border: 3px solid var(--gold-main); border-radius: 20px; background: radial-gradient(circle, rgba(233,196,106,0.25) 0%, rgba(15,23,42,0.95) 100%);">
        <div style="font-size: 3.5rem; margin-bottom: 6px; animation: pulse 1.5s infinite;">👑🏆✨</div>
        <h1 style="color: var(--gold-main); font-size: 2.4rem; font-family: var(--font-heading); margin: 0 0 10px 0;">${t("arena_champ_supreme", "¡CAMPEÓN SUPREMO DEL SANTUARIO!")}</h1>
        <p style="color: #80ed99; font-size: 1.25rem; font-weight: 700; margin-bottom: 1.5rem;">
          ¡Tu dragón <strong>${playerDragon.name}</strong> ha triunfado en la arena y alzado la legendaria Copa Draconiana ante la multitud!
        </p>

        <!-- ILUSTRACIÓN DE LA COPA Y CAMPEÓN -->
        <div style="display: flex; justify-content: center; align-items: center; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 1.8rem;">
          <div style="width: 100%; max-width: 480px; border-radius: 16px; overflow: hidden; border: 3px solid var(--gold-main); box-shadow: 0 8px 30px rgba(233,196,106,0.45); background: #0a0911;">
            <img src="/assets/ui/trophy_champion.webp" alt="Copa de Campeón del Santuario" style="width: 100%; height: auto; display: block;" />
          </div>
          <div style="display: flex; flex-direction: column; align-items: center; gap: 8px;">
            <div style="width: 150px; height: 150px; border-radius: 50%; overflow: hidden; border: 3px solid var(--gold-main); box-shadow: 0 0 20px rgba(233,196,106,0.6);">
              <img src="${getDragonArtworkSrc(playerDragon)}" alt="${playerDragon.name}" style="width: 100%; height: 100%; object-fit: cover;" />
            </div>
            <span style="color: var(--gold-main); font-weight: 800; font-size: 1.1rem;">${playerDragon.name}</span>
            <span class="badge badge-element badge-${playerDragon.element.toLowerCase()}">${getDragonElement(playerDragon)}</span>
          </div>
        </div>

        <div style="margin-bottom: 2rem;">
          <h4 style="color: var(--gold-light); margin-bottom: 8px; font-size: 1.05rem;">${t("arena_relics_collected", "Reliquias Coleccionadas en esta hazaña:")}</h4>
          <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
            ${playerRelics.map(r => `<span class="badge" style="background: rgba(233,196,106,0.2); border: 1px solid var(--gold-main); color: var(--gold-main); font-size: 0.95rem;">✨ ${r}</span>`).join("") || "<span style='color: var(--text-muted);'>Victoria en estado puro sin reliquias.</span>"}
          </div>
        </div>

        <button type="button" class="btn btn-gold btn-lg" onclick="resetTournamentToStart()" style="padding: 14px 32px; font-weight: 800; font-size: 1.15rem; box-shadow: 0 6px 20px rgba(233,196,106,0.4);">
          ${t("arena_another_tourney", "🔄 Jugar Otro Torneo")}
        </button>
      </div>
    `;
  }

  if (tournamentStage === -1) {
    const roundIndex = (currentOpponent && tournamentOpponents.indexOf(currentOpponent) !== -1)
      ? tournamentOpponents.indexOf(currentOpponent) + 1
      : 1;
    const roundFailedName = getStageName(roundIndex);
    const roundsWon = Math.max(0, roundIndex - 1);

    return `
      <!-- PANTALLA DE DERROTA EN EL TORNEO ROGUELITE -->
      <div class="fantasy-panel text-center" style="padding: 2.5rem 1.5rem; border: 3px solid #ff4757; border-radius: 20px; background: radial-gradient(circle, rgba(230,57,70,0.18) 0%, rgba(15,23,42,0.98) 100%); margin-bottom: 2rem; box-shadow: 0 10px 40px rgba(255,71,87,0.3);">
        <div style="font-size: 3.5rem; margin-bottom: 6px; animation: pulse 1.8s infinite;">💀⚔️🥀</div>
        <h1 style="color: #ff6b6b; font-size: 2.3rem; font-family: var(--font-heading); margin: 0 0 8px 0; text-shadow: 0 0 20px rgba(255,71,87,0.5);">
          ${t("arena_fallen_title", "¡CAÍDO EN LA ARENA ANCESTRAL!")}
        </h1>
        <p style="color: #f1faee; font-size: 1.15rem; max-width: 680px; margin: 0 auto 1.8rem auto; line-height: 1.5;">
          Tu dragón <strong>${playerDragon.name}</strong> libró una batalla feroz pero fue superado por <strong>${currentOpponent ? currentOpponent.name : 'su rival'}</strong> en <span style="color: var(--gold-main); font-weight: 700;">${roundFailedName}</span>.
        </p>

        <!-- ILUSTRACIÓN OFICIAL DE LA DERROTA -->
        <div style="max-width: 580px; margin: 0 auto 1.8rem auto; border-radius: 18px; overflow: hidden; border: 3px solid rgba(230,57,70,0.85); box-shadow: 0 10px 35px rgba(230,57,70,0.4); background: #0a0911;">
          <picture>
            <source srcset="/assets/ui/tournament_defeat.webp" type="image/webp">
            <img src="/assets/ui/tournament_defeat.jpg" alt="El descanso del dragón caído en el Coliseo" style="width: 100%; height: auto; display: block;" />
          </picture>
          <div style="padding: 12px 18px; background: rgba(10, 9, 17, 0.95); border-top: 1px solid rgba(230,57,70,0.4); text-align: center;">
            <p style="color: var(--text-muted); font-size: 0.88rem; font-style: italic; margin: 0; line-height: 1.45;">
              "El descanso del guerrero: incluso los titanes más legendarios deben tomar aliento entre las cenizas. El fuego volverá a encenderse."
            </p>
          </div>
        </div>

        <!-- CONFRONTACIÓN DEL COMBATE FATAL -->
        <div style="display: flex; justify-content: center; align-items: stretch; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 2rem; max-width: 820px; margin-left: auto; margin-right: auto;">
          <!-- Tu Dragón Caído -->
          <div class="fantasy-panel" style="flex: 1; min-width: 260px; max-width: 360px; padding: 1.4rem; border: 2px solid #ff4757; border-radius: 16px; background: rgba(15, 23, 42, 0.85); box-shadow: 0 0 20px rgba(255,71,87,0.25);">
            <div style="margin-bottom: 10px;">
              <span class="badge badge-danger" style="font-weight: 800; padding: 4px 10px;">${t("arena_fallen_hero", "💀 Héroe Caído")}</span>
            </div>
            <div style="width: 96px; height: 96px; margin: 0 auto 10px auto; border-radius: 50%; overflow: hidden; border: 3px solid #ff4757; position: relative; background: #0a0911;">
              <img src="${getDragonArtworkSrc(playerDragon)}" alt="${playerDragon.name}" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.45; filter: grayscale(40%);" />
              <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.5); color: #ff4757; font-size: 2rem;">💀</div>
            </div>
            <h3 style="color: #ff6b6b; font-size: 1.2rem; margin: 0 0 4px 0;">${playerDragon.name}</h3>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0 0 8px 0; font-style: italic;">"${getDragonTitle(playerDragon)}"</p>
            <div style="display: flex; gap: 6px; justify-content: center; flex-wrap: wrap;">
              <span class="badge badge-element badge-${playerDragon.element.toLowerCase()}">${getDragonElement(playerDragon)}</span>
              <span class="badge badge-type">${getDragonType(playerDragon)}</span>
            </div>
          </div>

          <div style="display: flex; align-items: center; justify-content: center; font-size: 1.8rem; color: var(--text-muted); font-weight: 800;">VS</div>

          <!-- Rival Vencedor -->
          ${currentOpponent ? `
            <div class="fantasy-panel" style="flex: 1; min-width: 260px; max-width: 360px; padding: 1.4rem; border: 2px solid var(--gold-main); border-radius: 16px; background: rgba(15, 23, 42, 0.85); box-shadow: 0 0 20px rgba(233,196,106,0.3);">
              <div style="margin-bottom: 10px;">
                <span class="badge" style="background: rgba(42,157,143,0.25); color: #80ed99; border: 1px solid #2a9d8f; font-weight: 800; padding: 4px 10px;">${t("arena_victorious_rival", "👑 Rival Victorioso")}</span>
              </div>
              <div style="width: 96px; height: 96px; margin: 0 auto 10px auto; border-radius: 50%; overflow: hidden; border: 3px solid var(--gold-main); box-shadow: 0 0 16px rgba(233,196,106,0.4); background: #0a0911;">
                <img src="${getDragonArtworkSrc(currentOpponent)}" alt="${currentOpponent.name}" style="width: 100%; height: 100%; object-fit: cover;" />
              </div>
              <h3 style="color: var(--gold-main); font-size: 1.2rem; margin: 0 0 4px 0;">${currentOpponent.name}</h3>
              <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0 0 8px 0; font-style: italic;">"${getDragonTitle(currentOpponent)}"</p>
              <div style="display: flex; gap: 6px; justify-content: center; flex-wrap: wrap;">
                <span class="badge badge-element badge-${currentOpponent.element.toLowerCase()}">${getDragonElement(currentOpponent)}</span>
                <span class="badge badge-type">${getDragonType(currentOpponent)}</span>
              </div>
            </div>
          ` : ''}
        </div>

        <!-- RESUMEN ROGUELITE DEL INTENTO -->
        <div class="fantasy-panel" style="max-width: 640px; margin: 0 auto 2rem auto; padding: 1.4rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 14px; background: rgba(10,9,17,0.75);">
          <div style="display: flex; justify-content: space-around; flex-wrap: wrap; gap: 1rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 12px; margin-bottom: 12px;">
            <div>
              <span style="color: var(--text-muted); font-size: 0.85rem; display: block;">${t("arena_rounds_cleared", "Rondas Superadas")}</span>
              <strong style="color: ${roundsWon > 0 ? '#80ed99' : 'var(--text-muted)'}; font-size: 1.3rem;">${roundsWon} de 3</strong>
            </div>
            <div>
              <span style="color: var(--text-muted); font-size: 0.85rem; display: block;">${t("arena_instance_reached", "Instancia Alcanzada")}</span>
              <strong style="color: var(--gold-main); font-size: 1.15rem;">${roundFailedName}</strong>
            </div>
            <div>
              <span style="color: var(--text-muted); font-size: 0.85rem; display: block;">${t("arena_active_blessings", "Bendiciones Activas")}</span>
              <strong style="color: #9d4edd; font-size: 1.3rem;">${playerRelics.length}</strong>
            </div>
          </div>

          <div>
            <h4 style="color: var(--text-muted); margin: 0 0 8px 0; font-size: 0.9rem; text-align: left;">Reliquias Ancestrales reunidas en el intento:</h4>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center;">
              ${playerRelics.length > 0
                ? playerRelics.map(r => `<span class="badge" style="background: rgba(157,78,221,0.2); border: 1px solid #9d4edd; color: #e0aaff; font-size: 0.85rem; padding: 5px 10px;">✨ ${r}</span>`).join("")
                : `<span style="color: var(--text-muted); font-style: italic; font-size: 0.88rem;">Caíste en la primera ronda antes de poder invocar bendiciones ancestrales.</span>`
              }
            </div>
          </div>
        </div>

        <!-- BOTONES DE ACCIÓN INMEDIATA -->
        <div style="display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
          <button type="button" class="btn btn-gold btn-lg" onclick="startTournamentRun()" style="padding: 14px 28px; font-weight: 800; font-size: 1.1rem; box-shadow: 0 6px 20px rgba(233,196,106,0.4);">
            ${t("arena_retry_btn", "🔄 Reintentar con")} ${playerDragon.name}
          </button>
          <button type="button" class="btn btn-secondary btn-lg" onclick="resetTournamentToStart()" style="padding: 14px 28px; font-weight: 700; font-size: 1.1rem;">
            ${t("arena_pick_other_btn", "🐲 Elegir Otro Dragón")}
          </button>
        </div>
      </div>
    `;
  }

  const isFinal = tournamentStage === 3;
  const stageTitle = getStageName(tournamentStage);

  return `
    <!-- HEADER DE ETAPA DEL TORNEO -->
    <div class="fantasy-panel text-center margin-bottom-lg" style="padding: 1.2rem; border: 2px solid ${isFinal ? '#ff4757' : 'var(--gold-main)'}; border-radius: 16px; background: rgba(15,23,42,0.9);">
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <span class="badge" style="background: rgba(233,196,106,0.2); border: 1px solid var(--gold-main); color: var(--gold-main); font-size: 1rem; font-weight: 700;">
          ${stageTitle}
        </span>
        <div style="display: flex; gap: 8px; align-items: center;">
          <span style="color: var(--text-muted); font-size: 0.9rem;">Reliquias:</span>
          ${playerRelics.map(r => `<span title="${r}" style="font-size: 1.2rem;">⭐</span>`).join("") || "<span style='color: var(--text-muted); font-size: 0.85rem;'>Ninguna</span>"}
        </div>
        <button type="button" class="btn btn-secondary btn-sm" onclick="resetTournamentToStart()" ${isTournamentBattling ? "disabled" : ""}>
          ${t("arena_abandon_tourney", "🏳️ Abandonar Torneo")}
        </button>
      </div>
    </div>

    <!-- ARENA DEL TORNEO (TU DRAGÓN VS RIVAL DEL TORNEO) -->
    <div class="arena-grid">
      
      <!-- FICHA TU CAMPEÓN -->
      <div class="fantasy-panel fighter-card fighter-card-a">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-a">${t("arena_your_guardian", "🐲 Tu Guardián (Tú)")}</span>
            <span class="badge" style="background: rgba(42,157,143,0.2); color: #80ed99; border: 1px solid #2a9d8f;">+${playerAttackBonus} ATK / +${playerDefenseBonus} DEF</span>
          </div>

          <div class="fighter-img-box">
            <img src="${getDragonArtworkSrc(playerDragon)}" alt="${playerDragon.name}" />
          </div>

          <h3 class="fighter-name">${playerDragon.name}</h3>
          <p class="fighter-subtitle">"${getDragonTitle(playerDragon)}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${playerDragon.element.toLowerCase()}">${getDragonElement(playerDragon)}</span>
            <span class="badge badge-type">${getDragonType(playerDragon)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${playerDragon.danger}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(playerDragon)}
          </p>
        </div>

        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: var(--color-teal);">${t("arena_your_hp", "Tu Salud (HP)")}</span>
            <span id="player-hp-text" style="color: var(--color-teal);">${playerHp} / ${playerMaxHp}</span>
          </div>
          <div class="fighter-hp-track" style="border-color: var(--color-teal);">
            <div id="player-hp-bar" class="fighter-hp-fill-a" style="width: ${(playerHp / playerMaxHp) * 100}%;"></div>
          </div>
        </div>
      </div>

      <!-- CENTRO: VERSUS & ACCIÓN TORNEO -->
      <div class="arena-vs-panel">
        <div class="arena-vs-badge" style="color: ${isFinal ? '#ff4757' : 'var(--gold-main)'};">VS</div>
        
        <button id="btn-start-tourney-battle" type="button" class="btn btn-gold btn-lg arena-btn-fight" onclick="startTournamentBattle()" ${isTournamentBattling ? "disabled" : ""}>
          ${t("arena_tourney_fight_btn", "⚔️ ¡LUCHAR!")}
        </button>
      </div>

      <!-- FICHA RIVAL DE LA RONDA -->
      <div class="fantasy-panel fighter-card fighter-card-b">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-b">🐲 Rival: ${currentOpponent.name}</span>
            <span class="badge badge-danger">${isFinal ? '👑 JEFE FINAL' : 'Rival de Copa'}</span>
          </div>

          <div class="fighter-img-box">
            <img src="${getDragonArtworkSrc(currentOpponent)}" alt="${currentOpponent.name}" />
          </div>

          <h3 class="fighter-name">${currentOpponent ? currentOpponent.name : ''}</h3>
          <p class="fighter-subtitle">"${currentOpponent ? getDragonTitle(currentOpponent) : ''}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${currentOpponent ? currentOpponent.element.toLowerCase() : 'fuego'}">${getDragonElement(currentOpponent)}</span>
            <span class="badge badge-type">${getDragonType(currentOpponent)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${currentOpponent ? currentOpponent.danger : 3}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(currentOpponent)}
          </p>
          <p class="fighter-stat-text">
            <strong style="color: #ff6b6b;">${t("stat_weakness", "Debilidad")}:</strong> ${getDragonWeakness(currentOpponent)}
          </p>
        </div>

        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: #ff6b6b;">${t("arena_opp_hp", "Salud Rival (HP)")}</span>
            <span id="opp-hp-text" style="color: #ff6b6b;">${opponentHp} / ${opponentMaxHp}</span>
          </div>
          <div class="fighter-hp-track" style="border-color: #ff4757;">
            <div id="opp-hp-bar" class="fighter-hp-fill-b" style="width: ${(opponentHp / opponentMaxHp) * 100}%;"></div>
          </div>
        </div>
      </div>

    </div>

    <!-- MODAL / PANEL DE BENDICIONES ROGUELITE -->
    <div id="relic-reward-modal" style="display: none; margin-bottom: 2rem;" class="fantasy-panel">
      <h3 style="color: var(--gold-main); text-align: center; margin-top: 0;">${t("arena_relic_victory_title", "✨ ¡VICTORIA DE RONDA! Elegí tu Bendición Ancestral:")}</h3>
      <p style="text-align: center; color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.2rem;">
        ${t("arena_relic_victory_desc", "Los espíritus draconianos recompensan tu coraje. Escogé 1 bendición para fortalecerte antes de la siguiente batalla:")}
      </p>
      <div id="relic-options-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;"></div>
    </div>

    <!-- CRÓNICA DE BATALLA DEL TORNEO -->
    <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--border-gold); background: rgba(10, 9, 17, 0.95); border-radius: 16px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid var(--border-panel); padding-bottom: 8px;">
        <h3 style="color: var(--gold-main); margin: 0; font-size: 1.2rem;">
          ${t("arena_tourney_log_title", "📜 Crónica del Torneo")}
        </h3>
        <span id="tourney-round-indicator" style="color: var(--text-muted); font-size: 0.9rem; font-weight: bold;">${t("arena_tourney_waiting", "Esperando orden de combate")}</span>
      </div>

      <div id="tourney-log-box" style="height: 160px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; padding-right: 8px; font-size: 0.92rem; line-height: 1.5; color: var(--text-main);">
        <div style="color: var(--text-muted); font-style: italic; text-align: center; padding-top: 40px;">
          ${t("arena_tourney_press", "Presioná \"¡LUCHAR!\" para disputar la ronda...")}
        </div>
      </div>
    </div>
  `;
}

window.selectTournamentChampion = function(dragonId) {
  const selected = DRAGONS_DATA.find(d => d.id === parseInt(dragonId));
  if (selected) {
    playerDragon = selected;
    playSound("click");
    const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
    if (container) renderArenaContainer(container);
  }
};

window.resetTournamentToStart = function() {
  if (tournamentInterval) clearInterval(tournamentInterval);
  isTournamentBattling = false;
  tournamentStage = 0;
  playerHp = 130;
  playerMaxHp = 130;
  playerAttackBonus = 0;
  playerDefenseBonus = 0;
  playerRelics = [];
  firstTournamentStrikeUsed = false;
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.startTournamentRun = function() {
  playSound("roar");
  const pool = DRAGONS_DATA.filter(d => d.id !== playerDragon.id);
  
  const easyPool = pool.filter(d => d.danger <= 3);
  const opp1 = easyPool[Math.floor(Math.random() * easyPool.length)] || pool[0];
  
  const medPool = pool.filter(d => d.id !== opp1.id && d.danger >= 3 && d.danger <= 4);
  const opp2 = medPool[Math.floor(Math.random() * medPool.length)] || pool[1];

  const bossPool = pool.filter(d => d.id !== opp1.id && d.id !== opp2.id && d.danger === 5);
  const opp3 = bossPool[Math.floor(Math.random() * bossPool.length)] || pool[2];

  tournamentOpponents = [opp1, opp2, opp3];
  tournamentStage = 1;
  playerHp = 130;
  playerMaxHp = 130;
  playerAttackBonus = 0;
  playerDefenseBonus = 0;
  playerRelics = [];
  firstTournamentStrikeUsed = false;

  setupTournamentRound();
};

function setupTournamentRound() {
  currentOpponent = tournamentOpponents[tournamentStage - 1];
  opponentMaxHp = tournamentStage === 3 ? 140 : (tournamentStage === 2 ? 115 : 100);
  opponentHp = opponentMaxHp;

  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
}

window.startTournamentBattle = function() {
  if (isTournamentBattling || !playerDragon || !currentOpponent) return;

  isTournamentBattling = true;
  playSound("roar");

  const btnFight = document.getElementById("btn-start-tourney-battle");
  if (btnFight) btnFight.style.display = "none";

  const logBox = document.getElementById("tourney-log-box");
  const roundIndicator = document.getElementById("tourney-round-indicator");
  if (logBox) logBox.innerHTML = "";

  let round = 1;
  const advPlayer = (ELEMENTAL_ADVANTAGE[playerDragon.element] || []).includes(currentOpponent.element);
  const advOpp = (ELEMENTAL_ADVANTAGE[currentOpponent.element] || []).includes(playerDragon.element);

  appendTourneyLog(isEn() ? `⚔️ <strong>Combat begins for ${getStageName(tournamentStage)}!</strong>` : `⚔️ <strong>¡Comienza el combate de ${getStageName(tournamentStage)}!</strong>`, "gold");

  if (advPlayer) {
    appendTourneyLog(isEn() ? `🔥 Elemental Advantage! Your <strong>${getDragonElement(playerDragon)}</strong> element dominates the rival's <strong>${getDragonElement(currentOpponent)}</strong>.` : `🔥 ¡Ventaja Elemental! Tu elemento <strong>${getDragonElement(playerDragon)}</strong> domina al <strong>${getDragonElement(currentOpponent)}</strong> rival.`, "teal");
  } else if (advOpp) {
    appendTourneyLog(isEn() ? `⚡ Beware! Rival's <strong>${getDragonElement(currentOpponent)}</strong> element dominates your <strong>${getDragonElement(playerDragon)}</strong>.` : `⚡ ¡Cuidado! El elemento <strong>${getDragonElement(currentOpponent)}</strong> rival domina a tu <strong>${getDragonElement(playerDragon)}</strong>.`, "rust");
  }

  tournamentInterval = setInterval(() => {
    if (roundIndicator) roundIndicator.textContent = `Asalto ${round}`;

    let dmgToOpp = 0;
    let isCrit = false;

    if (!firstTournamentStrikeUsed) {
      dmgToOpp = 57;
      isCrit = true;
      firstTournamentStrikeUsed = true;
    } else {
      const baseAtk = playerDragon.danger * 7 + playerAttackBonus + Math.floor(Math.random() * 8);
      const elemBonus = advPlayer ? 9 : 0;
      const hasCritRelic = playerRelics.includes("crit_boost");
      isCrit = Math.random() < (hasCritRelic ? 0.55 : 0.35) || advPlayer;
      dmgToOpp = Math.round((baseAtk + elemBonus) * (isCrit ? 1.45 : 1.0));
    }

    opponentHp = Math.max(0, opponentHp - dmgToOpp);
    updateTourneyHpBars();

    playSound("hit");
    appendTourneyLog(isEn() ? `${isCrit ? '💥 CRITICAL HIT! ' : ''}Your dragon strikes with <em>${getDragonAbility(playerDragon)}</em> dealing <strong>${dmgToOpp}</strong> damage!` : `${isCrit ? '💥 ¡CRÍTICO! ' : ''}¡Tu dragón ataca con <em>${getDragonAbility(playerDragon)}</em> causando <strong>${dmgToOpp}</strong> de daño!`, isCrit ? "gold" : "teal");

    if (opponentHp <= 0) {
      handleTournamentRoundWin();
      return;
    }

    setTimeout(() => {
      if (opponentHp <= 0) return;
      const baseOppAtk = currentOpponent.danger * 7 + Math.floor(Math.random() * 7);
      const oppElemBonus = advOpp ? 8 : 0;
      const rawDmg = baseOppAtk + oppElemBonus - playerDefenseBonus;
      const finalDmg = Math.max(4, Math.round(rawDmg));

      playerHp = Math.max(0, playerHp - finalDmg);
      updateTourneyHpBars();

      playSound("hit");
      appendTourneyLog(isEn() ? `${currentOpponent.name} counterattacks dealing <strong>${finalDmg}</strong> damage!` : `¡${currentOpponent.name} contrataca infligiendo <strong>${finalDmg}</strong> de daño!`, "rust");

      if (playerHp <= 0) {
        handleTournamentDefeat();
      }
    }, 600);

    round++;
  }, 1400);
};

function updateTourneyHpBars() {
  const pBar = document.getElementById("player-hp-bar");
  const pText = document.getElementById("player-hp-text");
  const oBar = document.getElementById("opp-hp-bar");
  const oText = document.getElementById("opp-hp-text");

  if (pBar) pBar.style.width = `${(playerHp / playerMaxHp) * 100}%`;
  if (pText) pText.textContent = `${playerHp} / ${playerMaxHp}`;
  if (oBar) oBar.style.width = `${(opponentHp / opponentMaxHp) * 100}%`;
  if (oText) oText.textContent = `${opponentHp} / ${opponentMaxHp}`;
}

function appendTourneyLog(message, styleType = "main") {
  const logBox = document.getElementById("tourney-log-box");
  if (!logBox) return;

  const entry = document.createElement("div");
  entry.style.padding = "5px 9px";
  entry.style.borderRadius = "6px";

  if (styleType === "gold") {
    entry.style.background = "rgba(233,196,106,0.15)";
    entry.style.color = "var(--gold-light)";
  } else if (styleType === "teal") {
    entry.style.background = "rgba(42,157,143,0.15)";
    entry.style.color = "#80ed99";
  } else if (styleType === "rust") {
    entry.style.background = "rgba(230,57,70,0.15)";
    entry.style.color = "#ff9f1c";
  } else {
    entry.style.background = "rgba(255,255,255,0.03)";
    entry.style.color = "var(--text-main)";
  }

  entry.innerHTML = message;
  logBox.appendChild(entry);
  logBox.scrollTop = logBox.scrollHeight;
}

function handleTournamentRoundWin() {
  if (tournamentInterval) clearInterval(tournamentInterval);
  isTournamentBattling = false;
  playSound("victory");

  appendTourneyLog(`🏆👑 <strong>¡HAS DERROTADO A ${currentOpponent.name}!</strong>`, "gold");

  if (tournamentStage >= 3) {
    setTimeout(() => {
      tournamentStage = 5;
      const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
      if (container) renderArenaContainer(container);
    }, 1500);
  } else {
    showRelicSelectionModal();
  }
}

function showRelicSelectionModal() {
  const modal = document.getElementById("relic-reward-modal");
  const optContainer = document.getElementById("relic-options-container");
  if (!modal || !optContainer) return;

  const shuffled = [...BLESSINGS_POOL].sort(() => 0.5 - Math.random()).slice(0, 3);

  optContainer.innerHTML = shuffled.map(relic => `
    <div class="fantasy-panel" style="padding: 1rem; border: 1px solid var(--gold-main); text-align: center; border-radius: 12px; background: rgba(0,0,0,0.5);">
      <div style="font-size: 2.2rem; margin-bottom: 6px;">${relic.icon}</div>
      <h4 style="color: var(--gold-light); margin: 0 0 6px 0; font-size: 1rem;">${relic.name}</h4>
      <p style="color: var(--text-main); font-size: 0.85rem; margin-bottom: 12px;">${relic.desc}</p>
      <button type="button" class="btn btn-gold btn-sm" onclick="claimRelicReward('${relic.id}')" style="width: 100%; font-weight: 700;">
        Elegir Bendición ✨
      </button>
    </div>
  `).join("");

  modal.style.display = "block";
  modal.scrollIntoView({ behavior: "smooth" });
}

window.claimRelicReward = function(relicId) {
  const relic = BLESSINGS_POOL.find(r => r.id === relicId);
  if (relic) {
    relic.apply();
    playerRelics.push(relic.name);
    playSound("chime");
  }

  tournamentStage++;
  setupTournamentRound();
};

function handleTournamentDefeat() {
  if (tournamentInterval) clearInterval(tournamentInterval);
  isTournamentBattling = false;
  playSound("click");

  appendTourneyLog(`💀 <strong>¡Tu dragón ha caído en combate! Fin del recorrido en el Torneo.</strong>`, "rust");

  const btnFight = document.getElementById("btn-start-tourney-battle");
  if (btnFight) {
    btnFight.textContent = "🔄 Reintentar Torneo";
    btnFight.style.display = "inline-block";
    btnFight.onclick = resetTournamentToStart;
  }

  setTimeout(() => {
    tournamentStage = -1;
    const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
    if (container) renderArenaContainer(container);
  }, 1300);
}


/* ==========================================================================
   3. MODO BATALLA DE ESCUADRONES 5 VS 5 (GUERRA DE CLANES)
   ========================================================================== */

function renderSquadViewHtml() {
  if (squadWinnerTeam) {
    const winnerName = squadWinnerTeam === "A" ? squadNameA : squadNameB;
    const loserName = squadWinnerTeam === "A" ? squadNameB : squadNameA;
    const winningSquad = squadWinnerTeam === "A" ? squadA : squadB;
    const losingSquad = squadWinnerTeam === "A" ? squadB : squadA;
    const winningHps = squadWinnerTeam === "A" ? squadHpA : squadHpB;
    const survivingCount = winningHps.filter(h => h > 0).length;

    return `
      <!-- PANTALLA DE VICTORIA GUERRA 5v5 (SIN COPA) -->
      <div class="fantasy-panel text-center" style="padding: 2.5rem 1.5rem; border: 3px solid var(--gold-main); border-radius: 20px; background: radial-gradient(circle, rgba(233,196,106,0.2) 0%, rgba(15,23,42,0.96) 100%); margin-bottom: 2rem; box-shadow: 0 10px 40px rgba(233,196,106,0.25);">
        <div style="font-size: 3.5rem; margin-bottom: 6px; animation: pulse 1.5s infinite;">👑⚔️🛡️</div>
        <h2 style="color: var(--gold-main); font-size: 2.3rem; font-family: var(--font-heading); margin: 0 0 10px 0;">${t("arena_squad_victory_title", "¡CLAN VENCEDOR DE LA ARENA 5v5!")}</h2>
        <p style="color: #80ed99; font-size: 1.25rem; font-weight: 700; margin-bottom: 2rem;">
          ¡El escuadrón <strong>[${winnerName}]</strong> ha triunfado en la batalla campal con <strong>${survivingCount}</strong> dragones en pie demostrando la supremacía de su bando!
        </p>

        <!-- CONFRONTACIÓN DE CLANES: VENCEDORES VS RIVALES -->
        <div style="display: flex; justify-content: center; align-items: stretch; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 2rem;">
          
          <!-- CLAN GANADOR -->
          <div class="fantasy-panel" style="flex: 1; min-width: 290px; max-width: 440px; padding: 1.5rem; border: 2px solid var(--gold-main); border-radius: 16px; background: rgba(10,9,17,0.9); box-shadow: 0 0 25px rgba(233,196,106,0.35);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid var(--border-panel); padding-bottom: 8px;">
              <span class="badge" style="background: rgba(42,157,143,0.25); color: #80ed99; border: 1px solid #2a9d8f; font-weight: 800;">${t("arena_squad_triumphant_clan", "👑 Clan Triunfador")}</span>
              <span style="color: var(--gold-main); font-weight: 700; font-size: 1.1rem;">[${winnerName}]</span>
            </div>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0 0 12px 0; text-align: left;">${t("arena_squad_survivors", "Sobrevivientes:")} <strong style="color: #80ed99;">${survivingCount} / 5</strong></p>
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px;">
              ${winningSquad.map((d, idx) => {
                const isAlive = winningHps[idx] > 0;
                return `
                  <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                    <div style="width: 54px; height: 54px; border-radius: 50%; overflow: hidden; border: 2px solid ${isAlive ? 'var(--gold-main)' : '#ff4757'}; position: relative; background: #0a0911;">
                      <img src="${getDragonArtworkSrc(d)}" alt="${d.name}" style="width: 100%; height: 100%; object-fit: cover; opacity: ${isAlive ? 1 : 0.35};" />
                      ${!isAlive ? '<div style="position: absolute; inset:0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.55); color: #ff4757; font-size: 0.85rem;">💀</div>' : ''}
                    </div>
                    <span style="font-size: 0.72rem; color: ${isAlive ? '#80ed99' : 'var(--text-muted)'}; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 60px;">${d.name}</span>
                  </div>
                `;
              }).join("")}
            </div>
          </div>

          <div style="display: flex; align-items: center; justify-content: center; font-size: 1.8rem; color: var(--text-muted); font-weight: 800;">VS</div>

          <!-- CLAN DERROTADO -->
          <div class="fantasy-panel" style="flex: 1; min-width: 280px; max-width: 400px; padding: 1.5rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 16px; background: rgba(10,9,17,0.6); opacity: 0.75;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 8px;">
              <span class="badge badge-danger">${t("arena_squad_defeated_clan", "💀 Clan Derrotado")}</span>
              <span style="color: var(--text-muted); font-weight: 700; font-size: 1.05rem;">[${loserName}]</span>
            </div>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin: 0 0 12px 0; text-align: left;">${t("arena_squad_survivors", "Sobrevivientes:")} <strong style="color: #ff6b6b;">0 / 5</strong></p>
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px;">
              ${losingSquad.map((d) => `
                <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                  <div style="width: 50px; height: 50px; border-radius: 50%; overflow: hidden; border: 1px solid rgba(255,255,255,0.2); position: relative; background: #0a0911;">
                    <img src="${getDragonArtworkSrc(d)}" alt="${d.name}" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.35;" />
                    <div style="position: absolute; inset:0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.55); color: #ff4757; font-size: 0.8rem;">💀</div>
                  </div>
                  <span style="font-size: 0.72rem; color: var(--text-muted); text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 56px;">${d.name}</span>
                </div>
              `).join("")}
            </div>
          </div>

        </div>

        <button type="button" class="btn btn-gold btn-lg" onclick="resetSquadWar()" style="padding: 14px 34px; font-weight: 800; font-size: 1.15rem; box-shadow: 0 6px 20px rgba(233,196,106,0.4);">
          ${t("arena_squad_another_war", "🔄 Disputar Otra Guerra de Clanes")}
        </button>
      </div>
    `;
  }

  ensureArenaInitialized();
  const activeDragonA = (squadA && squadA[activeIndexA]) || (squadA && squadA[0]) || DRAGONS_DATA[0];
  const activeDragonB = (squadB && squadB[activeIndexB]) || (squadB && squadB[0]) || DRAGONS_DATA[1];
  const currentHpA = (squadHpA && squadHpA[activeIndexA] !== undefined) ? squadHpA[activeIndexA] : 100;
  const currentHpB = (squadHpB && squadHpB[activeIndexB] !== undefined) ? squadHpB[activeIndexB] : 100;

  const aliveA = (squadHpA || []).filter(h => h > 0).length;
  const aliveB = (squadHpB || []).filter(h => h > 0).length;

  return `
    <!-- HERO BANNER ARENA ESCUADRONES -->
    <div class="fantasy-panel text-center margin-bottom-lg" style="padding: 1.6rem; background: linear-gradient(135deg, rgba(42,157,143,0.2), rgba(233,196,106,0.15)); border: 2px solid var(--color-teal); border-radius: 20px;">
      <div style="font-size: 2.5rem; margin-bottom: 4px;">🛡️🐉⚔️</div>
      <h2 style="color: var(--gold-main); font-size: 1.85rem; margin: 0; font-family: var(--font-heading);">${t("arena_squad_banner_title", "Guerra de Clanes: 5 vs 5")}</h2>
      <p style="color: var(--text-main); font-size: 0.95rem; max-width: 760px; margin: 6px auto 0 auto; line-height: 1.5;">
        ${t("arena_squad_banner_desc", "¡Formá tu clan de 5 dragones con nombre personalizado y enfrentá al escuadrón rival en una batalla campal por relevos hasta la última garra!")}
      </p>
    </div>

    <!-- CONFIGURADOR Y BARRAS DE ESCUADRÓN -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; margin-bottom: 1.5rem;">
      
      <!-- ESCUADRÓN A (TU CLAN) -->
      <div class="fantasy-panel" style="padding: 1.2rem; border: 2px solid var(--gold-main); border-radius: 14px; background: rgba(15,23,42,0.9);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
          <div style="display: flex; align-items: center; gap: 6px; flex: 1;">
            <span style="font-size: 1.3rem;">🛡️</span>
            <input type="text" id="squad-name-input-a" class="search-input" value="${squadNameA}" placeholder="${t('arena_squad_name_a', 'Nombre de tu Clan...')}" onchange="updateSquadName('A', this.value)" style="font-weight: 700; color: var(--gold-main); padding: 6px 10px; font-size: 1rem; width: 100%; max-width: 240px;" ${isSquadBattling ? "disabled" : ""} />
          </div>
          <button type="button" class="btn btn-secondary btn-sm" onclick="randomizeSquad('A')" ${isSquadBattling ? "disabled" : ""}>${t("arena_random", "🎲 Al Azar")}</button>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <span style="font-size: 0.85rem; color: var(--text-muted);">${t("arena_squad_survivors", "Sobrevivientes:")}</span>
          <span class="badge" style="background: rgba(42,157,143,0.25); color: #80ed99; font-weight: 800; border: 1px solid #2a9d8f;">${aliveA} / 5 ${t('arena_dragons_count', 'Dragones')}</span>
        </div>

        <!-- LISTA DE MINIATURAS 5 DRAGONES A -->
        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px;">
          ${squadA.map((d, idx) => `
            <div class="squad-slot ${idx === activeIndexA ? 'squad-slot-active' : ''} ${squadHpA[idx] <= 0 ? 'squad-slot-dead' : ''}" onclick="selectActiveSquadDragon('A', ${idx})">
              <div class="squad-slot-img-wrap" style="border-color: ${idx === activeIndexA ? 'var(--gold-main)' : 'rgba(255,255,255,0.12)'};">
                <img src="${getDragonArtworkSrc(d)}" alt="${d.name}" style="opacity: ${squadHpA[idx] <= 0 ? 0.3 : 1};" />
                ${squadHpA[idx] <= 0 ? `<div style="position: absolute; top:0; left:0; right:0; bottom:0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.6); color: #ff4757; font-weight: 800; font-size: 1.1rem;">💀</div>` : ''}
              </div>
              <span class="squad-slot-name" style="color: ${idx === activeIndexA ? 'var(--gold-main)' : 'var(--text-muted)'};">${d.name}</span>
              <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; overflow: hidden; margin-top: 2px;">
                <div style="width: ${squadHpA[idx]}%; height: 100%; background: #2a9d8f;"></div>
              </div>
            </div>
          `).join("")}
        </div>

        <!-- BOTÓN SELECTOR RÁPIDO PARA CAMBIAR INTEGRANTE A -->
        <div style="margin-top: 12px;">
          <button type="button" class="arena-picker-btn" onclick="openDragonPicker('squad_A_${activeIndexA}')" ${isSquadBattling ? "disabled" : ""}>
            <span>🔍 ${t('arena_squad_change_pos', 'Cambiar pos.')} ${activeIndexA + 1}: <strong>${activeDragonA.name}</strong></span>
            <span style="color: var(--gold-main); font-size: 0.8rem;">${t("arena_search_btn", "Buscar ▾")}</span>
          </button>
        </div>
      </div>

      <!-- ESCUADRÓN B (RIVALES) -->
      <div class="fantasy-panel" style="padding: 1.2rem; border: 2px solid #ff4757; border-radius: 14px; background: rgba(15,23,42,0.9);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
          <div style="display: flex; align-items: center; gap: 6px; flex: 1;">
            <span style="font-size: 1.3rem;">⚔️</span>
            <input type="text" id="squad-name-input-b" class="search-input" value="${squadNameB}" placeholder="${t('arena_squad_name_b', 'Nombre del Clan Rival...')}" onchange="updateSquadName('B', this.value)" style="font-weight: 700; color: #ff6b6b; padding: 6px 10px; font-size: 1rem; width: 100%; max-width: 240px;" ${isSquadBattling ? "disabled" : ""} />
          </div>
          <button type="button" class="btn btn-secondary btn-sm" onclick="randomizeSquad('B')" ${isSquadBattling ? "disabled" : ""}>${t("arena_random", "🎲 Al Azar")}</button>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <span style="font-size: 0.85rem; color: var(--text-muted);">${t("arena_squad_survivors", "Sobrevivientes:")}</span>
          <span class="badge" style="background: rgba(230,57,70,0.25); color: #ff6b6b; font-weight: 800; border: 1px solid #e63946;">${aliveB} / 5 ${t('arena_dragons_count', 'Dragones')}</span>
        </div>

        <!-- LISTA DE MINIATURAS 5 DRAGONES B -->
        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px;">
          ${squadB.map((d, idx) => `
            <div class="squad-slot ${idx === activeIndexB ? 'squad-slot-active' : ''} ${squadHpB[idx] <= 0 ? 'squad-slot-dead' : ''}" onclick="selectActiveSquadDragon('B', ${idx})">
              <div class="squad-slot-img-wrap" style="border-color: ${idx === activeIndexB ? '#ff4757' : 'rgba(255,255,255,0.12)'};">
                <img src="${getDragonArtworkSrc(d)}" alt="${d.name}" style="opacity: ${squadHpB[idx] <= 0 ? 0.3 : 1};" />
                ${squadHpB[idx] <= 0 ? `<div style="position: absolute; top:0; left:0; right:0; bottom:0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.6); color: #ff4757; font-weight: 800; font-size: 1.1rem;">💀</div>` : ''}
              </div>
              <span class="squad-slot-name" style="color: ${idx === activeIndexB ? '#ff6b6b' : 'var(--text-muted)'};">${d.name}</span>
              <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; overflow: hidden; margin-top: 2px;">
                <div style="width: ${squadHpB[idx]}%; height: 100%; background: #ff4757;"></div>
              </div>
            </div>
          `).join("")}
        </div>

        <!-- BOTÓN SELECTOR RÁPIDO PARA CAMBIAR INTEGRANTE B -->
        <div style="margin-top: 12px;">
          <button type="button" class="arena-picker-btn" onclick="openDragonPicker('squad_B_${activeIndexB}')" ${isSquadBattling ? "disabled" : ""}>
            <span>🔍 ${t('arena_squad_change_pos', 'Cambiar pos.')} ${activeIndexB + 1}: <strong>${activeDragonB.name}</strong></span>
            <span style="color: var(--gold-main); font-size: 0.8rem;">${t("arena_search_btn", "Buscar ▾")}</span>
          </button>
        </div>
      </div>

    </div>

    <!-- ARENA CENTRAL DEL CHOQUE ACTIVO (CAMPEÓN A vs CAMPEÓN B EN TURNO) -->
    <div class="arena-grid">
      
      <!-- LUCHADOR ACTIVO CLAN A -->
      <div class="fantasy-panel fighter-card fighter-card-a">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-a">🐲 ${squadNameA} [Posición ${activeIndexA + 1}]</span>
          </div>

          <div class="fighter-img-box">
            <img src="${getDragonArtworkSrc(activeDragonA)}" alt="${activeDragonA.name}" />
          </div>

          <h3 class="fighter-name">${activeDragonA.name}</h3>
          <p class="fighter-subtitle">"${getDragonTitle(activeDragonA)}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${activeDragonA.element.toLowerCase()}">${getDragonElement(activeDragonA)}</span>
            <span class="badge badge-type">${getDragonType(activeDragonA)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${activeDragonA.danger}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(activeDragonA)}
          </p>
        </div>

        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: var(--color-teal);">${t("arena_squad_fighter_hp", "Salud del Combatiente")}</span>
            <span id="squad-hp-text-A" style="color: var(--color-teal);">${currentHpA} / 100</span>
          </div>
          <div class="fighter-hp-track" style="border-color: var(--color-teal);">
            <div id="squad-hp-bar-A" class="fighter-hp-fill-a" style="width: ${currentHpA}%;"></div>
          </div>
        </div>
      </div>

      <!-- BOTONERA CENTRAL GUERRA -->
      <div class="arena-vs-panel">
        <div class="arena-vs-badge" style="font-size: 1.8rem; line-height: 1.1;">5v5<br><span style="font-size: 1.1rem; color: var(--text-muted);">WAR</span></div>
        
        <button id="btn-start-squad-war" type="button" class="btn btn-gold btn-lg arena-btn-fight" onclick="startSquadWar()" ${isSquadBattling ? "disabled" : ""}>
          ${t("arena_squad_start_btn", "⚔️ ¡INICIAR GUERRA DE CLANES!")}
        </button>

        <button id="btn-reset-squad-war" type="button" class="btn btn-secondary btn-sm margin-top-sm" onclick="resetSquadWar()" style="display: ${squadBattleEnded ? 'inline-block' : 'none'};">
          ${t("arena_squad_another_war", "🔄 Reiniciar Guerra")}
        </button>
      </div>

      <!-- LUCHADOR ACTIVO CLAN B -->
      <div class="fantasy-panel fighter-card fighter-card-b">
        <div>
          <div class="fighter-card-header">
            <span class="fighter-title fighter-title-b">🐲 ${squadNameB} [Posición ${activeIndexB + 1}]</span>
          </div>

          <div class="fighter-img-box">
            <img src="${getDragonArtworkSrc(activeDragonB)}" alt="${activeDragonB.name}" />
          </div>

          <h3 class="fighter-name">${activeDragonB.name}</h3>
          <p class="fighter-subtitle">"${getDragonTitle(activeDragonB)}"</p>

          <div class="fighter-badges">
            <span class="badge badge-element badge-${activeDragonB.element.toLowerCase()}">${getDragonElement(activeDragonB)}</span>
            <span class="badge badge-type">${getDragonType(activeDragonB)}</span>
            <span class="badge badge-danger">🔥 ${t("danger_prefix", "Peligro")} ${activeDragonB.danger}/5</span>
          </div>

          <p class="fighter-stat-text">
            <strong style="color: var(--gold-main);">${t("stat_ability", "Habilidad")}:</strong> ${getDragonAbility(activeDragonB)}
          </p>
        </div>

        <div class="fighter-hp-wrap">
          <div class="fighter-hp-info">
            <span style="color: #ff6b6b;">${t("arena_squad_fighter_hp", "Salud del Combatiente")}</span>
            <span id="squad-hp-text-B" style="color: #ff6b6b;">${currentHpB} / 100</span>
          </div>
          <div class="fighter-hp-track" style="border-color: #ff4757;">
            <div id="squad-hp-bar-B" class="fighter-hp-fill-b" style="width: ${currentHpB}%;"></div>
          </div>
        </div>
      </div>

    </div>

    <!-- CRÓNICA DE LA GUERRA 5V5 -->
    <div class="fantasy-panel" style="padding: 1.5rem; border: 2px solid var(--border-gold); background: rgba(10, 9, 17, 0.95); border-radius: 16px;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid var(--border-panel); padding-bottom: 8px;">
        <h3 style="color: var(--gold-main); margin: 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          📜 Crónica de la Guerra de Escuadrones
        </h3>
        <span id="squad-round-indicator" style="color: var(--text-muted); font-size: 0.9rem; font-weight: bold;">Preparando las filas</span>
      </div>

      <div id="squad-log-box" style="height: 180px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; padding-right: 8px; font-size: 0.92rem; line-height: 1.5; color: var(--text-main);">
        <div style="color: var(--text-muted); font-style: italic; text-align: center; padding-top: 50px;">
          Asigná los nombres de los clanes, configurá tus 5 dragones y presioná "¡BATALLA CAMPAL!"...
        </div>
      </div>
    </div>
  `;
}

window.updateSquadName = function(teamKey, name) {
  if (teamKey === "A") squadNameA = name.trim() || "Legión Dracónica";
  else squadNameB = name.trim() || "Horda Ancestral";
};

window.changeSquadMember = function(teamKey, index, dragonId) {
  if (isSquadBattling) return;
  const d = DRAGONS_DATA.find(x => x.id === parseInt(dragonId));
  if (!d) return;

  if (teamKey === "A") squadA[index] = d;
  else squadB[index] = d;

  playSound("click");
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.selectActiveSquadDragon = function(teamKey, index) {
  if (isSquadBattling) return;
  if (teamKey === "A") activeIndexA = index;
  else activeIndexB = index;

  playSound("click");
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.randomizeSquad = function(teamKey) {
  if (isSquadBattling) return;
  playSound("click");
  const shuffled = [...DRAGONS_DATA].sort(() => 0.5 - Math.random());
  if (teamKey === "A") {
    squadA = shuffled.slice(0, 5);
    squadHpA = [100, 100, 100, 100, 100];
    activeIndexA = 0;
  } else {
    squadB = shuffled.slice(0, 5);
    squadHpB = [100, 100, 100, 100, 100];
    activeIndexB = 0;
  }
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.resetSquadWar = function() {
  if (squadInterval) clearInterval(squadInterval);
  isSquadBattling = false;
  squadBattleEnded = false;
  squadWinnerTeam = null;
  squadHpA = [100, 100, 100, 100, 100];
  squadHpB = [100, 100, 100, 100, 100];
  activeIndexA = 0;
  activeIndexB = 0;
  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.startSquadWar = function() {
  if (isSquadBattling) return;

  squadWinnerTeam = null;

  if (squadBattleEnded || squadHpA.every(h => h <= 0) || squadHpB.every(h => h <= 0)) {
    squadHpA = [100, 100, 100, 100, 100];
    squadHpB = [100, 100, 100, 100, 100];
    activeIndexA = 0;
    activeIndexB = 0;
  }

  isSquadBattling = true;
  squadBattleEnded = false;
  playSound("roar");

  const btnStart = document.getElementById("btn-start-squad-war");
  const btnReset = document.getElementById("btn-reset-squad-war");
  if (btnStart) btnStart.style.display = "none";
  if (btnReset) btnReset.style.display = "none";

  const logBox = document.getElementById("squad-log-box");
  const roundIndicator = document.getElementById("squad-round-indicator");
  if (logBox) logBox.innerHTML = "";

  appendSquadLog(`🛡️⚔️ <strong>¡DA INICIO LA GUERRA CAMPAL 5v5 ENTRE [${squadNameA}] Y [${squadNameB}]!</strong>`, "gold");

  let clashCount = 1;

  squadInterval = setInterval(() => {
    if (squadHpA[activeIndexA] <= 0) {
      const nextA = squadHpA.findIndex(h => h > 0);
      if (nextA !== -1) {
        activeIndexA = nextA;
        appendSquadLog(`🔄 <strong>${squadNameA}</strong> envía al frente a <strong>${squadA[activeIndexA].name}</strong>!`, "teal");
        playSound("chime");
      } else {
        endSquadWar("B");
        return;
      }
    }

    if (squadHpB[activeIndexB] <= 0) {
      const nextB = squadHpB.findIndex(h => h > 0);
      if (nextB !== -1) {
        activeIndexB = nextB;
        appendSquadLog(`🔄 <strong>${squadNameB}</strong> envía al frente a <strong>${squadB[activeIndexB].name}</strong>!`, "rust");
        playSound("chime");
      } else {
        endSquadWar("A");
        return;
      }
    }

    const dragonActiveA = squadA[activeIndexA];
    const dragonActiveB = squadB[activeIndexB];

    if (roundIndicator) roundIndicator.textContent = `Choque #${clashCount} (Duelo en curso)`;

    const advA = (ELEMENTAL_ADVANTAGE[dragonActiveA.element] || []).includes(dragonActiveB.element);
    const advB = (ELEMENTAL_ADVANTAGE[dragonActiveB.element] || []).includes(dragonActiveA.element);

    const baseAtkA = dragonActiveA.danger * 7 + Math.floor(Math.random() * 8);
    const elemBonusA = advA ? 8 : 0;
    const isCritA = Math.random() < 0.35 || advA;
    const dmgA = Math.round((baseAtkA + elemBonusA) * (isCritA ? 1.4 : 1.0));

    squadHpB[activeIndexB] = Math.max(0, squadHpB[activeIndexB] - dmgA);
    updateSquadWarUi();

    playSound("hit");
    appendSquadLog(`${isCritA ? '💥 ' : ''}<strong>${dragonActiveA.name}</strong> (${squadNameA}) golpea con <em>${dragonActiveA.ability}</em> causando <strong>${dmgA}</strong> de daño a ${dragonActiveB.name}!`, isCritA ? "gold" : "teal");

    if (squadHpB[activeIndexB] <= 0) {
      appendSquadLog(`💀 <strong>¡${dragonActiveB.name} ha caído en combate!</strong>`, "rust");
      if (squadHpB.every(h => h <= 0)) {
        endSquadWar("A");
        return;
      }
    }

    setTimeout(() => {
      if (squadHpB[activeIndexB] <= 0) return;
      if (squadHpA[activeIndexA] <= 0) return;

      const baseAtkB = dragonActiveB.danger * 7 + Math.floor(Math.random() * 8);
      const elemBonusB = advB ? 8 : 0;
      const isCritB = Math.random() < 0.35 || advB;
      const dmgB = Math.round((baseAtkB + elemBonusB) * (isCritB ? 1.4 : 1.0));

      squadHpA[activeIndexA] = Math.max(0, squadHpA[activeIndexA] - dmgB);
      updateSquadWarUi();

      playSound("hit");
      appendSquadLog(`${isCritB ? '💥 ' : ''}<strong>${dragonActiveB.name}</strong> (${squadNameB}) contrataca infligiendo <strong>${dmgB}</strong> de daño a ${dragonActiveA.name}!`, isCritB ? "rust" : "main");

      if (squadHpA[activeIndexA] <= 0) {
        appendSquadLog(`💀 <strong>¡${dragonActiveA.name} ha caído en combate!</strong>`, "rust");
        if (squadHpA.every(h => h <= 0)) {
          endSquadWar("B");
        }
      }
    }, 600);

    clashCount++;
  }, 1400);
};

function updateSquadWarUi() {
  const hpTextA = document.getElementById("squad-hp-text-A");
  const hpBarA = document.getElementById("squad-hp-bar-A");
  const hpTextB = document.getElementById("squad-hp-text-B");
  const hpBarB = document.getElementById("squad-hp-bar-B");

  const curHpA = squadHpA[activeIndexA] !== undefined ? squadHpA[activeIndexA] : 0;
  const curHpB = squadHpB[activeIndexB] !== undefined ? squadHpB[activeIndexB] : 0;

  if (hpTextA) hpTextA.textContent = `${curHpA} / 100`;
  if (hpBarA) hpBarA.style.width = `${curHpA}%`;
  if (hpTextB) hpTextB.textContent = `${curHpB} / 100`;
  if (hpBarB) hpBarB.style.width = `${curHpB}%`;

  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) {
    const logBox = document.getElementById("squad-log-box");
    const savedLog = logBox ? logBox.innerHTML : "";
    const roundInd = document.getElementById("squad-round-indicator");
    const savedRound = roundInd ? roundInd.textContent : "";

    renderArenaContainer(container);

    const newLogBox = document.getElementById("squad-log-box");
    if (newLogBox && savedLog) {
      newLogBox.innerHTML = savedLog;
      newLogBox.scrollTop = newLogBox.scrollHeight;
    }
    const newRoundInd = document.getElementById("squad-round-indicator");
    if (newRoundInd && savedRound) {
      newRoundInd.textContent = savedRound;
    }
  }
}

function appendSquadLog(message, styleType = "main") {
  const logBox = document.getElementById("squad-log-box");
  if (!logBox) return;

  const entry = document.createElement("div");
  entry.style.padding = "5px 9px";
  entry.style.borderRadius = "6px";

  if (styleType === "gold") {
    entry.style.background = "rgba(233,196,106,0.15)";
    entry.style.color = "var(--gold-light)";
  } else if (styleType === "teal") {
    entry.style.background = "rgba(42,157,143,0.15)";
    entry.style.color = "#80ed99";
  } else if (styleType === "rust") {
    entry.style.background = "rgba(230,57,70,0.15)";
    entry.style.color = "#ff9f1c";
  } else {
    entry.style.background = "rgba(255,255,255,0.03)";
    entry.style.color = "var(--text-main)";
  }

  entry.innerHTML = message;
  logBox.appendChild(entry);
  logBox.scrollTop = logBox.scrollHeight;
}

function endSquadWar(winningTeam) {
  if (squadInterval) clearInterval(squadInterval);
  isSquadBattling = false;
  squadBattleEnded = true;
  playSound("victory");

  const winnerName = winningTeam === "A" ? squadNameA : squadNameB;
  appendSquadLog(`🛡️👑 <strong>¡GLORIA Y SUPREMACÍA TOTAL! ¡El escuadrón [${winnerName}] ha aniquilado al clan rival y conquistado la Arena 5v5!</strong>`, "gold");

  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);

  setTimeout(() => {
    squadWinnerTeam = winningTeam;
    const target = document.getElementById("arena-container") || document.getElementById("coliseo-container");
    if (target) renderArenaContainer(target);
  }, 1300);
}


/* ==========================================================================
   4. SISTEMA DE BÚSQUEDA RÁPIDA Y SELECTOR VISUAL DE DRAGONES
   ========================================================================== */

window.openDragonPicker = function(contextKey) {
  ensureArenaInitialized();
  activePickerContext = contextKey;
  pickerSearchQuery = "";
  pickerElementFilter = "Todos";
  playSound("click");
  renderDragonPickerModal();
};

window.closeDragonPicker = function() {
  activePickerContext = null;
  const root = document.getElementById("arena-picker-modal-root");
  if (root) root.innerHTML = "";
};

window.filterDragonPicker = function() {
  const input = document.getElementById("picker-search-input");
  const select = document.getElementById("picker-elem-filter");
  if (input) pickerSearchQuery = input.value.trim().toLowerCase();
  if (select) pickerElementFilter = select.value;
  renderDragonPickerList();
};

function renderDragonPickerModal() {
  const root = document.getElementById("arena-picker-modal-root");
  if (!root) return;

  const elementsList = ["Todos", "Fuego", "Agua", "Tierra", "Viento", "Tormenta", "Hielo", "Magma", "Luz", "Sombra", "Veneno", "Naturaleza", "Cristal"];

  root.innerHTML = `
    <div class="arena-picker-modal-overlay" onclick="handlePickerOverlayClick(event)">
      <div class="arena-picker-modal">
        
        <div class="arena-picker-header">
          <h3 style="color: var(--gold-main); margin: 0; font-size: 1.25rem; display: flex; align-items: center; gap: 8px;">
            ${t("arena_picker_title", "🔍 Seleccionar Dragón para el Combate")}
          </h3>
          <button type="button" class="btn btn-secondary btn-sm" onclick="closeDragonPicker()">${t("arena_picker_close", "✕ Cerrar")}</button>
        </div>

        <div class="arena-picker-filters">
          <div style="flex: 2; min-width: 180px;">
            <input type="text" id="picker-search-input" class="search-input" placeholder="${t('arena_picker_placeholder', '🔍 Escribí un nombre o mitología...')}" oninput="filterDragonPicker()" style="padding: 8px 12px; font-size: 0.95rem;" autofocus />
          </div>
          <div style="flex: 1; min-width: 140px;">
            <select id="picker-elem-filter" class="filter-select" onchange="filterDragonPicker()" style="padding: 8px; font-size: 0.9rem;">
              ${elementsList.map(e => `<option value="${e}">${e === 'Todos' ? 'Todos los Elementos' : e}</option>`).join("")}
            </select>
          </div>
        </div>

        <div id="arena-picker-list-container" class="arena-picker-list"></div>

      </div>
    </div>
  `;

  renderDragonPickerList();
}

function renderDragonPickerList() {
  const container = document.getElementById("arena-picker-list-container");
  if (!container) return;

  const filtered = DRAGONS_DATA.filter(d => {
    const matchQuery = !pickerSearchQuery || 
      d.name.toLowerCase().includes(pickerSearchQuery) || 
      d.mythology.toLowerCase().includes(pickerSearchQuery) ||
      d.ability.toLowerCase().includes(pickerSearchQuery);

    const matchElement = pickerElementFilter === "Todos" || d.element.toLowerCase() === pickerElementFilter.toLowerCase();

    return matchQuery && matchElement;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 2rem;">
        ${t("arena_picker_no_results", "No se encontraron dragones con esos criterios")} de búsqueda.
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(d => `
    <div class="arena-picker-card" onclick="selectPickerDragon(${d.id})">
      <img src="${getDragonArtworkSrc(d)}" alt="${d.name}" loading="lazy" />
      <div class="picker-name">${d.name}</div>
      <div class="picker-meta">${getDragonElement(d)} • ${t("danger_prefix", "Peligro")} ${d.danger}/5</div>
    </div>
  `).join("");
}

window.handlePickerOverlayClick = function(e) {
  if (e.target.classList.contains("arena-picker-modal-overlay")) {
    closeDragonPicker();
  }
};

window.selectPickerDragon = function(dragonId) {
  const dragon = DRAGONS_DATA.find(d => d.id === dragonId);
  if (!dragon || !activePickerContext) return;

  playSound("click");

  if (activePickerContext === "duel_A") {
    dragonA = dragon;
  } else if (activePickerContext === "duel_B") {
    dragonB = dragon;
  } else if (activePickerContext === "tourney") {
    playerDragon = dragon;
  } else if (activePickerContext.startsWith("squad_A_")) {
    const idx = parseInt(activePickerContext.replace("squad_A_", ""));
    squadA[idx] = dragon;
  } else if (activePickerContext.startsWith("squad_B_")) {
    const idx = parseInt(activePickerContext.replace("squad_B_", ""));
    squadB[idx] = dragon;
  }

  closeDragonPicker();

  const container = document.getElementById("arena-container") || document.getElementById("coliseo-container");
  if (container) renderArenaContainer(container);
};

window.endBattle = endBattle;
window.handleTournamentDefeat = handleTournamentDefeat;
window.handleTournamentRoundWin = handleTournamentRoundWin;
window.endSquadWar = endSquadWar;



window.isBattling = isBattling;
window.isTournamentBattling = isTournamentBattling;
window.isSquadBattling = isSquadBattling;
window.renderArenaContainer = renderArenaContainer;
window.initColiseoModule = initColiseoModule;




function renderFavoritesView() {
  const container = document.getElementById("favorites-grid");
  if (!container) return;

  const favSet = getFavoritesSet();
  const favDragons = DRAGONS_DATA.filter(d => favSet.has(d.id));

  const isEn = (typeof window !== "undefined" && window.I18N && window.I18N.currentLang === "en");
  const t = (k) => (window.I18N ? window.I18N.t(k) : k);

  if (favDragons.length === 0) {
    container.innerHTML = `
      <div class="empty-state fantasy-panel width-100">
        <h3>${t("fav_empty_title")}</h3>
        <p>${t("fav_empty_desc")}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = favDragons.map(dragon => renderDragonCardHTML(dragon)).join("");

  // Attach card click handlers for modal detail and favorite toggling
  container.querySelectorAll(".dragon-card").forEach(card => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".fav-btn")) return;
      const dragonId = parseInt(card.dataset.id, 10);
      const dragon = DRAGONS_DATA.find(d => d.id === dragonId);
      if (dragon) openDragonModal(dragon, renderFavoritesView);
    });

    const btnFav = card.querySelector(".fav-btn");
    if (btnFav) {
      btnFav.addEventListener("click", (e) => {
        e.stopPropagation();
        const dragonId = parseInt(card.dataset.id, 10);
        toggleFavorite(dragonId);
        renderFavoritesView();
      });
    }
  });
}

window.renderFavoritesView = renderFavoritesView;




  // 5. MAIN ENTRY POINT

function switchTab(tabName, playSoundEffect = true) {
  if (playSoundEffect) {
    playSound("click");
  }

  const sectionUrls = {
    encyclopedia: "/",
    arena: "/arena.html",
    coliseo: "/arena.html",
    magic: "/magia-draconiana.html",
    quiz: "/test-draconiano.html",
    favorites: "/favoritos.html"
  };

  const targetSection = document.getElementById(`section-${tabName}`);
  if (!targetSection && sectionUrls[tabName]) {
    window.location.href = sectionUrls[tabName];
    return;
  }

  // Toggle active tab button
  document.querySelectorAll(".nav-tab").forEach(tab => {
    if (tab.dataset.tab === tabName) {
      tab.classList.add("active");
    } else {
      tab.classList.remove("active");
    }
  });

  // Toggle active view section
  document.querySelectorAll(".view-section").forEach(sec => {
    sec.classList.remove("active");
    sec.style.display = "none";
  });

  if (targetSection) {
    targetSection.classList.add("active");
    targetSection.style.display = "block";
  }

  // Trigger view renderers
  if (tabName === "encyclopedia") {
    renderEncyclopedia();
  } else if (tabName === "arena" || tabName === "coliseo") {
    initColiseoModule();
  } else if (tabName === "sigils") {
    switchTab("magic", false);
    if (window.switchMagicSubPage) {
      window.switchMagicSubPage("sigilos");
    }
  } else if (tabName === "magic") {
    initMagicModule();
  } else if (tabName === "quiz") {
    initQuizModule();
  } else if (tabName === "favorites") {
    renderFavoritesView();
  }

  window.scrollTo({ top: 0, behavior: "smooth" });
}

// Expose switchTab globally immediately
window.switchTab = switchTab;
window.renderEncyclopedia = renderEncyclopedia;

function initApp() {
  initParticlesCanvas("particle-canvas");

  const btnAudio = document.getElementById("btn-audio-toggle");
  if (btnAudio) {
    updateAudioButtonUI();
    btnAudio.addEventListener("click", toggleSound);
  }

  // Attach sound click handler to all nav tabs
  document.querySelectorAll(".nav-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      playSound("click");
    });
  });

  initEncyclopediaFilters();
  
  // Check active route from pathname without double sound or flash
  const path = window.location.pathname;
  if (path.includes("magia-draconiana")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("fundamentos");
  } else if (path.includes("altar-varita")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("altar");
    if (window.switchAltarTool) window.switchAltarTool("varita");
  } else if (path.includes("altar-pentaculo")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("altar");
    if (window.switchAltarTool) window.switchAltarTool("pentaculo");
  } else if (path.includes("altar-espejo")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("altar");
    if (window.switchAltarTool) window.switchAltarTool("espejo");
  } else if (path.includes("altar-dragonscript")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("altar");
    if (window.switchAltarTool) window.switchAltarTool("dragonscript");
  } else if (path.includes("altar-draconiano")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("altar");
  } else if (path.includes("academia-anillo-1")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
    if (window.switchMagicRing) window.switchMagicRing(1);
  } else if (path.includes("academia-anillo-2")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
    if (window.switchMagicRing) window.switchMagicRing(2);
  } else if (path.includes("academia-anillo-3")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
    if (window.switchMagicRing) window.switchMagicRing(3);
  } else if (path.includes("academia-anillo-4")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
    if (window.switchMagicRing) window.switchMagicRing(4);
  } else if (path.includes("academia-anillo-5")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
    if (window.switchMagicRing) window.switchMagicRing(5);
  } else if (path.includes("academia-draconiana")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("academia");
  } else if (path.includes("forja-de-sigilos")) {
    switchTab("magic", false);
    if (window.switchMagicSubPage) window.switchMagicSubPage("sigilos");
  } else if (path.includes("test-draconiano")) {
    switchTab("quiz", false);
  } else if (path.includes("arena") || path.includes("coliseo")) {
    switchTab("arena", false);
  } else if (path.includes("favoritos")) {
    switchTab("favorites", false);
  } else if (!path.includes("/dragon/")) {
    renderEncyclopedia();
  }

  // Deep-linking fallback: redirect legacy ?dragon=ID parameters to static SSG page
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("dragon")) {
    const dId = parseInt(urlParams.get("dragon"), 10);
    const dragon = DRAGONS_DATA.find(d => d.id === dId);
    if (dragon) {
      const slug = dragon.name.toLowerCase().replace(/á/g,'a').replace(/é/g,'e').replace(/í/g,'i').replace(/ó/g,'o').replace(/ú/g,'u').replace(/ñ/g,'n').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
      window.location.href = `/dragon/${slug}.html`;
    }
  }

  window.initApp = initApp;
}

// ==========================================================================
// SISTEMA DE REPORTE DE ERRORES Y SUGERENCIAS (ESTILO LIBER 777 ENGINE)
// ==========================================================================
window.FEEDBACK_WEBHOOK_URL = window.FEEDBACK_WEBHOOK_URL || "https://script.google.com/macros/s/AKfycbwbHMfLxLqgcTvcQ6q-B_LjEusWXV27VQL51w6Y186McFCuwSmqpzQewU9AZKUk9Ljy/exec";

window.ensureFeedbackModalInDOM = function() {
  if (document.getElementById("feedback-modal-backdrop")) return;

  const isEn = (typeof window !== "undefined" && window.I18N && window.I18N.currentLang === "en");
  const modalHtml = `
  <div id="feedback-modal-backdrop" class="feedback-modal-backdrop" style="display:none;" onclick="if(event.target===this) closeFeedbackModal();">
    <div class="feedback-modal-box">
      <div class="feedback-modal-header">
        <h3><span>🝯</span> <span>${isEn ? 'Report Error or Suggestion' : 'Reportar Error o Sugerencia'}</span></h3>
        <button type="button" class="feedback-close-btn" onclick="closeFeedbackModal()" aria-label="${isEn ? 'Close' : 'Cerrar'}">&times;</button>
      </div>
      <form id="feedback-form" onsubmit="submitFeedback(event)">
        <div class="form-group">
          <label for="fb-type">${isEn ? 'Report Type:' : 'Tipo de Reporte:'}</label>
          <select id="fb-type" required>
            <option value="errata">${isEn ? 'Errata or lore/mythology correction' : 'Errata o corrección de lore / mitología'}</option>
            <option value="bug">${isEn ? 'Technical bug (Arena, Combat, Quiz, Magic)' : 'Falla técnica o bug (Arena, Combate, Test, Magia)'}</option>
            <option value="sugerencia">${isEn ? 'Suggestion or proposal for the Sanctuary' : 'Sugerencia o propuesta para el Santuario'}</option>
            <option value="visual">${isEn ? 'Visual issue or mobile screen glitch' : 'Problema visual o de pantalla en celular'}</option>
            <option value="otro">${isEn ? 'Other subject' : 'Otro asunto'}</option>
          </select>
        </div>
        <div class="form-group">
          <label for="fb-context">${isEn ? 'Page / Source section:' : 'Página / Sección de origen:'}</label>
          <input type="text" id="fb-context" readonly>
        </div>
        <div class="form-group">
          <label for="fb-key-cat">${isEn ? 'Affected dragon, mode or element (optional):' : 'Dragón, modo o elemento afectado (opcional):'}</label>
          <input type="text" id="fb-key-cat" placeholder="${isEn ? 'E.g.: Dragon #15, Arena 5v5, Draconian Quiz...' : 'Ej: Dragón #15, Arena 5v5, Test Draconiano...'}">
        </div>
        <div class="form-group">
          <label for="fb-message">${isEn ? 'Error or suggestion description:' : 'Descripción del error o sugerencia:'}</label>
          <textarea id="fb-message" rows="4" required placeholder="${isEn ? 'Describe what happened, what looked wrong or what you suggest...' : 'Describí qué ocurrió, qué viste mal o qué sugerís para mejorar el Santuario...'}"></textarea>
        </div>
        <!-- Campo Honeypot invisible Anti-Spam para atrapar bots -->
        <div style="display:none !important; visibility:hidden; opacity:0; position:absolute; left:-9999px;">
          <input type="text" id="fb-hp-website" name="website_verification_code" tabindex="-1" autocomplete="off">
        </div>
        <div class="form-group">
          <label for="fb-email">${isEn ? 'Your contact email (optional):' : 'Tu correo de contacto (opcional):'}</label>
          <input type="email" id="fb-email" placeholder="${isEn ? 'In case you want us to notify you when resolved' : 'Por si querés que te avisemos cuando lo resolvamos'}">
        </div>
        <div id="fb-status-msg" style="display:none; padding:0.6rem 0.8rem; border-radius:8px; margin-bottom:1rem; font-size:0.88rem;"></div>
        <div class="feedback-modal-actions">
          <button type="button" class="btn-cancel" onclick="closeFeedbackModal()">${isEn ? 'Cancel' : 'Cancelar'}</button>
          <button type="submit" id="fb-submit-btn" class="btn-submit">
            <span id="fb-btn-text">${isEn ? 'Send Report' : 'Enviar Reporte'}</span>
          </button>
        </div>
      </form>
    </div>
  </div>`;
  document.body.insertAdjacentHTML("beforeend", modalHtml);
};

window.openFeedbackModal = function(keyOrCat) {
  window.ensureFeedbackModalInDOM();
  const backdrop = document.getElementById("feedback-modal-backdrop");
  if (!backdrop) return;
  window._fbOpenTime = Date.now();
  const ctxInput = document.getElementById("fb-context");
  if (ctxInput) {
    const currentPath = window.location.pathname.split('/').filter(Boolean).slice(-2).join('/') || window.location.pathname;
    ctxInput.value = currentPath || document.title;
  }
  const keyCatInput = document.getElementById("fb-key-cat");
  if (keyCatInput && keyOrCat) {
    keyCatInput.value = keyOrCat;
  }
  const statusMsg = document.getElementById("fb-status-msg");
  if (statusMsg) statusMsg.style.display = "none";
  backdrop.style.display = "flex";
  document.body.style.overflow = "hidden";
};

window.closeFeedbackModal = function() {
  const backdrop = document.getElementById("feedback-modal-backdrop");
  if (backdrop) backdrop.style.display = "none";
  document.body.style.overflow = "";
};

window.submitFeedback = async function(e) {
  e.preventDefault();
  const btn = document.getElementById("fb-submit-btn");
  const btnText = document.getElementById("fb-btn-text");
  const statusMsg = document.getElementById("fb-status-msg");

  // 1. Blindaje Honeypot: si el bot completó el campo trampa
  const hpVal = document.getElementById("fb-hp-website") ? document.getElementById("fb-hp-website").value : "";
  if (hpVal) {
    if (statusMsg) {
      statusMsg.style.display = "block";
      statusMsg.style.color = "#10b981";
      statusMsg.textContent = "✦ Reporte registrado con éxito.";
    }
    setTimeout(() => { window.closeFeedbackModal(); }, 1000);
    return;
  }

  // 2. Blindaje Time-Gate: si se envió en menos de 1.5s desde abrir el modal
  const timeSpent = (Date.now() - (window._fbOpenTime || 0)) / 1000;
  if (timeSpent < 1.5) {
    if (statusMsg) {
      statusMsg.style.display = "block";
      statusMsg.style.color = "#10b981";
      statusMsg.textContent = "✦ Reporte registrado con éxito.";
    }
    setTimeout(() => { window.closeFeedbackModal(); }, 800);
    return;
  }

  // 3. Blindaje Rate-Limiting: Cooldown de 20s por navegador
  const lastSub = parseInt(localStorage.getItem("santuario_fb_last") || "0", 10);
  if (Date.now() - lastSub < 20000) {
    if (statusMsg) {
      statusMsg.style.display = "block";
      statusMsg.style.background = "rgba(233, 196, 106, 0.15)";
      statusMsg.style.border = "1px solid var(--gold-main)";
      statusMsg.style.color = "var(--gold-main)";
      statusMsg.textContent = "✦ Por favor esperá unos segundos antes de enviar otro reporte.";
    }
    return;
  }

  const payload = {
    type: document.getElementById("fb-type").value,
    url: window.location.href,
    page: document.title,
    context: document.getElementById("fb-context").value,
    dragon_o_modo: document.getElementById("fb-key-cat").value,
    message: document.getElementById("fb-message").value,
    email: document.getElementById("fb-email").value,
    timestamp: new Date().toISOString(),
    userAgent: navigator.userAgent
  };

  if (btn) btn.disabled = true;
  if (btnText) btnText.textContent = "Enviando...";

  try {
    const webhookUrl = window.FEEDBACK_WEBHOOK_URL || localStorage.getItem("santuario_feedback_webhook");

    if (!webhookUrl) {
      const stored = JSON.parse(localStorage.getItem("santuario_offline_feedback") || "[]");
      stored.push(payload);
      localStorage.setItem("santuario_offline_feedback", JSON.stringify(stored));
      localStorage.setItem("santuario_fb_last", Date.now().toString());

      if (statusMsg) {
        statusMsg.style.display = "block";
        statusMsg.style.background = "rgba(233, 196, 106, 0.18)";
        statusMsg.style.border = "1px solid var(--gold-main)";
        statusMsg.style.color = "var(--gold-main)";
        statusMsg.textContent = "✦ ¡Reporte guardado! Muchas gracias por colaborar con la sabiduría del Santuario.";
      }
      setTimeout(() => {
        const form = document.getElementById("feedback-form");
        if (form) form.reset();
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = "Enviar Reporte";
        window.closeFeedbackModal();
      }, 2000);
      return;
    }

    await fetch(webhookUrl, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    localStorage.setItem("santuario_fb_last", Date.now().toString());

    if (statusMsg) {
      statusMsg.style.display = "block";
      statusMsg.style.background = "rgba(42, 157, 143, 0.2)";
      statusMsg.style.border = "1px solid #2a9d8f";
      statusMsg.style.color = "#80ed99";
      statusMsg.textContent = "✦ ¡Reporte enviado con éxito! El conocimiento ha sido transmitido a los guardianes.";
    }

    setTimeout(() => {
      const form = document.getElementById("feedback-form");
      if (form) form.reset();
      if (btn) btn.disabled = false;
      if (btnText) btnText.textContent = "Enviar Reporte";
      window.closeFeedbackModal();
    }, 2000);

  } catch (err) {
    console.error("[Feedback] Error al enviar reporte:", err);
    if (statusMsg) {
      statusMsg.style.display = "block";
      statusMsg.style.background = "rgba(230, 57, 70, 0.2)";
      statusMsg.style.border = "1px solid #e63946";
      statusMsg.style.color = "#ff6b6b";
      statusMsg.textContent = "Hubo un error al enviar. El reporte quedó respaldado en tu navegador.";
    }
    if (btn) btn.disabled = false;
  }
};

window.getFeedbackReports = function() {
  const reports = JSON.parse(localStorage.getItem("santuario_offline_feedback") || "[]");
  if (reports.length === 0) {
    console.log("ℹ️ No hay reportes de errores guardados aún en este navegador.");
  } else {
    console.log(`📋 Total de reportes almacenados: ${reports.length}`);
    console.table(reports);
  }
  return reports;
};

window.clearFeedbackReports = function() {
  localStorage.removeItem("santuario_offline_feedback");
  console.log("🧹 Todos los reportes locales fueron eliminados.");
};

// Auto-boot app on DOMContentLoaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initApp);
} else {
  initApp();
}

// PWA Service Worker Registration
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        console.log("[PWA] Service Worker activo:", reg.scope);
      })
      .catch((err) => {
        console.warn("[PWA] Error al registrar Service Worker:", err);
      });
  });
}

})();