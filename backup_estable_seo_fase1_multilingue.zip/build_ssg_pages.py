import os, re, shutil, json, html

root_dir = r'c:\Users\matia\Documents\proyectos antigravity\dragones'
dragons_file = os.path.join(root_dir, 'js', 'data', 'dragons.js')
dragons_en_file = os.path.join(root_dir, 'js', 'data', 'dragons_en.json')
template_file = os.path.join(root_dir, 'index.html')
output_dir = os.path.join(root_dir, 'dragon')

dragons_en = {}
if os.path.exists(dragons_en_file):
    with open(dragons_en_file, 'r', encoding='utf-8') as f:
        dragons_en = json.load(f)

def escape_attr(val):
    return html.escape(str(val), quote=True)

if os.path.exists(output_dir):
    shutil.rmtree(output_dir)
os.makedirs(output_dir, exist_ok=True)

with open(dragons_file, 'r', encoding='utf-8') as f:
    text = f.read()

with open(template_file, 'r', encoding='utf-8') as f:
    html_template = f.read()

def slugify(text):
    text = text.lower()
    replacements = {'á':'a', 'é':'e', 'í':'i', 'ó':'o', 'ú':'u', 'ñ':'n', 'ü':'u'}
    for k, v in replacements.items():
        text = text.replace(k, v)
    text = re.sub(r'[^a-z0-9]+', '-', text).strip('-')
    return text

blocks = re.split(r'\{\s*id:\s*', text)[1:]
dragons = []

for b in blocks:
    try:
        d_id = int(re.search(r'^(\d+)', b).group(1))
        name = re.search(r'name:\s*"([^"]+)"', b).group(1)
        title = re.search(r'title:\s*"([^"]+)"', b).group(1)
        mythology = re.search(r'mythology:\s*"([^"]+)"', b).group(1)
        type_ = re.search(r'type:\s*"([^"]+)"', b).group(1)
        element = re.search(r'element:\s*"([^"]+)"', b).group(1)
        danger = int(re.search(r'danger:\s*(\d+)', b).group(1))
        habitat = re.search(r'habitat:\s*"([^"]+)"', b).group(1)
        ability = re.search(r'ability:\s*"([^"]+)"', b).group(1)
        weakness = re.search(r'weakness:\s*"([^"]+)"', b).group(1)
        scroll = re.search(r'scroll:\s*"([^"]+)"', b).group(1)
        
        dragons.append({
            'id': d_id, 'name': name, 'title': title, 'mythology': mythology,
            'type': type_, 'element': element, 'danger': danger,
            'habitat': habitat, 'ability': ability, 'weakness': weakness, 'scroll': scroll,
            'slug': slugify(name)
        })
    except Exception as e:
        print(f"Error parsing block: {e}")

print(f"Total dragones parseados: {len(dragons)}")

base_url = "https://santuariodragones.vercel.app"

# Prepare clean template by stripping default meta tags from <head> to prevent duplicates
clean_head_template = html_template
clean_head_template = re.sub(r'<title>.*?</title>\s*', '', clean_head_template)
clean_head_template = re.sub(r'<meta name="description" content=".*?">\s*', '', clean_head_template)
clean_head_template = re.sub(r'<link rel="canonical" href=".*?">\s*', '', clean_head_template)
clean_head_template = re.sub(r'<meta property="og:[^"]+" content=".*?">\s*', '', clean_head_template)
clean_head_template = re.sub(r'<meta name="twitter:[^"]+" content=".*?">\s*', '', clean_head_template)
clean_head_template = re.sub(r'<script type="application/ld\+json">.*?</script>\s*', '', clean_head_template, flags=re.DOTALL)

for d in dragons:
    slug = d['slug']
    img_url = f"{base_url}/assets/dragons/dragon_{d['id']}.webp"
    page_url = f"{base_url}/dragon/{slug}.html"
    
    page_title = f"{d['name']} ({d['title']}) | Santuario de Dragones"
    meta_desc = f"{d['name']} es un dragón {d['type']} de {d['element']} de la mitología {d['mythology']}. Hábitat: {d['habitat']}. {d['scroll'][:140]}..."
    
    en_page_url = f"{base_url}/en/dragon/{slug}.html"
    encoded_myth = d['mythology'].replace(" ", "%20")
    
    og_meta = f'''
  <!-- Custom SSG Open Graph & Meta Tags for {d['name']} -->
  <title>{page_title}</title>
  <meta name="description" content="{meta_desc}">
  <link rel="canonical" href="{page_url}">
  <link rel="alternate" hreflang="es" href="{page_url}">
  <link rel="alternate" hreflang="en" href="{en_page_url}">
  <link rel="alternate" hreflang="x-default" href="{page_url}">
  <meta property="og:title" content="{d['name']} - {d['title']}">
  <meta property="og:description" content="{meta_desc}">
  <meta property="og:image" content="{img_url}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="900">
  <meta property="og:type" content="article">
  <meta property="og:url" content="{page_url}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{d['name']} | Santuario Secreto de Dragones">
  <meta name="twitter:description" content="{meta_desc}">
  <meta name="twitter:image" content="{img_url}">
  
  <script type="application/ld+json">
  {{
    "@context": "https://schema.org",
    "@graph": [
      {{
        "@type": "BreadcrumbList",
        "@id": "{page_url}#breadcrumb",
        "itemListElement": [
          {{
            "@type": "ListItem",
            "position": 1,
            "name": "Santuario de Dragones",
            "item": "{base_url}/"
          }},
          {{
            "@type": "ListItem",
            "position": 2,
            "name": "{d['mythology']}",
            "item": "{base_url}/?mitologia={encoded_myth}"
          }},
          {{
            "@type": "ListItem",
            "position": 3,
            "name": "{d['name']}",
            "item": "{page_url}"
          }}
        ]
      }},
      {{
        "@type": "Article",
        "@id": "{page_url}#article",
        "headline": "{d['name']} - {d['title']}",
        "description": "{meta_desc}",
        "image": "{img_url}",
        "url": "{page_url}",
        "inLanguage": ["es", "en"],
        "author": {{
          "@type": "Person",
          "name": "Magus Dragus"
        }},
        "publisher": {{
          "@type": "Organization",
          "name": "Santuario Secreto de Dragones",
          "url": "{base_url}/",
          "logo": {{
            "@type": "ImageObject",
            "url": "{base_url}/assets/ui/hero_emblem.webp"
          }}
        }},
        "mainEntity": {{
          "@type": "Thing",
          "name": "{d['name']}",
          "alternateName": "{d['title']}",
          "description": "{meta_desc}",
          "image": "{img_url}",
          "additionalProperty": [
            {{ "@type": "PropertyValue", "name": "Mitología", "value": "{d['mythology']}" }},
            {{ "@type": "PropertyValue", "name": "Tipo de Cuerpo", "value": "{d['type']}" }},
            {{ "@type": "PropertyValue", "name": "Elemento", "value": "{d['element']}" }},
            {{ "@type": "PropertyValue", "name": "Nivel de Peligro", "value": "{d['danger']}/5" }},
            {{ "@type": "PropertyValue", "name": "Hábitat", "value": "{d['habitat']}" }},
            {{ "@type": "PropertyValue", "name": "Habilidad Primordial", "value": "{d['ability']}" }},
            {{ "@type": "PropertyValue", "name": "Debilidad", "value": "{d['weakness']}" }}
          ]
        }}
      }}
    ]
  }}
  </script>
'''

    d_en = dragons_en.get(str(d['id']), {})
    title_en = d_en.get('title', d['title'])
    habitat_en = d_en.get('habitat', d['habitat'])
    ability_en = d_en.get('ability', d['ability'])
    weakness_en = d_en.get('weakness', d['weakness'])
    scroll_en = d_en.get('scroll', d['scroll'])

    stars = '⭐' * d['danger']
    
    # Epic Standalone Dragon Detail Page Layout
    dragon_detail_page_html = f'''
    <section class="dragon-detail-standalone-section" style="max-width: 900px; margin: 0.5rem auto; padding: 0 0.3rem;">
      <div style="margin-bottom: 0.8rem;">
        <a href="/" onclick="if (document.referrer &amp;&amp; document.referrer.includes(window.location.host)) {{ history.back(); return false; }}" class="btn btn-secondary" style="text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: 700; padding: 8px 14px; font-size: 0.9rem;">
          <span data-i18n="btn_back_encyclopedia">⬅️ Volver a la Enciclopedia</span>
        </a>
      </div>

      <article class="fantasy-panel dragon-standalone-card" style="padding: 1rem; border-radius: 14px; border: 2px solid var(--gold-main); background: rgba(12, 11, 20, 0.95); box-shadow: 0 10px 35px rgba(0,0,0,0.8);">
        
        <header style="text-align: center; margin-bottom: 1.2rem; border-bottom: 1px solid var(--border-panel); padding-bottom: 1rem;">
          <span class="badge" data-dragon-id-badge="{d['id']}" style="background: rgba(233,196,106,0.15); border: 1px solid var(--gold-main); color: var(--gold-main); padding: 4px 12px; border-radius: 20px; font-weight: 700; font-size: 0.85rem; text-transform: uppercase;">
            📜 Dragón #{d['id']}
          </span>
          <h1 class="hero-title" style="font-size: 2.8rem; color: var(--gold-main); margin: 0.8rem 0 0.4rem 0; font-family: var(--font-heading); text-align: center;">{d['name']}</h1>
          <p class="dragon-standalone-subtitle trans-lore-title" data-es="{escape_attr(d['title'])}" data-en="{escape_attr(title_en)}" style="font-size: 1.3rem; font-style: italic; color: var(--color-teal); margin: 0 auto; text-align: center; width: 100%; display: block;">"{d['title']}"</p>
        </header>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.2rem; align-items: start;">
          
          <!-- Column 1: Image & Badges -->
          <div style="text-align: center;">
            <div style="aspect-ratio: 4 / 3; width: 100%; border-radius: 14px; overflow: hidden; border: 2px solid var(--gold-main); box-shadow: 0 8px 25px rgba(0,0,0,0.7); background: #0c0b14;">
              <img src="/assets/dragons/dragon_{d['id']}.webp" alt="{d['name']}" width="600" height="450" loading="eager" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain;" />
            </div>

            <div style="display: flex; flex-direction: column; gap: 6px; margin-top: 1rem;">
              <span class="badge" style="background: rgba(233,196,106,0.15); border: 1px solid var(--gold-main); color: var(--gold-main); padding: 8px 12px; border-radius: 8px; font-weight: 700; text-align: left; font-size: 0.9rem;">
                🏛️ <span data-i18n="stat_mythology">Mitología</span>: <span class="trans-myth" data-raw="{d['mythology']}">{d['mythology']}</span>
              </span>
              <span class="badge" style="background: rgba(42,157,143,0.15); border: 1px solid var(--color-teal); color: var(--color-teal); padding: 8px 12px; border-radius: 8px; font-weight: 700; text-align: left; font-size: 0.9rem;">
                🐉 <span data-i18n="stat_type">Tipo</span>: <span class="trans-type" data-raw="{d['type']}">{d['type']}</span>
              </span>
              <span class="badge" style="background: rgba(231,111,81,0.15); border: 1px solid #e76f51; color: #e76f51; padding: 8px 12px; border-radius: 8px; font-weight: 700; text-align: left; font-size: 0.9rem;">
                🔥 <span data-i18n="stat_element">Elemento</span>: <span class="trans-elem" data-raw="{d['element']}">{d['element']}</span>
              </span>
              <span class="badge" style="background: rgba(255,255,255,0.08); border: 1px solid #fff; color: #fff; padding: 8px 12px; border-radius: 8px; font-weight: 700; text-align: left; font-size: 0.9rem;">
                ⚠️ <span data-i18n="stat_danger">Peligrosidad</span>: {d['danger']}/5 ({stars})
              </span>
            </div>
          </div>

          <!-- Column 2: Data & Scroll -->
          <div>
            <div style="background: rgba(255,255,255,0.03); padding: 1rem; border-radius: 12px; border: 1px solid var(--border-panel); margin-bottom: 1rem;">
              <h3 style="color: var(--gold-main); margin-top: 0; font-size: 1.15rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 0.4rem;">
                📊 <span data-i18n="combat_data_title">Datos de Combate & Hábitat</span>
              </h3>
              <p style="margin: 0.5rem 0; font-size: 0.95rem;"><strong>🏡 <span data-i18n="stat_habitat">Hábitat</span>:</strong> <span class="trans-lore-habitat" data-es="{escape_attr(d['habitat'])}" data-en="{escape_attr(habitat_en)}" style="color: var(--text-main);">{d['habitat']}</span></p>
              <p style="margin: 0.5rem 0; font-size: 0.95rem;"><strong>⚡ <span data-i18n="stat_ability">Habilidad Especial</span>:</strong> <span class="trans-lore-ability" data-es="{escape_attr(d['ability'])}" data-en="{escape_attr(ability_en)}" style="color: var(--text-main);">{d['ability']}</span></p>
              <p style="margin: 0.5rem 0; font-size: 0.95rem;"><strong>🛡️ <span data-i18n="stat_weakness">Punto Débil</span>:</strong> <span class="trans-lore-weakness" data-es="{escape_attr(d['weakness'])}" data-en="{escape_attr(weakness_en)}" style="color: var(--text-main);">{d['weakness']}</span></p>
            </div>

            <div class="fantasy-panel" style="background: rgba(10,9,17,0.9); padding: 1rem; border-radius: 12px; border: 1px solid var(--gold-main);">
              <h3 style="color: var(--gold-main); margin-top: 0; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
                📜 <span data-i18n="ancient_scroll_title">Pergamino de la Antigüedad</span>
              </h3>
              <p class="trans-lore-scroll" data-es="{escape_attr(d['scroll'])}" data-en="{escape_attr(scroll_en)}" style="font-size: 0.95rem; line-height: 1.6; color: var(--text-main); font-style: italic; margin-bottom: 0;">"{d['scroll']}"</p>
            </div>
          </div>

        </div>

        <footer style="margin-top: 1.5rem; text-align: center; border-top: 1px solid var(--border-panel); padding-top: 1rem;">
          <a href="/" class="btn btn-gold btn-lg" style="text-decoration: none; display: inline-block; font-size: 1rem; padding: 10px 22px;">
            <span data-i18n="btn_back_catalog">📚 Volver al Catálogo de Dragones</span>
          </a>
        </footer>

      </article>
    </section>
'''

    # Build pure static page replacing main section
    page_html = clean_head_template
    
    # Absolute root paths with unified v=8.4.0
    page_html = re.sub(r'href="[^"]*styles(?:\.min)?\.css(?:\?v=[^"]*)?"', 'href="/styles.min.css?v=8.4.0"', page_html)
    page_html = re.sub(r'src="[^"]*bundle(?:\.min)?\.js(?:\?v=[^"]*)?"', 'src="/js/bundle.min.js?v=8.4.0"', page_html)
    
    # Inject OG meta tags
    page_html = page_html.replace('</head>', f'{og_meta}\n</head>')
    page_html = page_html.replace('<script src="/js/i18n.js"></script>', '<script src="/js/data/dragons_en.js"></script>\n  <script src="/js/i18n.js"></script>')

    
    # Replace entire <main class="main-content"> ... </main> with the standalone detail page layout!
    main_regex = r'<main class="main-content">.*?</main>'
    page_html = re.sub(main_regex, f'<main class="main-content">{dragon_detail_page_html}</main>', page_html, flags=re.DOTALL)

    out_file = os.path.join(output_dir, f"{slug}.html")
    with open(out_file, 'w', encoding='utf-8') as f:
        f.write(page_html)

print(f"¡Éxito! Generadas {len(dragons)} páginas de detalle estático limpias en /dragon/")
